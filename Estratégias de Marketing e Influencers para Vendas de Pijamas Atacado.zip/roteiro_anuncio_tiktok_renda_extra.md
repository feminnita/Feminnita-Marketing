# Roteiro Detalhado de Vídeo para Anúncio TikTok - Renda Extra com Pijamas Feminnita

## Informações Gerais do Vídeo

**Título:** "Como Ganhei R$ 2.500 em 1 Mês Revendendo Pijamas (Sem Experiência)"  
**Duração:** 30 segundos (formato TikTok otimizado)  
**Objetivo:** Captar pessoas que buscam renda extra, mostrar viabilidade e facilidade  
**Público-Alvo:** Mulheres 18-45 anos, desempregadas ou buscando renda complementar, sem experiência em vendas  
**Formato:** Antes/Depois + Prova Social + CTA  
**Estilo Visual:** Dinâmico, real, aspiracional  
**Tom de Voz:** Entusiasmado, confiante, acessível  
**Plataforma:** TikTok (vertical 9:16)  
**Resolução:** 1080x1920px  
**FPS:** 30fps (padrão TikTok)  
**Áudio:** Música viral + voz em off  

---

## Estrutura Narrativa

O vídeo segue a estrutura clássica de sucesso no TikTok: **Problema → Solução → Resultado → CTA**. A narrativa começa mostrando a frustração de não ter renda, apresenta a Feminnita como solução, demonstra resultados reais com números específicos, e termina com chamada clara para ação.

---

## Timeline Detalhada (30 segundos)

### Segundo 0-3: GANCHO (Crítico - Primeiros 3 segundos)

**Descrição de Cena:**  
Close-up no rosto de uma mulher (Carol, a persona de empreendedora iniciante) com expressão de frustração/preocupação. Ela está olhando para o celular com expressão de desespero. Fundo: quarto simples, luz natural de janela.

**Áudio:**  
Música viral começa (algo como "Levitating" remixado ou áudio viral de sucesso do TikTok). Volume: 70%. Voz em off feminina (confiante, amigável): "Eu estava QUEBRADA..."

**Texto na Tela:**  
Aparece em letras grandes, brancas, com contorno preto:  
**"EU ESTAVA QUEBRADA"**  
(Fonte: Poppins Bold, tamanho 48px, animação de entrada: slide da esquerda)

**Efeitos Visuais:**  
Transição rápida (0.3s) com zoom leve no rosto. Filtro leve de saturação reduzida (cinza) para transmitir tristeza/preocupação.

**Dica de Produção:**  
Este é o gancho mais importante. Precisa ser IMPACTANTE e relatable. A expressão deve ser genuína de frustração. Não exagere, mas deixe claro o problema.

---

### Segundo 3-6: PROBLEMA EXPANDIDO

**Descrição de Cena:**  
Corte para montagem rápida de 3 cenas (1 segundo cada):  
1. Mulher olhando para carteira vazia (close-up na carteira)  
2. Mulher olhando para contas/boletos (close-up em papéis)  
3. Mulher sentada na cama, pensativa (medium shot)

**Áudio:**  
Voz em off continua: "Sem emprego, sem renda, sem esperança de conseguir algo rápido..."  
Música mantém o tom dramático mas esperançoso.

**Texto na Tela:**  
Aparece em sequência (1 segundo cada):  
**"SEM EMPREGO"** → **"SEM RENDA"** → **"SEM ESPERANÇA"**  
(Mesma fonte, animação: fade in/out rápido)

**Efeitos Visuais:**  
Transições rápidas entre cenas (0.5s cada). Cada cena tem um efeito de "zoom out" suave. Filtro mantém saturação reduzida.

**Dica de Produção:**  
Mantenha as cenas reais e relatable. Não precisa ser perfeito, na verdade, imperfeições aumentam autenticidade. Use luz natural.

---

### Segundo 6-10: VIRADA (O Momento de Esperança)

**Descrição de Cena:**  
Corte para mulher recebendo notificação no celular (close-up na tela do celular mostrando mensagem: "Você foi aprovada para revender Feminnita!"). Seu rosto muda de expressão para surpresa/alegria.

**Áudio:**  
Música muda para tom mais positivo e energético. Voz em off: "Até que um dia, descobri a Feminnita..."  
Som de notificação (ding) quando a mensagem aparece.

**Texto na Tela:**  
**"ATÉ QUE UM DIA..."**  
Depois aparece: **"DESCOBRI A FEMINNITA"**  
(Animação: slide da direita, com efeito de brilho)

**Efeitos Visuais:**  
Transição rápida com efeito de "zoom in" na notificação. Quando a expressão muda, há um flash de luz branca (simbolizando esperança/virada). Saturação volta ao normal.

**Dica de Produção:**  
A mudança de expressão é crucial. Capture genuinamente a alegria. O efeito de flash deve ser sutil, não ofuscante.

---

### Segundo 10-18: RESULTADO (O Coração do Vídeo)

**Descrição de Cena:**  
Montagem rápida de 4 cenas (2 segundos cada):

1. **Cena 1 (2s):** Mulher mostrando pijamas em sua cama/mesa. Close-up nos pijamas coloridos, bonitos. Ela está sorrindo, mostrando para câmera.

2. **Cena 2 (2s):** Close-up em celular mostrando pedidos chegando (notificações de WhatsApp/Instagram com mensagens de clientes). Números de vendas aparecendo na tela (R$ 500, R$ 750, R$ 1.200).

3. **Cena 3 (2s):** Mulher contando dinheiro (notas de R$ 50 e R$ 100) com expressão de satisfação. Câmera foca no dinheiro sendo contado.

4. **Cena 4 (2s):** Mulher com sacolas de compras, sorrindo, comemorando. Fundo: shopping ou rua com lojas.

**Áudio:**  
Voz em off (entusiasmada): "E em apenas 1 mês, ganhei R$ 2.500! Sem experiência, sem estoque prévio, sem complicações!"  
Música continua energética. Sons de notificação (ding) quando números aparecem. Som de dinheiro sendo contado (subtle).

**Texto na Tela:**  
Sequência de números aparecendo na tela:  
**"SEMANA 1: R$ 500"** → **"SEMANA 2: R$ 750"** → **"SEMANA 3: R$ 1.200"** → **"TOTAL: R$ 2.500"**  
Depois aparece em letras maiores: **"EM APENAS 1 MÊS!"**  
(Animação: números aparecem com efeito de "pop" ou "scale")

**Efeitos Visuais:**  
Transições rápidas entre cenas (0.5s). Cada número que aparece tem um efeito de brilho/glow. Cores voltam ao normal, vibrantes. Há um efeito de "confete" digital quando o total aparece.

**Dica de Produção:**  
Este é o momento de PROVA SOCIAL. Mostre números reais (ou realistas). O dinheiro sendo contado é poderoso psicologicamente. Mantenha a energia alta. Sorrisos genuínos.

---

### Segundo 18-24: COMO FUNCIONA (Simplificação)

**Descrição de Cena:**  
Montagem de 3 cenas rápidas (2 segundos cada) mostrando o processo:

1. **Cena 1 (2s):** Mulher no celular, clicando em link. Tela mostra: "Clique aqui para se registrar" com botão destacado. Close-up na mão clicando.

2. **Cena 2 (2s):** Tela do celular mostrando catálogo de pijamas. Mulher swiping através de diferentes cores e modelos. Voz em off explicando.

3. **Cena 3 (2s):** Mulher fotografando pijamas em seu quarto, criando conteúdo. Ela está tirando fotos com celular, sorrindo. Depois a foto aparece em seu Instagram/TikTok.

**Áudio:**  
Voz em off (clara, didática): "É simples: 1) Se registre, 2) Escolha seus pijamas com desconto especial, 3) Comece a vender no seu Instagram ou TikTok!"  
Música mantém tom positivo e energético.

**Texto na Tela:**  
Aparece em sequência (2 segundos cada):  
**"1. SE REGISTRE"** → **"2. ESCOLHA SEUS PIJAMAS"** → **"3. COMECE A VENDER"**  
(Fonte: Poppins Bold, tamanho 40px, animação: slide de baixo para cima)

**Efeitos Visuais:**  
Transições suaves entre cenas. Números aparecem com efeito de "pop". Há um efeito de "highlight" nos botões/elementos interativos.

**Dica de Produção:**  
Mantenha a simplicidade. O objetivo é mostrar que é FÁCIL. Não complique. Use linguagem acessível.

---

### Segundo 24-27: PROVA SOCIAL + URGÊNCIA

**Descrição de Cena:**  
Corte para depoimentos rápidos de 2-3 outras pessoas (pode ser a mesma pessoa em diferentes roupas/ambientes, ou pessoas diferentes). Cada uma fala 1 frase rápida.

1. **Pessoa 1 (1s):** "Já ganhei R$ 1.500 em 2 semanas!" (sorrindo para câmera)
2. **Pessoa 2 (1s):** "Meu melhor cliente comprou 20 peças!" (mostrando thumbs up)
3. **Pessoa 3 (1s):** "Recomendo demais, é real!" (acenando para câmera)

**Áudio:**  
Voz em off: "Milhares de pessoas já estão ganhando com a Feminnita..."  
Música continua energética. Cada depoimento tem um "ding" de notificação.

**Texto na Tela:**  
Aparece acima de cada pessoa:  
**"⭐ DEPOIMENTO REAL"**  
(Animação: fade in)

**Efeitos Visuais:**  
Transições rápidas (0.3s) entre depoimentos. Cada pessoa tem um "frame" ao redor (como um card de TikTok). Há um efeito de "like" (coração) que aparece durante cada depoimento.

**Dica de Produção:**  
Autenticidade é chave. Se usar pessoas diferentes, escolha pessoas reais (amigos, família, clientes reais). Se usar a mesma pessoa, mude roupas/ambiente para parecer diferente. Sorrisos genuínos.

---

### Segundo 27-30: CALL-TO-ACTION (CTA) + FECHAMENTO

**Descrição de Cena:**  
Mulher (Carol) olhando diretamente para câmera, com expressão confiante e convidativa. Ela está em um ambiente limpo, bem iluminado. Fundo: seu quarto ou espaço de trabalho.

**Áudio:**  
Voz em off (direto, convidativo): "Você também pode! Clique no link da bio e comece AGORA!"  
Música atinge o pico de energia. Som de "sucesso" (como um ding positivo).

**Texto na Tela:**  
Aparece em letras GRANDES e destacadas:  
**"CLIQUE NO LINK DA BIO"**  
Depois aparece menor:  
**"COMECE AGORA! 🚀"**  
(Animação: zoom in para o texto principal, depois fade out)

**Efeitos Visuais:**  
Close-up no rosto de Carol. Há um efeito de "glow" ao redor dela (luz de sucesso). Quando o CTA aparece, há um efeito de "pulse" (pulsação) no texto para atrair atenção.

**Dica de Produção:**  
Olhar direto para câmera é poderoso. Crie intimidade. A expressão deve ser confiante mas acessível (não arrogante). O CTA é o momento final crítico - deixe claro e visível.

---

## Especificações Técnicas

### Áudio

**Música de Fundo:**  
- Recomendação: Áudio viral do TikTok (ex: "Levitating" remix, "Good as Hell" remix, ou qualquer áudio de sucesso com >10M usos)
- Volume: 70% durante todo o vídeo
- Duração: 30 segundos (certifique-se de que a música escolhida tenha exatamente 30s ou corte para 30s)
- Estilo: Upbeat, energético, positivo

**Voz em Off:**  
- Voz: Feminina, confiante, amigável, clara
- Tom: Entusiasmado mas não exagerado
- Velocidade: Moderada (não muito rápida, não muito lenta)
- Volume: 80% (mais alto que a música)
- Efeito: Sem reverb excessivo, voz clara e direta
- Duração total de fala: ~20 segundos (deixar 10 segundos para música/efeitos)

**Efeitos Sonoros:**  
- Notificação (ding): Quando números aparecem, quando depoimentos aparecem
- Som de dinheiro: Subtle, quando dinheiro é contado
- Som de sucesso: Quando CTA aparece
- Volume: 40-50% (não deve dominar a música ou voz)

### Visuais

**Cores Principais:**  
- Rosa Feminnita: #E84C89 (usar em acentos, texto principal)
- Branco: #FFFFFF (fundo de texto, clareza)
- Preto: #000000 (contorno de texto, profundidade)
- Cores dos Pijamas: Vibrantes (rosa, azul, verde, amarelo)

**Tipografia:**  
- Fonte Principal: Poppins Bold (Google Fonts - gratuita)
- Tamanho: 40-48px para texto principal, 24-32px para texto secundário
- Contorno: Preto 2-3px para garantir legibilidade
- Sombra: Leve (blur 2px, opacidade 30%) para profundidade

**Transições:**  
- Tipo: Cortes rápidos (0.3-0.5s), slides, zooms suaves
- Duração: Manter rápido (TikTok adora velocidade)
- Efeito: Sem transições muito complexas (mantém foco no conteúdo)

**Filtros/Efeitos:**  
- Primeiros 6 segundos: Saturação reduzida (cinza) para transmitir problema
- Segundo 6 em diante: Cores vibrantes e normais para transmitir solução/sucesso
- Brilho/Glow: Usar em momentos-chave (virada, números, CTA)
- Confete Digital: Quando total de ganhos aparece (opcional, mas poderoso)

### Resolução e Formato

**Resolução:** 1080x1920px (padrão TikTok vertical)  
**Aspect Ratio:** 9:16  
**FPS:** 30fps  
**Codec:** H.264 (compatível com TikTok)  
**Tamanho de Arquivo:** Máximo 287.6MB (limite do TikTok)  
**Duração:** Exatamente 30 segundos  

---

## Dicas de Produção e Gravação

### Equipamento Necessário

**Mínimo:**  
- Celular com câmera decente (iPhone 11+ ou Android equivalente)
- Tripé ou suporte para celular
- Luz natural (janela) ou anel de luz (R$ 50-100)
- Microfone externo (opcional, mas recomendado para voz em off clara)

**Ideal:**  
- Câmera mirrorless ou DSLR
- Microfone lavalier ou shotgun
- Iluminação profissional (ring light + softbox)
- Tripé de qualidade
- Computador para edição

### Ambiente de Gravação

**Quarto/Espaço Pessoal:**  
- Limpo, organizado, bem iluminado
- Fundo neutro ou com elementos que remetem a "trabalho de casa" (mesa, plantas, etc.)
- Luz natural preferível (gravar perto de janela)
- Se usar luz artificial, use temperatura quente (3000K) para parecer acolhedor

**Iluminação:**  
- Luz frontal (não lateral) para iluminar o rosto
- Evitar sombras duras no rosto
- Se usar anel de luz, posicione na altura dos olhos
- Teste a iluminação antes de gravar

### Técnica de Gravação

**Enquadramento:**  
- Primeiros 3 segundos: Close-up no rosto (enquadramento: do queixo até o topo da cabeça)
- Cenas de ação: Medium shot (cintura para cima) ou close-up em mãos/objetos
- CTA final: Close-up no rosto (mesmo enquadramento do gancho)

**Movimento de Câmera:**  
- Mantenha a câmera estável (use tripé)
- Movimentos suaves de zoom (se usar zoom, não muito rápido)
- Evitar movimento de câmera excessivo (distrai)

**Expressões e Atuação:**  
- Primeira cena (frustração): Expressão genuína de preocupação, olhar para baixo/para o lado
- Virada (alegria): Mudança rápida de expressão, sorriso genuíno
- Cenas de ação: Natural, como se estivesse realmente fazendo (não exagerar)
- CTA final: Olhar direto para câmera, sorriso confiante, acenador com a cabeça

### Edição

**Software Recomendado:**  
- Gratuito: CapCut (mobile ou desktop), DaVinci Resolve
- Pago: Adobe Premiere Pro, Final Cut Pro, Sony Vegas

**Passos de Edição:**  
1. Importar todos os clips de vídeo
2. Organizar em sequência (problema → solução → resultado → CTA)
3. Cortar clips para duração exata (30 segundos total)
4. Adicionar transições entre clips (0.3-0.5s cada)
5. Adicionar texto (títulos, números, CTAs) com animações
6. Adicionar áudio (música + voz em off)
7. Balancear volumes (música 70%, voz 80%, efeitos 40-50%)
8. Adicionar efeitos visuais (brilho, glow, confete)
9. Exportar em 1080x1920px, 30fps, H.264

### Checklist de Gravação

- [ ] Ambiente limpo e bem iluminado
- [ ] Celular/câmera carregado
- [ ] Áudio testado (sem ruído de fundo)
- [ ] Expressões praticadas (frustração, alegria, confiança)
- [ ] Roteiro memorizado ou em cards fora de câmera
- [ ] Múltiplas takes de cada cena (pelo menos 3 takes)
- [ ] Voz em off gravada em local silencioso
- [ ] Todos os elementos visuais preparados (pijamas, dinheiro, celular com notificações)

---

## Variações e A/B Testing

### Versão Alternativa 1: "Prova Social Forte"

Se a primeira versão não gerar muitos cliques, tente esta variação que enfatiza mais depoimentos reais:

- Segundo 0-3: Mesmo gancho
- Segundo 3-6: Mostrar 3-4 depoimentos de clientes reais (1.5 segundos cada)
- Segundo 6-15: Mostrar resultados (números, dinheiro)
- Segundo 15-24: Como funciona
- Segundo 24-30: CTA

**Razão:** Algumas audiências confiam mais em depoimentos de pares do que em uma única pessoa.

### Versão Alternativa 2: "Educacional"

Se o público é mais técnico/cético, tente esta variação que explica melhor o modelo:

- Segundo 0-3: Gancho sobre "modelo de negócio fácil"
- Segundo 3-12: Explicar como funciona (margem de lucro, processo)
- Segundo 12-20: Mostrar resultados
- Segundo 20-30: CTA

**Razão:** Público mais educado/técnico quer entender o "como" antes de decidir.

### Versão Alternativa 3: "Lifestyle"

Se o público é mais aspiracional, tente esta variação que mostra estilo de vida:

- Segundo 0-3: Gancho sobre "trabalhe de casa, ganhe bem"
- Segundo 3-15: Mostrar cenas de lifestyle (trabalhando de casa, comprando coisas, relaxando)
- Segundo 15-24: Números de ganho
- Segundo 24-30: CTA

**Razão:** Público aspiracional quer ver o estilo de vida que podem ter, não apenas números.

---

## Estratégia de Postagem e Promoção

### Quando Postar

**Melhor Horário:** 19h-22h (noite, quando pessoas estão no TikTok)  
**Melhor Dia:** Terça a Quinta (menos competição que fim de semana)  
**Frequência:** Postar 1-2 vezes por semana (não spam)

### Como Promover

1. **Postar no TikTok:** Use hashtags relevantes (#RendaExtra #PijamaPerfeito #TrabalhoemCasa #Feminnita)
2. **Compartilhar no Instagram Reels:** Mesmo vídeo, com legenda adaptada
3. **Compartilhar no WhatsApp:** Enviar para grupos de amigas/comunidades
4. **Pedir Shares:** No vídeo, peça para compartilhar com amigas ("Compartilhe com uma amiga que precisa!")
5. **Responder Comentários:** Engage rapidamente com comentários (aumenta algoritmo)

### Métricas para Acompanhar

- **Visualizações:** Meta mínima 10K views
- **Completion Rate:** Meta mínima 50% (pessoas assistindo até o final)
- **Cliques no Link:** Meta mínima 100 cliques
- **Compartilhamentos:** Meta mínima 50 shares
- **Comentários:** Meta mínima 20 comentários
- **Conversão:** Meta mínima 10 registros (de 100 cliques)

Se não atingir essas metas em 48 horas, tente a versão alternativa.

---

## Dicas Finais para Maximizar Sucesso

### 1. Autenticidade é Tudo

Não tente parecer perfeita. Imperfeições aumentam confiança. Se usar a mesma pessoa (Carol), deixe visível que é a mesma pessoa em diferentes momentos.

### 2. Números Específicos Convertem

"R$ 2.500 em 1 mês" converte melhor que "Ganhe muito dinheiro". Números específicos parecem mais reais.

### 3. Problema → Solução → Resultado

Sempre siga esta estrutura. Pessoas precisam sentir o problema antes de querer a solução.

### 4. Velocidade é Chave

TikTok adora conteúdo rápido e dinâmico. Mantenha transições rápidas (0.3-0.5s). Não deixe uma cena por mais de 3 segundos.

### 5. CTA Clara e Direta

Não deixe ambiguidade. "Clique no link da bio" é melhor que "Saiba mais". Deixe o link visível e fácil de encontrar.

### 6. Teste Múltiplas Versões

Não espere uma versão perfeita. Poste, meça, aprenda, otimize. A versão 2 sempre será melhor que a versão 1.

### 7. Engaje com Seu Público

Responda comentários, responda DMs, agradeça shares. Isso aumenta a chance de o algoritmo promover seu vídeo.

### 8. Mantenha Consistência

Se este vídeo funcionar bem, crie variações similares. Consistência no estilo aumenta reconhecimento de marca.

---

## Checklist Final Antes de Postar

- [ ] Vídeo tem exatamente 30 segundos
- [ ] Áudio está sincronizado com vídeo
- [ ] Texto está legível em celular (teste em celular real)
- [ ] Cores estão vibrantes (não muito escuro ou claro)
- [ ] Transições são suaves e rápidas
- [ ] CTA é claro e visível
- [ ] Link na bio está funcional
- [ ] Hashtags estão relevantes e populares
- [ ] Legenda está atrativa
- [ ] Vídeo foi testado em diferentes celulares
- [ ] Áudio foi testado (sem ruído, volume correto)
- [ ] Você está satisfeita com o resultado final
