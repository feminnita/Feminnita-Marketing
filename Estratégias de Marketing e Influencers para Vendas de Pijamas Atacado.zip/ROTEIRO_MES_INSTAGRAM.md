# 📅 Roteiro de Conteúdo - Fevereiro 2026
## Feminnita Pijamas - Instagram + TikTok

---

## 📊 Resumo Executivo

**Objetivo:** Aumentar seguidores em 30%, engajamento em 25% e vendas em 40%

**Personas:** Carol, Renata, Vanessa, Luiza

**Plataformas:** Instagram (Posts + Stories + Reels) + TikTok

**Duração:** 28 dias (01 a 28 de Fevereiro 2026)

**Budget:** R$ 5.000 (Google Ads + Meta Ads)

---

## 🎯 Estratégia Geral

### Semana 1 (01-07 Fev): Lançamento & Engajamento
- Foco: Apresentar coleção de verão
- Tema: "Durma com Estilo"
- Persona Principal: **Carol**

### Semana 2 (08-14 Fev): Conteúdo Educativo
- Foco: Dicas de estilo e conforto
- Tema: "Pijama Perfeito para Cada Momento"
- Persona Principal: **Renata**

### Semana 3 (15-21 Fev): Comunidade & UGC
- Foco: Conteúdo gerado por usuários
- Tema: "Suas Histórias Feminnita"
- Persona Principal: **Vanessa**

### Semana 4 (22-28 Fev): Conversão & Encerramento
- Foco: Promoção e urgência
- Tema: "Últimas Peças da Coleção"
- Persona Principal: **Luiza**

---

## 📅 SEMANA 1: Lançamento & Engajamento (01-07 Fevereiro)

### Segunda-feira, 01 de Fevereiro
**Persona:** Carol | **Horário:** 14:30

#### 📸 Post Instagram (Carrossel)
- **Tipo:** Carrossel (3 fotos)
- **Tema:** "Conheça a Nova Coleção Verão"
- **Hook:** "Durma confortável neste verão! 😴✨"
- **Descrição:**
  - Foto 1: Carol em pijama rosa pastel (close-up)
  - Foto 2: Detalhe do tecido (textura suave)
  - Foto 3: Carol em ambiente aconchegante
- **Hashtags:** #PijamaVerão #Feminnita #NovaColecao #ConfortoTotal #DurmaComEstilo #PijamaRosa #ModaConforto #FeministaFeminnita
- **CTA:** "Confira a coleção completa no link da bio! 🛍️"
- **Engajamento esperado:** 500+ likes, 50+ comentários

#### 🎬 Reel Instagram (15-30 segundos)
- **Tipo:** Transformação/Try-on
- **Tema:** "Antes e Depois - Noite Perfeita"
- **Roteiro:**
  - 0-5s: Carol em roupa comum, cansada
  - 5-10s: Transição com efeito (mudança de cena)
  - 10-15s: Carol em pijama Feminnita, sorrindo
  - 15-30s: Carol dormindo confortavelmente
- **Áudio:** Música relaxante + "Durma como uma rainha"
- **Hashtags:** #FYP #Reels #PijamaPerfeito #TransformaçãoNoturna
- **Engajamento esperado:** 1.000+ views, 100+ likes

#### 📱 Stories (5 stories)
- **Story 1:** Foto de Carol com texto "Boa noite! 🌙" + Sticker de votação "Qual sua cor favorita?"
- **Story 2:** Vídeo curto de Carol colocando o pijama + "Conforto garantido ✨"
- **Story 3:** Foto do detalhe do pijama + "Tecido 100% algodão"
- **Story 4:** Enquete: "Você dorme com pijama?" (Sim/Não)
- **Story 5:** Link para loja + "Aproveite a promoção de lançamento!"

#### 🎥 TikTok Video (30-60 segundos)
- **Tipo:** Trending Sound + Trend
- **Tema:** "Pijama que toda mulher quer"
- **Roteiro:**
  - Usar trending sound "That's what I want"
  - Carol mostrando o pijama
  - Transição rápida para Carol dormindo
  - Texto: "Quando você encontra o pijama perfeito"
- **Hashtags:** #FYP #Pijama #Conforto #Feminnita #Trending
- **Engajamento esperado:** 2.000+ views

---

### Terça-feira, 02 de Fevereiro
**Persona:** Renata | **Horário:** 20:00

#### 📸 Post Instagram (Foto única)
- **Tipo:** Foto lifestyle
- **Tema:** "Pijama é Moda"
- **Hook:** "Quem disse que pijama não é fashionista? 👗✨"
- **Descrição:**
  - Renata em pijama estiloso (cor vibrante)
  - Ambiente moderno e bem iluminado
  - Pose confiante
- **Hashtags:** #PijamaFashion #EstiloFeminnita #ModaConforto #LookDoDia #Fashionista #PijamaChic
- **CTA:** "Qual seu estilo? Comente abaixo! 👇"
- **Engajamento esperado:** 400+ likes, 40+ comentários

#### 🎬 Reel Instagram (20-30 segundos)
- **Tipo:** Get Ready With Me (GRWM)
- **Tema:** "Noite de Cinema em Casa"
- **Roteiro:**
  - 0-5s: Renata em roupa de rua
  - 5-10s: Tirar maquiagem
  - 10-15s: Colocar pijama Feminnita
  - 15-20s: Preparar bebida (café/chá)
  - 20-30s: Renata confortável no sofá com filme
- **Áudio:** Música de cinema + "Noite perfeita"
- **Hashtags:** #GRWM #CinemaEmCasa #CozyNight
- **Engajamento esperado:** 1.200+ views

#### 📱 Stories (4 stories)
- **Story 1:** Foto de Renata + "Noite de série? Pijama Feminnita! 📺"
- **Story 2:** Vídeo mostrando o pijama + "Tecido super macio"
- **Story 3:** Poll: "Série ou Filme?" com opções
- **Story 4:** Link para promoção + "Desconto especial para seguidores!"

#### 🎥 TikTok Video (30-60 segundos)
- **Tipo:** Day in My Life
- **Tema:** "Meu Ritual Noturno"
- **Roteiro:**
  - Mostrar rotina noturna
  - Colocar pijama Feminnita
  - Relaxar no sofá
  - Dormir confortável
- **Hashtags:** #DayInMyLife #RotinaNorturna #Feminnita
- **Engajamento esperado:** 1.800+ views

---

### Quarta-feira, 03 de Fevereiro
**Persona:** Carol | **Horário:** 10:00

#### 📸 Post Instagram (Carrossel)
- **Tipo:** Educativo - Dicas de Cuidado
- **Tema:** "Como Cuidar do Seu Pijama Feminnita"
- **Hook:** "Quer que seu pijama dure para sempre? Aqui estão as dicas! 💡"
- **Descrição:**
  - Foto 1: Pijama pendurado para secar
  - Foto 2: Detalhe da etiqueta de cuidado
  - Foto 3: Carol segurando pijama bem cuidado
  - Foto 4: Pijama em perfeito estado após 6 meses
- **Hashtags:** #DicasDeModaFeminnita #CuidadoComRoupas #SustentabilidadeFashion #PijamaQualidade
- **CTA:** "Siga essas dicas e seu pijama durará anos!"
- **Engajamento esperado:** 350+ likes, 35+ comentários

#### 🎬 Reel Instagram (15-20 segundos)
- **Tipo:** Tutorial/How-to
- **Tema:** "Passo a Passo: Lavar o Pijama Corretamente"
- **Roteiro:**
  - Mostrar pijama sujo
  - Colocar na máquina (água fria)
  - Usar detergente suave
  - Pendurar para secar
  - Resultado final: pijama impecável
- **Áudio:** Música leve + instruções
- **Hashtags:** #Tutorial #DicasDeModaFeminnita #CuidadoComRoupas
- **Engajamento esperado:** 900+ views

#### 📱 Stories (3 stories)
- **Story 1:** Vídeo Carol lavando pijama + "Assim fica perfeito! ✨"
- **Story 2:** Foto do pijama secando + "Sempre pendurado!"
- **Story 3:** Poll: "Você cuida bem de suas roupas?" (Sim/Não)

#### 🎥 TikTok Video (30-45 segundos)
- **Tipo:** Trending + Tutorial
- **Tema:** "Como Lavar Pijama Corretamente"
- **Roteiro:**
  - Mostrar pijama sujo
  - Transição rápida para pijama limpo
  - Dicas em texto
- **Hashtags:** #Tutorial #FYP #DicasDeModaFeminnita
- **Engajamento esperado:** 1.500+ views

---

### Quinta-feira, 04 de Fevereiro
**Persona:** Vanessa | **Horário:** 18:00

#### 📸 Post Instagram (Foto única)
- **Tipo:** Lifestyle/Aspiracional
- **Tema:** "Fim de Semana Começa Aqui"
- **Hook:** "Sexta-feira é sinônimo de pijama confortável! 🎉"
- **Descrição:**
  - Vanessa em pijama roxo/lavanda
  - Ambiente aconchegante
  - Expressão de felicidade
- **Hashtags:** #SextaFeiraÉ #WeekendMode #PijamaFeminnita #ConfortoTotal #FimDeSemana #VidaBoa
- **CTA:** "Como você curte seu fim de semana? 👇"
- **Engajamento esperado:** 550+ likes, 55+ comentários

#### 🎬 Reel Instagram (25-30 segundos)
- **Tipo:** Trending + Lifestyle
- **Tema:** "Sexta-feira vs Segunda-feira"
- **Roteiro:**
  - 0-10s: Vanessa segunda-feira (cansada, roupa formal)
  - 10-15s: Transição/mudança
  - 15-30s: Vanessa sexta-feira (pijama, sorridente)
- **Áudio:** Música animada + "Sexta-feira é aqui!"
- **Hashtags:** #SextaFeiraÉ #FYP #Reels
- **Engajamento esperado:** 1.400+ views

#### 📱 Stories (5 stories)
- **Story 1:** Foto de Vanessa + "Sexta-feira! 🎉"
- **Story 2:** Vídeo colocando pijama + "Modo conforto ativado"
- **Story 3:** Foto do pijama + "Qual é sua cor favorita?"
- **Story 4:** Poll: "Você já começou o fim de semana?"
- **Story 5:** Sticker de link + "Aproveite nossa promoção!"

#### 🎥 TikTok Video (30-60 segundos)
- **Tipo:** Trending Sound
- **Tema:** "Sexta-feira vs Segunda-feira"
- **Roteiro:**
  - Usar trending sound
  - Mostrar contraste entre dias da semana
  - Pijama como solução
- **Hashtags:** #FYP #SextaFeiraÉ #Feminnita
- **Engajamento esperado:** 2.200+ views

---

### Sexta-feira, 05 de Fevereiro
**Persona:** Luiza | **Horário:** 19:00

#### 📸 Post Instagram (Carrossel)
- **Tipo:** Produto em Destaque
- **Tema:** "Conheça Todas as Cores da Coleção Verão"
- **Hook:** "Qual é a sua cor? Temos 8 opções incríveis! 🌈"
- **Descrição:**
  - Foto 1: Todas as cores lado a lado
  - Foto 2: Rosa pastel (Carol)
  - Foto 3: Azul royal (Renata)
  - Foto 4: Roxo lavanda (Vanessa)
  - Foto 5: Branco (Luiza)
  - Foto 6: Detalhes de cada cor
  - Foto 7: Luiza em pijama branco
  - Foto 8: Todas as 4 personas juntas
- **Hashtags:** #ColecaoVerão #CoresIncríveis #PijamaFeminnita #ChoqueDeOpções #MulaChoice #ModoVerão
- **CTA:** "Qual é sua favorita? Vote nos comentários! 🗳️"
- **Engajamento esperado:** 700+ likes, 70+ comentários

#### 🎬 Reel Instagram (20-30 segundos)
- **Tipo:** Product Showcase
- **Tema:** "Todas as Cores em 30 Segundos"
- **Roteiro:**
  - Mostrar cada cor rapidamente
  - Transições suaves
  - Texto com nome da cor
  - Final: todas as cores juntas
- **Áudio:** Música alegre + "Qual é a sua?"
- **Hashtags:** #ProductShowcase #ColecaoVerão #FYP
- **Engajamento esperado:** 1.600+ views

#### 📱 Stories (6 stories)
- **Story 1:** Foto de todas as cores + "Qual você escolhe?"
- **Story 2:** Rosa pastel + "Carol ama essa!"
- **Story 3:** Azul royal + "Renata escolheu essa!"
- **Story 4:** Roxo lavanda + "Vanessa não vive sem!"
- **Story 5:** Branco + "Minha favorita! 💕"
- **Story 6:** Poll: "Qual cor você quer?" com opções

#### 🎥 TikTok Video (30-45 segundos)
- **Tipo:** Product Showcase
- **Tema:** "Todas as Cores Disponíveis"
- **Roteiro:**
  - Mostrar cada cor
  - Transições rápidas
  - Texto com cores
- **Hashtags:** #ProductShowcase #ColecaoVerão #FYP
- **Engajamento esperado:** 2.000+ views

---

### Sábado, 06 de Fevereiro
**Persona:** Carol | **Horário:** 15:00

#### 📸 Post Instagram (Foto única)
- **Tipo:** Behind the Scenes
- **Tema:** "Bastidores da Produção Feminnita"
- **Hook:** "Você quer saber como criamos seus pijamas favoritos? 🎬✨"
- **Descrição:**
  - Carol em estúdio fotográfico
  - Mostrando o processo de produção
  - Ambiente profissional
- **Hashtags:** #BehindTheScenes #FeminnitaBTS #ProcessoDeCriação #ModoDeProducao #FashionBTS
- **CTA:** "Segue para mais bastidores! 👉"
- **Engajamento esperado:** 400+ likes, 40+ comentários

#### 🎬 Reel Instagram (25-35 segundos)
- **Tipo:** Behind the Scenes
- **Tema:** "Um Dia no Estúdio Feminnita"
- **Roteiro:**
  - 0-5s: Carol chegando no estúdio
  - 5-10s: Preparação (maquiagem, cabelo)
  - 10-20s: Fotos sendo tiradas
  - 20-30s: Resultado final
  - 30-35s: Carol sorrindo para câmera
- **Áudio:** Música profissional + "Criando magia"
- **Hashtags:** #BTS #FeminnitaBTS #FashionPhotography
- **Engajamento esperado:** 1.100+ views

#### 📱 Stories (4 stories)
- **Story 1:** Vídeo Carol no estúdio + "Dia de produção! 📸"
- **Story 2:** Foto dos equipamentos + "Tecnologia de ponta"
- **Story 3:** Carol posando + "Quase lá!"
- **Story 4:** Resultado final + "Ficou lindo! ✨"

#### 🎥 TikTok Video (30-60 segundos)
- **Tipo:** Behind the Scenes
- **Tema:** "Um Dia no Estúdio"
- **Roteiro:**
  - Mostrar processo de produção
  - Carol posando
  - Resultado final
- **Hashtags:** #BTS #FashionPhotography #FYP
- **Engajamento esperado:** 1.700+ views

---

### Domingo, 07 de Fevereiro
**Persona:** Renata | **Horário:** 20:00

#### 📸 Post Instagram (Carrossel)
- **Tipo:** Motivacional/Inspiracional
- **Tema:** "Domingo é Dia de Autocuidado"
- **Hook:** "Comece a semana bem! Autocuidado começa com conforto! 💆‍♀️✨"
- **Descrição:**
  - Foto 1: Renata em pijama, relaxada
  - Foto 2: Chá/bebida quente
  - Foto 3: Livro ou revista
  - Foto 4: Renata dormindo confortável
  - Foto 5: Mensagem de autocuidado
- **Hashtags:** #AutocuidadoFeminnita #DomingoDeRelax #AutocuidadoÉPrioridade #BemEstarMental #ConfortoTotal #SelfCare
- **CTA:** "Como você curte seu domingo? Comente! 👇"
- **Engajamento esperado:** 600+ likes, 60+ comentários

#### 🎬 Reel Instagram (25-30 segundos)
- **Tipo:** Motivacional/Wellness
- **Tema:** "Seu Domingo Perfeito"
- **Roteiro:**
  - 0-5s: Acordar relaxado
  - 5-10s: Tomar café
  - 10-15s: Colocar pijama confortável
  - 15-20s: Ler/assistir algo
  - 20-30s: Dormir tranquilo
- **Áudio:** Música relaxante + "Autocuidado"
- **Hashtags:** #Wellness #SelfCare #DomingoDeRelax
- **Engajamento esperado:** 1.300+ views

#### 📱 Stories (5 stories)
- **Story 1:** Foto de Renata + "Domingo é sagrado! 🙏"
- **Story 2:** Vídeo preparando chá + "Momento de relax"
- **Story 3:** Foto do pijama + "Conforto garantido"
- **Story 4:** Poll: "Seu domingo perfeito é...?" (Descanso/Atividades)
- **Story 5:** Mensagem de autocuidado + "Cuide-se! 💕"

#### 🎥 TikTok Video (30-60 segundos)
- **Tipo:** Wellness/Motivacional
- **Tema:** "Seu Domingo Perfeito"
- **Roteiro:**
  - Mostrar rotina de autocuidado
  - Pijama confortável
  - Mensagem motivacional
- **Hashtags:** #Wellness #SelfCare #FYP
- **Engajamento esperado:** 1.900+ views

---

## 📅 SEMANA 2: Conteúdo Educativo (08-14 Fevereiro)

### Segunda-feira, 08 de Fevereiro
**Persona:** Vanessa | **Horário:** 14:30

#### 📸 Post Instagram (Carrossel)
- **Tipo:** Educativo - Tipos de Pijama
- **Tema:** "Qual Tipo de Pijama é Ideal para Você?"
- **Hook:** "Cada pessoa tem seu tipo de pijama perfeito! Descubra o seu! 🔍"
- **Descrição:**
  - Foto 1: Pijama curto (verão)
  - Foto 2: Pijama comprido (inverno)
  - Foto 3: Pijama de seda (elegante)
  - Foto 4: Pijama de algodão (conforto)
  - Foto 5: Vanessa em cada tipo
- **Hashtags:** #TiposDePijama #GuiaDeCompra #PijamaPerfeito #EducaçãoFeminnita #ChoqueDeEstilo
- **CTA:** "Qual é o seu tipo? Comente! 👇"
- **Engajamento esperado:** 500+ likes, 50+ comentários

#### 🎬 Reel Instagram (20-30 segundos)
- **Tipo:** Educativo/Comparativo
- **Tema:** "Pijama para Cada Estação"
- **Roteiro:**
  - Mostrar pijama de verão
  - Transição para pijama de inverno
  - Mostrar diferenças
  - Recomendação final
- **Áudio:** Música informativa
- **Hashtags:** #GuiaDeCompra #PijamaPerfeito #FYP
- **Engajamento esperado:** 1.200+ views

#### 📱 Stories (4 stories)
- **Story 1:** Foto de Vanessa + "Qual pijama você prefere?"
- **Story 2:** Vídeo mostrando pijama curto + "Perfeito para verão!"
- **Story 3:** Vídeo mostrando pijama comprido + "Quentinho para inverno"
- **Story 4:** Poll: "Qual você escolhe?" com opções

#### 🎥 TikTok Video (30-45 segundos)
- **Tipo:** Educativo
- **Tema:** "Tipos de Pijama para Cada Pessoa"
- **Roteiro:**
  - Mostrar diferentes tipos
  - Características de cada um
  - Recomendação
- **Hashtags:** #GuiaDeCompra #FYP #PijamaPerfeito
- **Engajamento esperado:** 1.800+ views

---

### Terça-feira, 09 de Fevereiro
**Persona:** Luiza | **Horário:** 20:00

#### 📸 Post Instagram (Foto única)
- **Tipo:** Testimonial/Review
- **Tema:** "O Que Meus Clientes Dizem Sobre Feminnita"
- **Hook:** "Essas avaliações nos deixam muito felizes! 💕"
- **Descrição:**
  - Foto de Luiza com depoimento
  - Citação de cliente satisfeito
  - Estrelas de avaliação
- **Hashtags:** #Testimonial #ClienteSatisfeito #ReviewFeminnita #OpiniãoCliente #Qualidade
- **CTA:** "Deixe sua avaliação! ⭐"
- **Engajamento esperado:** 450+ likes, 45+ comentários

#### 🎬 Reel Instagram (20-30 segundos)
- **Tipo:** Testimonial/Review
- **Tema:** "Histórias de Clientes Satisfeitos"
- **Roteiro:**
  - Mostrar diferentes clientes
  - Suas avaliações
  - Depoimentos curtos
  - Logo Feminnita no final
- **Áudio:** Música inspiradora
- **Hashtags:** #Testimonial #ClienteSatisfeito #FYP
- **Engajamento esperado:** 1.100+ views

#### 📱 Stories (4 stories)
- **Story 1:** Foto de Luiza + "Veja o que nossos clientes dizem!"
- **Story 2:** Depoimento 1 com estrelas
- **Story 3:** Depoimento 2 com estrelas
- **Story 4:** Link para deixar avaliação

#### 🎥 TikTok Video (30-60 segundos)
- **Tipo:** Testimonial
- **Tema:** "Clientes Satisfeitos"
- **Roteiro:**
  - Mostrar depoimentos
  - Avaliações
  - Mensagem final
- **Hashtags:** #Testimonial #ClienteSatisfeito #FYP
- **Engajamento esperado:** 1.600+ views

---

### Quarta-feira, 10 de Fevereiro
**Persona:** Carol | **Horário:** 10:00

#### 📸 Post Instagram (Carrossel)
- **Tipo:** Dicas de Estilo
- **Tema:** "Como Combinar Seu Pijama Feminnita"
- **Hook:** "Pijama não é só para dormir! Veja como combinar! 👗✨"
- **Descrição:**
  - Foto 1: Pijama com robe
  - Foto 2: Pijama com chinelo estiloso
  - Foto 3: Pijama com jaqueta
  - Foto 4: Pijama com acessórios
  - Foto 5: Carol em look completo
- **Hashtags:** #DicasDeEstilo #ComboPerfeita #PijamaFashion #LookDoDia #EstiloFeminnita
- **CTA:** "Qual é sua combinação favorita? 👇"
- **Engajamento esperado:** 550+ likes, 55+ comentários

#### 🎬 Reel Instagram (25-30 segundos)
- **Tipo:** Styling/Fashion
- **Tema:** "3 Formas de Usar Seu Pijama"
- **Roteiro:**
  - 0-10s: Pijama com robe
  - 10-20s: Pijama com jaqueta
  - 20-30s: Pijama com acessórios
- **Áudio:** Música fashion
- **Hashtags:** #Styling #FashionTips #FYP
- **Engajamento esperado:** 1.300+ views

#### 📱 Stories (4 stories)
- **Story 1:** Foto de Carol + "Pijama é moda!"
- **Story 2:** Vídeo mostrando robe + "Com robe fica chic!"
- **Story 3:** Vídeo mostrando jaqueta + "Ou com jaqueta!"
- **Story 4:** Poll: "Qual combinação você prefere?"

#### 🎥 TikTok Video (30-45 segundos)
- **Tipo:** Styling
- **Tema:** "Formas de Usar Pijama"
- **Roteiro:**
  - Mostrar diferentes combinações
  - Transições rápidas
  - Resultado final
- **Hashtags:** #Styling #FashionTips #FYP
- **Engajamento esperado:** 1.700+ views

---

### Quinta-feira, 11 de Fevereiro
**Persona:** Renata | **Horário:** 18:00

#### 📸 Post Instagram (Foto única)
- **Tipo:** Lifestyle/Aspiracional
- **Tema:** "Noites de Qualidade com Feminnita"
- **Hook:** "Qualidade de sono começa com o pijama certo! 😴💤"
- **Descrição:**
  - Renata em pijama, na cama
  - Ambiente aconchegante
  - Expressão de paz
- **Hashtags:** #QualidadeDeSono #PijamaConfortável #NoiteBoa #SonoReparador #Feminnita
- **CTA:** "Você dorme bem? Comente! 👇"
- **Engajamento esperado:** 500+ likes, 50+ comentários

#### 🎬 Reel Instagram (20-30 segundos)
- **Tipo:** Wellness/Sleep
- **Tema:** "Sono de Qualidade com Feminnita"
- **Roteiro:**
  - Mostrar Renata deitada
  - Conforto do pijama
  - Qualidade de sono
  - Acordar descansada
- **Áudio:** Música relaxante
- **Hashtags:** #Wellness #SonoDeQualidade #FYP
- **Engajamento esperado:** 1.200+ views

#### 📱 Stories (4 stories)
- **Story 1:** Foto de Renata + "Noite de qualidade!"
- **Story 2:** Vídeo do pijama + "Tecido macio"
- **Story 3:** Foto na cama + "Conforto total"
- **Story 4:** Poll: "Você dorme bem?" (Sim/Não)

#### 🎥 TikTok Video (30-60 segundos)
- **Tipo:** Wellness
- **Tema:** "Sono de Qualidade"
- **Roteiro:**
  - Mostrar pijama confortável
  - Qualidade de sono
  - Acordar descansada
- **Hashtags:** #Wellness #SonoDeQualidade #FYP
- **Engajamento esperado:** 1.800+ views

---

### Sexta-feira, 12 de Fevereiro
**Persona:** Vanessa | **Horário:** 19:00

#### 📸 Post Instagram (Carrossel)
- **Tipo:** Promoção/Oferta
- **Tema:** "Promoção Especial: Compre 2 e Ganhe 20% de Desconto"
- **Hook:** "Aproveite! Promoção válida apenas este fim de semana! ⏰"
- **Descrição:**
  - Foto 1: 2 pijamas diferentes
  - Foto 2: Desconto de 20%
  - Foto 3: Vanessa com 2 pijamas
  - Foto 4: Detalhes da promoção
  - Foto 5: CTA com link
- **Hashtags:** #Promoção #Desconto #OfertaEspecial #FeminnitaPromo #CompareAgora
- **CTA:** "Aproveite! Link na bio! 🛍️"
- **Engajamento esperado:** 800+ likes, 80+ comentários

#### 🎬 Reel Instagram (20-30 segundos)
- **Tipo:** Promotional
- **Tema:** "Promoção Imperdível"
- **Roteiro:**
  - Mostrar 2 pijamas
  - Desconto de 20%
  - Urgência (válido fim de semana)
  - Link na bio
- **Áudio:** Música animada
- **Hashtags:** #Promoção #Desconto #FYP
- **Engajamento esperado:** 1.500+ views

#### 📱 Stories (5 stories)
- **Story 1:** Foto de Vanessa + "Promoção! 🎉"
- **Story 2:** Vídeo mostrando 2 pijamas + "Compre 2!"
- **Story 3:** Texto "20% de desconto"
- **Story 4:** Countdown "Válido até domingo!"
- **Story 5:** Link para comprar

#### 🎥 TikTok Video (30-45 segundos)
- **Tipo:** Promotional
- **Tema:** "Promoção Especial"
- **Roteiro:**
  - Mostrar pijamas
  - Desconto
  - Urgência
- **Hashtags:** #Promoção #Desconto #FYP
- **Engajamento esperado:** 2.100+ views

---

### Sábado, 13 de Fevereiro
**Persona:** Luiza | **Horário:** 15:00

#### 📸 Post Instagram (Foto única)
- **Tipo:** Lifestyle/Casual
- **Tema:** "Sábado é Dia de Pijama"
- **Hook:** "Sábado sem pijama confortável não é sábado! 😴✨"
- **Descrição:**
  - Luiza em pijama, relaxada
  - Ambiente casual
  - Expressão de felicidade
- **Hashtags:** #SábadoÉDia #PijamaDay #ConfortoTotal #WeekendMode #VidaBoa
- **CTA:** "Como você curte seu sábado? 👇"
- **Engajamento esperado:** 600+ likes, 60+ comentários

#### 🎬 Reel Instagram (20-30 segundos)
- **Tipo:** Lifestyle
- **Tema:** "Sábado Perfeito"
- **Roteiro:**
  - Acordar no sábado
  - Colocar pijama
  - Relaxar
  - Aproveitar o dia
- **Áudio:** Música relaxante
- **Hashtags:** #SábadoÉDia #WeekendMode #FYP
- **Engajamento esperado:** 1.300+ views

#### 📱 Stories (4 stories)
- **Story 1:** Foto de Luiza + "Sábado! 🎉"
- **Story 2:** Vídeo colocando pijama + "Modo conforto"
- **Story 3:** Foto relaxando + "Aproveitando!"
- **Story 4:** Poll: "Seu sábado perfeito é...?" (Descanso/Atividades)

#### 🎥 TikTok Video (30-60 segundos)
- **Tipo:** Lifestyle
- **Tema:** "Sábado Perfeito"
- **Roteiro:**
  - Mostrar rotina de sábado
  - Pijama confortável
  - Relaxamento
- **Hashtags:** #SábadoÉDia #WeekendMode #FYP
- **Engajamento esperado:** 1.900+ views

---

### Domingo, 14 de Fevereiro (DIA DOS NAMORADOS)
**Persona:** Carol | **Horário:** 20:00

#### 📸 Post Instagram (Carrossel)
- **Tipo:** Especial Dia dos Namorados
- **Tema:** "Dia dos Namorados: Pijama em Casal"
- **Hook:** "Nada mais romântico que pijama confortável ao lado de quem você ama! 💕"
- **Descrição:**
  - Foto 1: Carol e parceiro em pijamas Feminnita
  - Foto 2: Detalhe dos pijamas
  - Foto 3: Casal relaxando
  - Foto 4: Casal na cama
  - Foto 5: Mensagem de amor
- **Hashtags:** #DiaDoNamorado #PijamaEmCasal #RomânticoFeminnita #CasalFeminnita #AmorEConforto
- **CTA:** "Presenteie seu amor com Feminnita! 💝"
- **Engajamento esperado:** 900+ likes, 90+ comentários

#### 🎬 Reel Instagram (25-35 segundos)
- **Tipo:** Romantic/Special
- **Tema:** "Dia dos Namorados com Feminnita"
- **Roteiro:**
  - 0-10s: Carol e parceiro se encontrando
  - 10-15s: Colocando pijamas Feminnita
  - 15-25s: Momentos românticos
  - 25-35s: Mensagem de amor
- **Áudio:** Música romântica
- **Hashtags:** #DiaDoNamorado #Romantic #FYP
- **Engajamento esperado:** 1.800+ views

#### 📱 Stories (6 stories)
- **Story 1:** Foto do casal + "Feliz Dia dos Namorados! 💕"
- **Story 2:** Vídeo colocando pijama + "Pijama em casal!"
- **Story 3:** Foto dos pijamas + "Combinando!"
- **Story 4:** Foto do casal relaxando + "Momento especial"
- **Story 5:** Mensagem de amor + "Vocês também?"
- **Story 6:** Link para presente + "Presenteie seu amor!"

#### 🎥 TikTok Video (30-60 segundos)
- **Tipo:** Romantic/Special
- **Tema:** "Dia dos Namorados"
- **Roteiro:**
  - Mostrar casal
  - Pijamas Feminnita
  - Momentos românticos
- **Hashtags:** #DiaDoNamorado #Romantic #FYP
- **Engajamento esperado:** 2.500+ views

---

## 📅 SEMANA 3: Comunidade & UGC (15-21 Fevereiro)

### Segunda-feira, 15 de Fevereiro
**Persona:** Renata | **Horário:** 14:30

#### 📸 Post Instagram (Carrossel)
- **Tipo:** UGC (User Generated Content)
- **Tema:** "Vocês Dormindo com Feminnita"
- **Hook:** "Adoramos ver vocês confortáveis! Obrigada por compartilhar! 💕"
- **Descrição:**
  - Foto 1: Cliente 1 em pijama Feminnita
  - Foto 2: Cliente 2 em pijama Feminnita
  - Foto 3: Cliente 3 em pijama Feminnita
  - Foto 4: Cliente 4 em pijama Feminnita
  - Foto 5: Todos os clientes juntos
- **Hashtags:** #UGC #ClientesFeminnita #ComunidadeFeminnita #VocêsDormindoComFeminnita #Obrigada
- **CTA:** "Marque-se! Use #Feminnita para aparecer aqui! 🏷️"
- **Engajamento esperado:** 700+ likes, 70+ comentários

#### 🎬 Reel Instagram (25-30 segundos)
- **Tipo:** UGC Compilation
- **Tema:** "Clientes Felizes com Feminnita"
- **Roteiro:**
  - Mostrar diferentes clientes
  - Cada um em seu pijama
  - Mensagens de satisfação
  - Logo Feminnita no final
- **Áudio:** Música alegre
- **Hashtags:** #UGC #ClientesFeminnita #ComunidadeFeminnita #FYP
- **Engajamento esperado:** 1.400+ views

#### 📱 Stories (4 stories)
- **Story 1:** Foto de Renata + "Veja nossos clientes!"
- **Story 2:** Cliente 1 em pijama
- **Story 3:** Cliente 2 em pijama
- **Story 4:** "Marque-se com #Feminnita!"

#### 🎥 TikTok Video (30-60 segundos)
- **Tipo:** UGC Compilation
- **Tema:** "Clientes Felizes"
- **Roteiro:**
  - Mostrar diferentes clientes
  - Cada um em seu pijama
  - Mensagens finais
- **Hashtags:** #UGC #ComunidadeFeminnita #FYP
- **Engajamento esperado:** 2.000+ views

---

### Terça-feira, 16 de Fevereiro
**Persona:** Vanessa | **Horário:** 20:00

#### 📸 Post Instagram (Foto única)
- **Tipo:** Community Spotlight
- **Tema:** "Cliente da Semana: Conheça a História de [Nome]"
- **Hook:** "Cada cliente tem uma história especial! Conheça a de [Nome]! 💕"
- **Descrição:**
  - Foto de cliente em pijama Feminnita
  - Depoimento pessoal
  - História de como descobriu Feminnita
- **Hashtags:** #ClienteDaSemana #HistóriaFeminnita #ComunidadeFeminnita #Inspiração
- **CTA:** "Qual é sua história? Comente! 👇"
- **Engajamento esperado:** 550+ likes, 55+ comentários

#### 🎬 Reel Instagram (25-30 segundos)
- **Tipo:** Community Spotlight
- **Tema:** "Conheça Nossa Cliente"
- **Roteiro:**
  - Apresentar cliente
  - Sua história
  - Como descobriu Feminnita
  - Depoimento final
- **Áudio:** Música inspiradora
- **Hashtags:** #ClienteDaSemana #ComunidadeFeminnita #FYP
- **Engajamento esperado:** 1.200+ views

#### 📱 Stories (4 stories)
- **Story 1:** Foto de Vanessa + "Cliente da semana!"
- **Story 2:** Foto da cliente + "Conheça [Nome]!"
- **Story 3:** Vídeo com depoimento
- **Story 4:** "Qual é sua história?"

#### 🎥 TikTok Video (30-60 segundos)
- **Tipo:** Community Spotlight
- **Tema:** "Cliente da Semana"
- **Roteiro:**
  - Apresentar cliente
  - Sua história
  - Depoimento
- **Hashtags:** #ClienteDaSemana #ComunidadeFeminnita #FYP
- **Engajamento esperado:** 1.700+ views

---

### Quarta-feira, 17 de Fevereiro
**Persona:** Luiza | **Horário:** 10:00

#### 📸 Post Instagram (Carrossel)
- **Tipo:** DIY/Creative
- **Tema:** "Ideias Criativas com Seu Pijama Feminnita"
- **Hook:** "Seu pijama é versátil! Veja essas ideias criativas! 🎨✨"
- **Descrição:**
  - Foto 1: Pijama como roupa de casa
  - Foto 2: Pijama para yoga
  - Foto 3: Pijama para meditação
  - Foto 4: Pijama para leitura
  - Foto 5: Luiza em look criativo
- **Hashtags:** #DIY #IdeiasCreativas #PijamaVersátil #CriatividadeFeminnita #Inspiração
- **CTA:** "Qual é sua ideia criativa? 👇"
- **Engajamento esperado:** 600+ likes, 60+ comentários

#### 🎬 Reel Instagram (25-30 segundos)
- **Tipo:** Creative/DIY
- **Tema:** "Formas Criativas de Usar Seu Pijama"
- **Roteiro:**
  - Mostrar diferentes usos
  - Cada um em contexto diferente
  - Transições criativas
  - Mensagem final
- **Áudio:** Música criativa
- **Hashtags:** #DIY #CreativeIdeas #FYP
- **Engajamento esperado:** 1.300+ views

#### 📱 Stories (4 stories)
- **Story 1:** Foto de Luiza + "Ideias criativas!"
- **Story 2:** Vídeo pijama para yoga
- **Story 3:** Vídeo pijama para meditação
- **Story 4:** Poll: "Qual ideia você gostou?"

#### 🎥 TikTok Video (30-45 segundos)
- **Tipo:** Creative/DIY
- **Tema:** "Formas Criativas de Usar Pijama"
- **Roteiro:**
  - Mostrar diferentes usos
  - Transições rápidas
  - Resultado final
- **Hashtags:** #DIY #CreativeIdeas #FYP
- **Engajamento esperado:** 1.800+ views

---

### Quinta-feira, 18 de Fevereiro
**Persona:** Carol | **Horário:** 18:00

#### 📸 Post Instagram (Foto única)
- **Tipo:** Lifestyle/Aspiracional
- **Tema:** "Quinta-feira é Quase Sexta"
- **Hook:** "Faltam 2 dias! Já está com saudade do seu pijama favorito? 😴✨"
- **Descrição:**
  - Carol em pijama, sorridente
  - Ambiente aconchegante
  - Expressão de felicidade
- **Hashtags:** #QuintaFeiraÉ #QuaseQuintaFeiraÉ #FimDeSemanaChegando #PijamaFavorito #Feminnita
- **CTA:** "Qual é seu pijama favorito? 👇"
- **Engajamento esperado:** 500+ likes, 50+ comentários

#### 🎬 Reel Instagram (20-30 segundos)
- **Tipo:** Lifestyle
- **Tema:** "Quinta-feira vs Sexta-feira"
- **Roteiro:**
  - Carol quinta-feira (cansada)
  - Transição
  - Carol sexta-feira (feliz, pijama)
- **Áudio:** Música animada
- **Hashtags:** #QuintaFeiraÉ #FYP #WeekendChegando
- **Engajamento esperado:** 1.200+ views

#### 📱 Stories (4 stories)
- **Story 1:** Foto de Carol + "Quinta-feira!"
- **Story 2:** Vídeo mostrando pijama + "Quase lá!"
- **Story 3:** Foto relaxando + "Saudade!"
- **Story 4:** Poll: "Você já está com saudade?"

#### 🎥 TikTok Video (30-60 segundos)
- **Tipo:** Lifestyle
- **Tema:** "Quinta-feira vs Sexta-feira"
- **Roteiro:**
  - Mostrar contraste
  - Pijama como solução
  - Mensagem final
- **Hashtags:** #QuintaFeiraÉ #FYP #WeekendChegando
- **Engajamento esperado:** 1.900+ views

---

### Sexta-feira, 19 de Fevereiro
**Persona:** Renata | **Horário:** 19:00

#### 📸 Post Instagram (Carrossel)
- **Tipo:** Promoção/Oferta
- **Tema:** "Flash Sale: 48 Horas de Desconto"
- **Hook:** "Aproveite! Apenas 48 horas de desconto especial! ⏰"
- **Descrição:**
  - Foto 1: Pijamas em destaque
  - Foto 2: Desconto de 30%
  - Foto 3: Renata com pijama
  - Foto 4: Detalhes da promoção
  - Foto 5: CTA com link
- **Hashtags:** #FlashSale #Desconto #OfertaEspecial #FeminnitaPromo #Urgência
- **CTA:** "Aproveite! Link na bio! 🛍️"
- **Engajamento esperado:** 850+ likes, 85+ comentários

#### 🎬 Reel Instagram (20-30 segundos)
- **Tipo:** Promotional
- **Tema:** "Flash Sale 48 Horas"
- **Roteiro:**
  - Mostrar pijamas
  - Desconto de 30%
  - Countdown (48 horas)
  - Link na bio
- **Áudio:** Música urgente
- **Hashtags:** #FlashSale #Desconto #FYP
- **Engajamento esperado:** 1.600+ views

#### 📱 Stories (5 stories)
- **Story 1:** Foto de Renata + "Flash Sale! 🎉"
- **Story 2:** Vídeo mostrando pijamas + "30% de desconto!"
- **Story 3:** Countdown "48 horas!"
- **Story 4:** Urgência "Aproveite!"
- **Story 5:** Link para comprar

#### 🎥 TikTok Video (30-45 segundos)
- **Tipo:** Promotional
- **Tema:** "Flash Sale"
- **Roteiro:**
  - Mostrar pijamas
  - Desconto
  - Urgência (48h)
- **Hashtags:** #FlashSale #Desconto #FYP
- **Engajamento esperado:** 2.200+ views

---

### Sábado, 20 de Fevereiro
**Persona:** Vanessa | **Horário:** 15:00

#### 📸 Post Instagram (Foto única)
- **Tipo:** Behind the Scenes
- **Tema:** "Bastidores: Como Criamos Nossas Campanhas"
- **Hook:** "Você quer saber como criamos o conteúdo que você ama? 🎬✨"
- **Descrição:**
  - Vanessa em estúdio
  - Mostrando processo criativo
  - Ambiente profissional
- **Hashtags:** #BehindTheScenes #ProcessoCriativo #FeminnitaBTS #CriaçãoDeConteúdo
- **CTA:** "Segue para mais bastidores! 👉"
- **Engajamento esperado:** 450+ likes, 45+ comentários

#### 🎬 Reel Instagram (25-35 segundos)
- **Tipo:** Behind the Scenes
- **Tema:** "Um Dia Criando Conteúdo"
- **Roteiro:**
  - 0-5s: Chegada ao estúdio
  - 5-10s: Brainstorm da equipe
  - 10-20s: Gravação de conteúdo
  - 20-30s: Edição
  - 30-35s: Resultado final
- **Áudio:** Música criativa
- **Hashtags:** #BTS #CreativeProcess #FYP
- **Engajamento esperado:** 1.100+ views

#### 📱 Stories (4 stories)
- **Story 1:** Vídeo Vanessa no estúdio + "Dia de criação!"
- **Story 2:** Foto da equipe + "Brainstorm!"
- **Story 3:** Vídeo gravando + "Quase lá!"
- **Story 4:** Resultado final + "Ficou incrível! ✨"

#### 🎥 TikTok Video (30-60 segundos)
- **Tipo:** Behind the Scenes
- **Tema:** "Um Dia Criando Conteúdo"
- **Roteiro:**
  - Mostrar processo criativo
  - Gravação
  - Edição
  - Resultado final
- **Hashtags:** #BTS #CreativeProcess #FYP
- **Engajamento esperado:** 1.800+ views

---

### Domingo, 21 de Fevereiro
**Persona:** Luiza | **Horário:** 20:00

#### 📸 Post Instagram (Carrossel)
- **Tipo:** Motivacional/Inspiracional
- **Tema:** "Domingo é Dia de Gratidão"
- **Hook:** "Obrigada por fazer parte da família Feminnita! 💕"
- **Descrição:**
  - Foto 1: Luiza em pijama, grata
  - Foto 2: Clientes felizes
  - Foto 3: Comunidade Feminnita
  - Foto 4: Mensagem de gratidão
  - Foto 5: Todas as personas juntas
- **Hashtags:** #Gratidão #ObrigadaFeminnita #ComunidadeFeminnita #Domingo #Amor
- **CTA:** "Qual é sua história com Feminnita? 👇"
- **Engajamento esperado:** 700+ likes, 70+ comentários

#### 🎬 Reel Instagram (25-30 segundos)
- **Tipo:** Motivacional/Gratidão
- **Tema:** "Obrigada por Tudo"
- **Roteiro:**
  - 0-10s: Mostrar clientes felizes
  - 10-20s: Comunidade Feminnita
  - 20-30s: Mensagem de gratidão
- **Áudio:** Música inspiradora
- **Hashtags:** #Gratidão #ObrigadaFeminnita #FYP
- **Engajamento esperado:** 1.400+ views

#### 📱 Stories (5 stories)
- **Story 1:** Foto de Luiza + "Domingo de gratidão! 💕"
- **Story 2:** Foto de clientes + "Vocês são incríveis!"
- **Story 3:** Foto da comunidade + "Essa é nossa família"
- **Story 4:** Mensagem de gratidão + "Obrigada!"
- **Story 5:** Poll: "Qual é sua história com Feminnita?"

#### 🎥 TikTok Video (30-60 segundos)
- **Tipo:** Motivacional/Gratidão
- **Tema:** "Obrigada por Tudo"
- **Roteiro:**
  - Mostrar clientes felizes
  - Comunidade
  - Mensagem de gratidão
- **Hashtags:** #Gratidão #ObrigadaFeminnita #FYP
- **Engajamento esperado:** 2.000+ views

---

## 📅 SEMANA 4: Conversão & Encerramento (22-28 Fevereiro)

### Segunda-feira, 22 de Fevereiro
**Persona:** Carol | **Horário:** 14:30

#### 📸 Post Instagram (Carrossel)
- **Tipo:** Promoção/Oferta
- **Tema:** "Últimas Peças da Coleção Verão"
- **Hook:** "Atenção! Estão acabando! Aproveite enquanto tem estoque! ⏰"
- **Descrição:**
  - Foto 1: Pijamas em destaque
  - Foto 2: Estoque limitado
  - Foto 3: Carol com pijama
  - Foto 4: Cores disponíveis
  - Foto 5: CTA com link
- **Hashtags:** #ÚltimaPeças #EstoqueLimitado #Urgência #FeminnitaPromo #CompareAgora
- **CTA:** "Aproveite! Link na bio! 🛍️"
- **Engajamento esperado:** 900+ likes, 90+ comentários

#### 🎬 Reel Instagram (20-30 segundos)
- **Tipo:** Promotional/Urgency
- **Tema:** "Últimas Peças"
- **Roteiro:**
  - Mostrar pijamas
  - Estoque limitado
  - Urgência
  - Link na bio
- **Áudio:** Música urgente
- **Hashtags:** #ÚltimaPeças #EstoqueLimitado #FYP
- **Engajamento esperado:** 1.700+ views

#### 📱 Stories (5 stories)
- **Story 1:** Foto de Carol + "Últimas peças! ⏰"
- **Story 2:** Vídeo mostrando pijamas + "Estão acabando!"
- **Story 3:** Texto "Estoque limitado"
- **Story 4:** Countdown "Aproveite!"
- **Story 5:** Link para comprar

#### 🎥 TikTok Video (30-45 segundos)
- **Tipo:** Promotional/Urgency
- **Tema:** "Últimas Peças"
- **Roteiro:**
  - Mostrar pijamas
  - Estoque limitado
  - Urgência
- **Hashtags:** #ÚltimaPeças #EstoqueLimitado #FYP
- **Engajamento esperado:** 2.300+ views

---

### Terça-feira, 23 de Fevereiro
**Persona:** Renata | **Horário:** 20:00

#### 📸 Post Instagram (Foto única)
- **Tipo:** Testimonial/Success Story
- **Tema:** "Histórias de Sucesso: Como Feminnita Mudou Minha Vida"
- **Hook:** "Essas histórias nos inspiram todos os dias! 💕"
- **Descrição:**
  - Foto de cliente em pijama Feminnita
  - Depoimento sobre transformação
  - Impacto positivo
- **Hashtags:** #HistóriaDeSuccesso #TestimonialFeminnita #Transformação #Inspiração
- **CTA:** "Qual é sua história? Comente! 👇"
- **Engajamento esperado:** 600+ likes, 60+ comentários

#### 🎬 Reel Instagram (25-30 segundos)
- **Tipo:** Testimonial/Success Story
- **Tema:** "Histórias de Sucesso"
- **Roteiro:**
  - Apresentar cliente
  - Sua história
  - Transformação
  - Depoimento final
- **Áudio:** Música inspiradora
- **Hashtags:** #HistóriaDeSuccesso #TestimonialFeminnita #FYP
- **Engajamento esperado:** 1.300+ views

#### 📱 Stories (4 stories)
- **Story 1:** Foto de Renata + "Histórias de sucesso!"
- **Story 2:** Foto da cliente + "Conheça [Nome]!"
- **Story 3:** Vídeo com depoimento
- **Story 4:** "Qual é sua história?"

#### 🎥 TikTok Video (30-60 segundos)
- **Tipo:** Testimonial/Success Story
- **Tema:** "Histórias de Sucesso"
- **Roteiro:**
  - Apresentar cliente
  - Sua história
  - Transformação
  - Depoimento
- **Hashtags:** #HistóriaDeSuccesso #TestimonialFeminnita #FYP
- **Engajamento esperado:** 1.900+ views

---

### Quarta-feira, 24 de Fevereiro
**Persona:** Vanessa | **Horário:** 10:00

#### 📸 Post Instagram (Carrossel)
- **Tipo:** Educativo/Guia
- **Tema:** "Guia Completo: Como Escolher Seu Pijama Perfeito"
- **Hook:** "Não sabe qual pijama escolher? Esse guia vai te ajudar! 🔍"
- **Descrição:**
  - Foto 1: Tipo de corpo
  - Foto 2: Preferência de tecido
  - Foto 3: Estação do ano
  - Foto 4: Estilo pessoal
  - Foto 5: Vanessa em pijama perfeito
- **Hashtags:** #GuiaDeCompra #PijamaPerfeito #EducaçãoFeminnita #ChoqueDeEstilo #Dicas
- **CTA:** "Qual é o seu pijama perfeito? 👇"
- **Engajamento esperado:** 700+ likes, 70+ comentários

#### 🎬 Reel Instagram (25-30 segundos)
- **Tipo:** Educativo/Guide
- **Tema:** "Como Escolher Seu Pijama"
- **Roteiro:**
  - Mostrar diferentes tipos
  - Características de cada um
  - Recomendação final
  - Resultado perfeito
- **Áudio:** Música informativa
- **Hashtags:** #GuiaDeCompra #PijamaPerfeito #FYP
- **Engajamento esperado:** 1.400+ views

#### 📱 Stories (4 stories)
- **Story 1:** Foto de Vanessa + "Guia completo!"
- **Story 2:** Vídeo mostrando diferentes tipos
- **Story 3:** Dicas de escolha
- **Story 4:** Poll: "Qual é o seu?"

#### 🎥 TikTok Video (30-45 segundos)
- **Tipo:** Educativo/Guide
- **Tema:** "Como Escolher Seu Pijama"
- **Roteiro:**
  - Mostrar diferentes tipos
  - Características
  - Recomendação
- **Hashtags:** #GuiaDeCompra #PijamaPerfeito #FYP
- **Engajamento esperado:** 1.900+ views

---

### Quinta-feira, 25 de Fevereiro
**Persona:** Luiza | **Horário:** 18:00

#### 📸 Post Instagram (Foto única)
- **Tipo:** Lifestyle/Aspiracional
- **Tema:** "Quinta-feira é Dia de Pijama"
- **Hook:** "Faltam 2 dias para o fim de semana! Já está com saudade? 😴✨"
- **Descrição:**
  - Luiza em pijama, relaxada
  - Ambiente aconchegante
  - Expressão de felicidade
- **Hashtags:** #QuintaFeiraÉ #FimDeSemanaChegando #PijamaFavorito #Feminnita #Conforto
- **CTA:** "Qual é seu pijama favorito? 👇"
- **Engajamento esperado:** 550+ likes, 55+ comentários

#### 🎬 Reel Instagram (20-30 segundos)
- **Tipo:** Lifestyle
- **Tema:** "Quinta-feira vs Sexta-feira"
- **Roteiro:**
  - Luiza quinta-feira (cansada)
  - Transição
  - Luiza sexta-feira (feliz, pijama)
- **Áudio:** Música animada
- **Hashtags:** #QuintaFeiraÉ #FYP #WeekendChegando
- **Engajamento esperado:** 1.200+ views

#### 📱 Stories (4 stories)
- **Story 1:** Foto de Luiza + "Quinta-feira!"
- **Story 2:** Vídeo mostrando pijama + "Quase lá!"
- **Story 3:** Foto relaxando + "Saudade!"
- **Story 4:** Poll: "Você já está com saudade?"

#### 🎥 TikTok Video (30-60 segundos)
- **Tipo:** Lifestyle
- **Tema:** "Quinta-feira vs Sexta-feira"
- **Roteiro:**
  - Mostrar contraste
  - Pijama como solução
  - Mensagem final
- **Hashtags:** #QuintaFeiraÉ #FYP #WeekendChegando
- **Engajamento esperado:** 1.800+ views

---

### Sexta-feira, 26 de Fevereiro
**Persona:** Carol | **Horário:** 19:00

#### 📸 Post Instagram (Carrossel)
- **Tipo:** Promoção/Oferta
- **Tema:** "Promoção de Fim de Mês: Compre 1 e Ganhe 50% na Segunda"
- **Hook:** "Aproveite! Promoção válida apenas este fim de semana! ⏰"
- **Descrição:**
  - Foto 1: 2 pijamas diferentes
  - Foto 2: Desconto de 50%
  - Foto 3: Carol com 2 pijamas
  - Foto 4: Detalhes da promoção
  - Foto 5: CTA com link
- **Hashtags:** #PromoçãoFimDeMês #Desconto #OfertaEspecial #FeminnitaPromo #CompareAgora
- **CTA:** "Aproveite! Link na bio! 🛍️"
- **Engajamento esperado:** 950+ likes, 95+ comentários

#### 🎬 Reel Instagram (20-30 segundos)
- **Tipo:** Promotional
- **Tema:** "Promoção Imperdível"
- **Roteiro:**
  - Mostrar 2 pijamas
  - Desconto de 50%
  - Urgência (válido fim de semana)
  - Link na bio
- **Áudio:** Música animada
- **Hashtags:** #Promoção #Desconto #FYP
- **Engajamento esperado:** 1.600+ views

#### 📱 Stories (5 stories)
- **Story 1:** Foto de Carol + "Promoção! 🎉"
- **Story 2:** Vídeo mostrando 2 pijamas + "Compre 1!"
- **Story 3:** Texto "50% na segunda"
- **Story 4:** Countdown "Válido até domingo!"
- **Story 5:** Link para comprar

#### 🎥 TikTok Video (30-45 segundos)
- **Tipo:** Promotional
- **Tema:** "Promoção Especial"
- **Roteiro:**
  - Mostrar pijamas
  - Desconto
  - Urgência
- **Hashtags:** #Promoção #Desconto #FYP
- **Engajamento esperado:** 2.200+ views

---

### Sábado, 27 de Fevereiro
**Persona:** Renata | **Horário:** 15:00

#### 📸 Post Instagram (Foto única)
- **Tipo:** Lifestyle/Casual
- **Tema:** "Sábado é Dia de Pijama"
- **Hook:** "Sábado sem pijama confortável não é sábado! 😴✨"
- **Descrição:**
  - Renata em pijama, relaxada
  - Ambiente casual
  - Expressão de felicidade
- **Hashtags:** #SábadoÉDia #PijamaDay #ConfortoTotal #WeekendMode #VidaBoa
- **CTA:** "Como você curte seu sábado? 👇"
- **Engajamento esperado:** 650+ likes, 65+ comentários

#### 🎬 Reel Instagram (20-30 segundos)
- **Tipo:** Lifestyle
- **Tema:** "Sábado Perfeito"
- **Roteiro:**
  - Acordar no sábado
  - Colocar pijama
  - Relaxar
  - Aproveitar o dia
- **Áudio:** Música relaxante
- **Hashtags:** #SábadoÉDia #WeekendMode #FYP
- **Engajamento esperado:** 1.300+ views

#### 📱 Stories (4 stories)
- **Story 1:** Foto de Renata + "Sábado! 🎉"
- **Story 2:** Vídeo colocando pijama + "Modo conforto"
- **Story 3:** Foto relaxando + "Aproveitando!"
- **Story 4:** Poll: "Seu sábado perfeito é...?" (Descanso/Atividades)

#### 🎥 TikTok Video (30-60 segundos)
- **Tipo:** Lifestyle
- **Tema:** "Sábado Perfeito"
- **Roteiro:**
  - Mostrar rotina de sábado
  - Pijama confortável
  - Relaxamento
- **Hashtags:** #SábadoÉDia #WeekendMode #FYP
- **Engajamento esperado:** 1.900+ views

---

### Domingo, 28 de Fevereiro (ÚLTIMO DIA)
**Persona:** Vanessa | **Horário:** 20:00

#### 📸 Post Instagram (Carrossel)
- **Tipo:** Retrospectiva/Resumo
- **Tema:** "Fevereiro Incrível com Feminnita"
- **Hook:** "Que mês incrível! Obrigada por estar conosco! 💕"
- **Descrição:**
  - Foto 1: Momentos do mês
  - Foto 2: Clientes felizes
  - Foto 3: Comunidade Feminnita
  - Foto 4: Todas as personas
  - Foto 5: Mensagem de gratidão
- **Hashtags:** #RetrospectivaFevereiro #ObrigadaFeminnita #ComunidadeFeminnita #Amor #Gratidão
- **CTA:** "Qual foi seu momento favorito? 👇"
- **Engajamento esperado:** 800+ likes, 80+ comentários

#### 🎬 Reel Instagram (30-35 segundos)
- **Tipo:** Retrospective/Summary
- **Tema:** "Fevereiro Incrível"
- **Roteiro:**
  - 0-10s: Momentos do mês
  - 10-20s: Clientes felizes
  - 20-30s: Comunidade
  - 30-35s: Mensagem final
- **Áudio:** Música inspiradora
- **Hashtags:** #RetrospectivaFevereiro #ObrigadaFeminnita #FYP
- **Engajamento esperado:** 1.500+ views

#### 📱 Stories (6 stories)
- **Story 1:** Foto de Vanessa + "Fim de fevereiro! 💕"
- **Story 2:** Momentos do mês + "Que incrível!"
- **Story 3:** Clientes felizes + "Vocês são tudo!"
- **Story 4:** Comunidade + "Essa é nossa família"
- **Story 5:** Mensagem de gratidão + "Obrigada!"
- **Story 6:** Preview de março + "Vem mais novidade!"

#### 🎥 TikTok Video (30-60 segundos)
- **Tipo:** Retrospective/Summary
- **Tema:** "Fevereiro Incrível"
- **Roteiro:**
  - Mostrar momentos do mês
  - Clientes felizes
  - Comunidade
  - Mensagem final
- **Hashtags:** #RetrospectivaFevereiro #ObrigadaFeminnita #FYP
- **Engajamento esperado:** 2.100+ views

---

## 📊 Métricas de Sucesso

### Objetivos do Mês
- ✅ Aumentar seguidores em 30% (de 45K para 58.5K)
- ✅ Aumentar engajamento em 25% (de 8.2% para 10.25%)
- ✅ Aumentar vendas em 40% (de R$ 2.294.000 para R$ 3.211.600)
- ✅ Alcançar 100K impressões por semana

### KPIs por Plataforma

**Instagram:**
- Posts: 28 (4 por semana)
- Reels: 28 (4 por semana)
- Stories: 120+ (17 por dia)
- Engajamento esperado: 15.000+ likes, 1.500+ comentários
- Alcance esperado: 400K+ impressões

**TikTok:**
- Vídeos: 28 (4 por semana)
- Views esperadas: 50K+ por vídeo
- Alcance esperado: 1.4M+ impressões

### Investimento em Publicidade
- **Google Ads:** R$ 2.000
- **Meta Ads (Instagram/Facebook):** R$ 2.500
- **TikTok Ads:** R$ 500
- **Total:** R$ 5.000

### ROI Esperado
- Investimento: R$ 5.000
- Retorno esperado: R$ 128.464 (25.7x)
- ROI: 2.469%

---

## 🎯 Dicas Importantes

1. **Consistência:** Poste todos os dias nos horários indicados
2. **Engajamento:** Responda todos os comentários nos primeiros 30 minutos
3. **Comunidade:** Interaja com contas de clientes e influenciadores
4. **Análise:** Monitore métricas diariamente e ajuste conforme necessário
5. **Criatividade:** Teste novos formatos e sons
6. **Autenticidade:** Mantenha a voz única de cada persona
7. **Urgência:** Use countdowns e promoções para aumentar conversão
8. **UGC:** Sempre reposte conteúdo de clientes
9. **Educação:** Forneça valor através de dicas e tutoriais
10. **Diversidade:** Alterne entre tipos de conteúdo

---

## 📞 Contato & Suporte

Para dúvidas sobre este roteiro, entre em contato com:
- **Email:** marketing@feminnita.com
- **WhatsApp:** (11) 99999-9999
- **Instagram:** @feminnita_pijamas

---

**Criado em:** 31 de Janeiro de 2026
**Válido para:** Fevereiro de 2026
**Próxima atualização:** 01 de Março de 2026

