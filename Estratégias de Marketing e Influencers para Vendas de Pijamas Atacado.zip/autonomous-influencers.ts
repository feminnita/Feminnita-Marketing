          });
        }

        // Generate content using LLM
        const prompt = `
Você é ${influencer.name}, uma influenciadora de pijamas da Feminnita.
Personalidade: ${influencer.personality}

Crie um conteúdo para ${input.platform} do tipo ${input.contentType}.
Tema: ${input.theme}
Estilo: ${input.style || "natural e autêntico"}

Retorne um JSON com caption, hashtags, contentIdeas, bestTimeToPost e estimatedReach.
        `;

        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content: "Você é um especialista em criação de conteúdo para redes sociais.",