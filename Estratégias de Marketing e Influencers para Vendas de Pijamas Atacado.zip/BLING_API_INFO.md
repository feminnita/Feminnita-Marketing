# Informações sobre API do Bling

## Autenticação

A API do Bling usa **OAuth 2.0** com Bearer tokens.

### Como usar:
```
GET /Api/v3/[caminho_da_api_desejada]
Host: https://api.bling.com.br
Header: Authorization: Bearer [access_token]
```

### Exemplo com cURL:
```bash
curl --location --request GET 'https://api.bling.com.br/Api/v3/contatos' \
  --header 'Authorization: Bearer 4a9de71b8aaf91c8ebbf830888354d5479e83a01'
```

## Endpoints Principais

- **Produtos**: `/Api/v3/produtos`
- **Contatos**: `/Api/v3/contatos`
- **Pedidos**: `/Api/v3/pedidos`
- **Notas Fiscais**: `/Api/v3/notas-fiscais`

## Métodos HTTP

- **GET**: Obter dados
- **POST**: Criar dados
- **PUT**: Atualizar todos os dados
- **PATCH**: Atualizar parcialmente
- **DELETE**: Remover dados

## Próximo Passo

Você precisa:
1. Acessar https://developer.bling.com.br
2. Criar uma aplicação OAuth
3. Gerar um access_token
4. Usar esse token para fazer requisições à API

**Você conseguiu criar a aplicação e gerar o access_token?**
