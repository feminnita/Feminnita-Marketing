# 🔐 Guia Completo: Como Gerar e Encontrar Todas as Credenciais

## 1️⃣ BLING ERP - Gerar API Key

### Passo a Passo:
1. Acesse: https://www.bling.com.br
2. Faça login com sua conta
3. Clique em **"Configurações"** (engrenagem no canto superior direito)
4. Vá em **"Integrações"** ou **"API"**
5. Procure por **"Chave de API"** ou **"API Key"**
6. Clique em **"Gerar Nova Chave"** ou **"Criar API Key"**
7. Copie a chave gerada (formato: `xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`)
8. **IMPORTANTE:** Salve em local seguro (você precisará adicionar no sistema)

### O que você receberá:
- **API Key**: `abc123def456ghi789jkl012mno345pqr`
- **URL Base Bling**: `https://www.bling.com.br/Api/v2`

---

## 2️⃣ FACEBOOK/INSTAGRAM - Encontrar Credenciais

### Passo a Passo:

#### A) Encontrar Facebook Pixel ID:
1. Acesse: https://business.facebook.com
2. Faça login
3. Vá em **"Configurações"** → **"Dados Comerciais"** → **"Pixels"**
4. Clique no seu pixel
5. Copie o **"ID do Pixel"** (números)

#### B) Encontrar Instagram Business Account ID:
1. Em Facebook Business Manager, vá em **"Contas"** → **"Contas do Instagram"**
2. Selecione sua conta Instagram
3. Copie o **"ID da Conta"** (números grandes)

#### C) Gerar Token de Acesso (Access Token):
1. Em Facebook Business Manager, vá em **"Configurações"** → **"Usuários"**
2. Clique em seu usuário
3. Vá em **"Tokens de Acesso"** → **"Gerar Token"**
4. Selecione **"Instagram Graph API"**
5. Copie o token gerado

### O que você receberá:
- **Facebook Pixel ID**: `123456789012345`
- **Instagram Account ID**: `987654321098765`
- **Access Token**: `EAAbBaCDEFGHIJKLMNOPQRSTUVWXYZ...`

---

## 3️⃣ TIKTOK ADS - Encontrar Credenciais

### Passo a Passo:

#### A) Acessar TikTok Ads Manager:
1. Acesse: https://ads.tiktok.com
2. Faça login com sua conta TikTok
3. Clique em **"Configurações"** (engrenagem)

#### B) Encontrar Advertiser ID:
1. Em Configurações, vá em **"Informações da Conta"**
2. Copie o **"ID do Anunciante"** (números)

#### C) Gerar Access Token:
1. Em Configurações, vá em **"Integrações"** ou **"API"**
2. Clique em **"Gerar Token"**
3. Copie o **"Access Token"** gerado

### O que você receberá:
- **Advertiser ID**: `1234567890123456`
- **Access Token**: `act_1234567890123456_abcdefghijklmnop...`

---

## 4️⃣ GOOGLE ADS - Encontrar Credenciais

### Passo a Passo:

#### A) Acessar Google Ads:
1. Acesse: https://ads.google.com
2. Faça login
3. Clique em **"Ferramentas"** (engrenagem) → **"Configurações"**

#### B) Encontrar Customer ID:
1. No canto superior direito, veja o **"ID da Conta"** (formato: `123-456-7890`)
2. Copie este ID

#### C) Gerar Google API Key:
1. Acesse: https://console.cloud.google.com
2. Crie um novo projeto
3. Vá em **"APIs e Serviços"** → **"Credenciais"**
4. Clique em **"Criar Credencial"** → **"Chave de API"**
5. Copie a chave gerada

### O que você receberá:
- **Customer ID**: `123-456-7890`
- **API Key**: `AIzaSyDxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`

---

## 5️⃣ META (Facebook + Instagram Ads) - Encontrar Credenciais

### Passo a Passo:

#### A) Acessar Meta Business Suite:
1. Acesse: https://business.facebook.com
2. Faça login

#### B) Encontrar Business Account ID:
1. Clique em **"Configurações"** → **"Informações da Conta"**
2. Copie o **"ID da Conta Comercial"** (números)

#### C) Encontrar Ad Account ID:
1. Vá em **"Contas"** → **"Contas de Anúncios"**
2. Clique na sua conta de anúncios
3. Copie o **"ID da Conta de Anúncios"** (formato: `act_123456789`)

#### D) Gerar Access Token:
1. Em Configurações, vá em **"Usuários"** → **"Tokens de Acesso"**
2. Clique em **"Gerar Token"**
3. Selecione **"Ads Management"** e **"Pages"**
4. Copie o token

### O que você receberá:
- **Business Account ID**: `123456789012345`
- **Ad Account ID**: `act_123456789012345`
- **Access Token**: `EAAbBaCDEFGHIJKLMNOPQRSTUVWXYZ...`

---

## 6️⃣ CANVA - Vincular Conta Oficial

### Passo a Passo:

#### A) Criar Canva Team (se não tiver):
1. Acesse: https://www.canva.com
2. Faça login
3. Clique em **"Criar um time"** (Team)
4. Dê um nome ao time (ex: "Feminnita")

#### B) Gerar Canva API Key:
1. Acesse: https://www.canva.com/developers
2. Clique em **"Criar Aplicação"**
3. Preencha os dados da aplicação
4. Copie a **"API Key"** gerada
5. Copie também o **"API Secret"**

### O que você receberá:
- **API Key**: `xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`
- **API Secret**: `yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy`
- **Team ID**: `zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz`

---

## 7️⃣ TRAY - Configurar API

### Passo a Passo:

#### A) Acessar Tray Admin:
1. Acesse: https://admin.tray.com.br
2. Faça login

#### B) Gerar API Key:
1. Vá em **"Configurações"** → **"Integrações"** ou **"API"**
2. Clique em **"Gerar Chave de API"**
3. Copie a chave gerada

#### C) Encontrar Store ID:
1. Em Configurações, procure por **"Informações da Loja"**
2. Copie o **"ID da Loja"** (números)

### O que você receberá:
- **API Key**: `xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`
- **Store ID**: `123456`
- **URL Base Tray**: `https://api.tray.com.br`

---

## 📋 Resumo das Credenciais Necessárias

| Plataforma | Credencial | Formato | Onde Usar |
|-----------|-----------|---------|-----------|
| **Bling** | API Key | `abc123...` | Integração Estoque |
| **Facebook** | Pixel ID | `123456789` | Rastreamento |
| **Instagram** | Account ID | `987654321` | Automação |
| **Instagram** | Access Token | `EAAbBa...` | Autenticação |
| **TikTok** | Advertiser ID | `1234567890` | Campanhas |
| **TikTok** | Access Token | `act_1234...` | Autenticação |
| **Google** | Customer ID | `123-456-7890` | Campanhas |
| **Google** | API Key | `AIzaSy...` | Autenticação |
| **Meta** | Business ID | `123456789` | Gerenciamento |
| **Meta** | Ad Account ID | `act_123...` | Campanhas |
| **Meta** | Access Token | `EAAbBa...` | Autenticação |
| **Canva** | API Key | `xxx...` | Integração |
| **Canva** | API Secret | `yyy...` | Integração |
| **Tray** | API Key | `xxx...` | Integração Pedidos |
| **Tray** | Store ID | `123456` | Integração |

---

## ⚠️ SEGURANÇA - Importante!

1. **NUNCA compartilhe** suas credenciais
2. **NUNCA coloque** credenciais em código
3. **SEMPRE use** variáveis de ambiente (.env)
4. **SEMPRE regenere** tokens se comprometidos
5. **SEMPRE revogue** acesso de aplicações antigas

---

## ✅ Próximo Passo

Após gerar todas as credenciais, você vai:
1. Adicionar no sistema via **"Configurações"** → **"Integrações"**
2. Testar cada integração
3. Ativar automações

**Vou aguardar você gerar as credenciais e depois integro tudo no sistema!** 🚀
