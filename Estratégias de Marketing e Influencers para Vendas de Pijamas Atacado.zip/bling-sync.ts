 * Router tRPC para sincronização de dados com Bling\n */

import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import {
  sincronizarProdutosBling,
  sincronizarPedidosBling,
  sincronizarContatosBling,
  sincronizarEstoqueBling,
  obterProdutoBling,
  obterPedidoBling,
  atualizarEstoqueBling,
  BlingAPIError,
  formatarErroBling,
} from "../integrations/bling-api";

export const blingSyncRouter = router({
  /**
   * Sincroniza produtos do Bling
   */
  produtos: protectedProcedure
    .input(
      z.object({
        accessToken: z.string(),
        pagina: z.number().optional().default(1),
        limite: z.number().optional().default(100),
      })
    )
    .mutation(async ({ input }: any) => {
      try {
        const response = await sincronizarProdutosBling(
          input.accessToken,
          input.pagina,
          input.limite
        );

        return {
          sucesso: true,
          total: response.data?.length || 0,
          produtos: response.data || [],
          paginacao: response.paging,
        };
      } catch (error: unknown) {
        if (error instanceof BlingAPIError) {
          throw new Error(formatarErroBling(error));
        }
        throw error;
      }
    }),