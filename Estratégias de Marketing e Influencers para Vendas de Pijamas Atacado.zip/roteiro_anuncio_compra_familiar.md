# Roteiro de Vídeo para Anúncio - Compra Familiar em Atacado

## Informações Gerais do Vídeo

**Título:** "Pijama para Toda a Família por MENOS que Uma Blusa"  
**Duração:** 30 segundos (formato TikTok/Reels otimizado)  
**Objetivo:** Captar famílias que buscam economizar, mostrando valor real e conforto compartilhado  
**Público-Alvo:** Mães 25-50 anos, responsáveis por compras familiares, buscando economia  
**Formato:** Problema (Preço Alto) → Solução (Compra em Familia) → Resultado (Economia + Conforto)  
**Estilo Visual:** Caloroso, familiar, aspiracional, real  
**Tom de Voz:** Amigável, entusiasmado, confiável, maternal  
**Plataforma:** TikTok, Instagram Reels, Facebook  
**Resolução:** 1080x1920px (vertical)  
**FPS:** 30fps  
**Áudio:** Música alegre + voz em off maternal  

---

## Estrutura Narrativa

O vídeo segue a narrativa de **economia inteligente e amor familiar**. Começa mostrando o problema (preço alto de pijamas em varejo), apresenta a solução (comprar em família com Feminnita), demonstra a economia real com números específicos, e termina com imagem aspiracional de família confortável e feliz.

---

## Timeline Detalhada (30 segundos)

### Segundo 0-3: GANCHO (Problema Relatable)

**Descrição de Cena:**  
Mãe em loja de shopping, olhando preço de pijama em manequim. Expressão de choque/preocupação. Close-up no preço: "R$ 149,90 por pijama". Fundo: loja de roupas com iluminação de shopping.

**Áudio:**  
Música começa (algo alegre mas com tom de "problema", como um "plot twist" musical). Volume: 60%. Voz em off feminina (maternal, preocupada): "Pijama de qualidade para toda a família? Caro demais..."

**Texto na Tela:**  
Aparece em letras grandes, vermelhas:  
**"R$ 149,90 POR PIJAMA"**  
Depois aparece menor: **"POR PESSOA"**  
(Fonte: Poppins Bold, animação: slide da direita com efeito de "choque")

**Efeitos Visuais:**  
Zoom leve no rosto. Quando o preço aparece, há um efeito de "shake" (tremor) na tela para transmitir choque. Filtro leve de dessaturação para transmitir preocupação.

**Dica de Produção:**  
Capture a expressão genuína de choque. Este é o momento de criar empatia com o público. A mãe deve parecer genuinamente preocupada com o preço.

---

### Segundo 3-7: PROBLEMA EXPANDIDO (Cálculo de Custo)

**Descrição de Cena:**  
Montagem rápida de 4 cenas (1 segundo cada):  
1. Mãe calculando em celular/papel (close-up nas mãos)  
2. Imagem de família (pais + 2-3 filhos) com números aparecendo  
3. Mãe com expressão de "isso é muito caro"  
4. Mãe colocando pijama de volta no manequim (desistindo)

**Áudio:**  
Voz em off: "Para uma família de 4 pessoas, seriam R$ 600 em pijamas... E ainda faltam mais pessoas!"  
Música mantém tom de preocupação.

**Texto na Tela:**  
Sequência de cálculos aparecendo:  
**"4 PESSOAS × R$ 149,90 = R$ 599,60"**  
Depois aparece: **"E AINDA FALTAM AVÓS, TIOS..."**  
(Animação: números aparecem com efeito de "pop", depois fade out)

**Efeitos Visuais:**  
Transições rápidas entre cenas (0.5s). Números aparecem com efeito de "vibração" para transmitir preocupação. Cores mantêm tom mais frio/cinzento.

**Dica de Produção:**  
Use números reais que o público possa calcular. Deixe claro que é "muito caro" para uma família inteira.

---

### Segundo 7-12: VIRADA (Descoberta da Solução)

**Descrição de Cena:**  
Mãe recebe notificação no celular (ou vê post no Instagram). Seu rosto muda de expressão para curiosidade/esperança. Close-up na tela do celular mostrando: "Pijamas Feminnita - Compre em Família e Economize até 60%!"

**Áudio:**  
Música muda para tom mais positivo e alegre. Voz em off (entusiasmada): "Até que descobri a Feminnita... E tudo mudou!"  
Som de notificação (ding).

**Texto na Tela:**  
**"DESCOBRI A FEMINNITA"**  
Depois aparece: **"COMPRE EM FAMÍLIA"**  
(Animação: slide de baixo para cima, com efeito de brilho)

**Efeitos Visuais:**  
Transição suave com zoom na notificação. Quando a expressão muda, há um flash de luz branca (esperança). Saturação volta ao normal. Cores ficam mais vibrantes.

**Dica de Produção:**  
A mudança de expressão é crucial. Capture genuinamente a alegria/esperança. O momento deve parecer real e relatable.

---

### Segundo 12-20: RESULTADO (Economia Real + Família Feliz)

**Descrição de Cena:**  
Montagem de 4 cenas (2 segundos cada):

1. **Cena 1 (2s):** Mãe mostrando pijamas coloridos e bonitos em sua cama. Close-up nos pijamas em diferentes cores (rosa, azul, verde, amarelo). Ela está sorrindo, tocando os pijamas com carinho.

2. **Cena 2 (2s):** Montagem rápida de família inteira usando pijamas Feminnita. Pai, mãe, filhos, até avó. Todos sorrindo, abraçados, em ambiente aconchego (sala, cama, sofá). Cenas de conforto e felicidade.

3. **Cena 3 (2s):** Close-up em celular mostrando cálculo de economia. Números aparecendo: "1 pijama: R$ 39,90 (em vez de R$ 149,90)" → "4 pijamas: R$ 159,60 (em vez de R$ 599,60)" → "ECONOMIA: R$ 440!"

4. **Cena 4 (2s):** Mãe com expressão de satisfação, abraçando os filhos, todos em pijamas, rindo, felizes. Luz quente, ambiente aconchego.

**Áudio:**  
Voz em off (entusiasmada, maternal): "Consegui pijamas de qualidade para TODA a minha família por apenas R$ 39,90 cada! Economizei R$ 440 em uma compra!"  
Música atinge pico de alegria. Sons de "sucesso" (ding positivo).

**Texto na Tela:**  
Sequência de números aparecendo:  
**"1 PIJAMA: R$ 39,90"** → **"4 PIJAMAS: R$ 159,60"** → **"ECONOMIA: R$ 440!"**  
Depois aparece em letras maiores: **"QUALIDADE + ECONOMIA + FAMÍLIA FELIZ"**  
(Animação: números com efeito "pop", depois confete digital quando economia aparece)

**Efeitos Visuais:**  
Transições suaves entre cenas (0.5s). Cores vibrantes e quentes. Quando a economia aparece, há efeito de confete digital. Há um efeito de "glow" ao redor da família feliz. Música atinge o pico.

**Dica de Produção:**  
Este é o coração do vídeo. Mostre genuinamente a felicidade familiar. Use luz quente e aconchego. A economia deve parecer REAL e SIGNIFICATIVA. Capture momentos reais de família se possível (pais, filhos, até avós).

---

### Segundo 20-25: COMO FUNCIONA (Simplicidade)

**Descrição de Cena:**  
Montagem de 3 cenas rápidas (1.5 segundos cada) mostrando o processo:

1. **Cena 1 (1.5s):** Mãe no celular, clicando em link. Tela mostra: "Escolha quantos pijamas precisa" com números (5, 10, 15, 20+). Mãe swiping através das opções.

2. **Cena 2 (1.5s):** Tela mostra catálogo de cores/modelos. Mãe e filhos escolhendo juntos, apontando para tela, rindo, decidindo qual cor cada um quer.

3. **Cena 3 (1.5s):** Caixa de pijamas chegando na porta. Mãe e filhos abrindo a caixa, pegando os pijamas, experimentando, felizes. Todos se abraçando.

**Áudio:**  
Voz em off (clara, didática, alegre): "É simples: 1) Escolha quantos pijamas sua família precisa, 2) Escolha as cores e modelos, 3) Receba em casa em 24-48 horas!"  
Música mantém tom positivo e energético.

**Texto na Tela:**  
Aparece em sequência (1.5 segundos cada):  
**"1. ESCOLHA A QUANTIDADE"** → **"2. ESCOLHA AS CORES"** → **"3. RECEBA EM CASA"**  
(Fonte: Poppins Bold, animação: slide de baixo para cima)

**Efeitos Visuais:**  
Transições suaves entre cenas. Números aparecem com efeito de "pop". Há um efeito de "highlight" nos botões/elementos interativos. Cores mantêm tom quente e aconchego.

**Dica de Produção:**  
Mantenha a simplicidade. Mostre que é FÁCIL envolver toda a família no processo. Use cenas de família decidindo juntas (crianças apontando, pais ajudando).

---

### Segundo 25-28: PROVA SOCIAL + BENEFÍCIOS

**Descrição de Cena:**  
Corte para depoimentos rápidos de 2-3 mães (pode ser a mesma pessoa em diferentes roupas/ambientes, ou pessoas diferentes). Cada uma fala 1 frase rápida.

1. **Pessoa 1 (1s):** "Minha família toda usa Feminnita! Qualidade impecável!" (sorrindo para câmera, mostrando pijamas)
2. **Pessoa 2 (1s):** "Economizei mais de R$ 500 em uma compra!" (mostrando thumbs up, feliz)
3. **Pessoa 3 (1s):** "Meus filhos pedem para usar todo dia!" (abraçando filhos, rindo)

**Áudio:**  
Voz em off: "Milhares de famílias já confiam na Feminnita..."  
Música continua energética. Cada depoimento tem um "ding" de notificação.

**Texto na Tela:**  
Aparece acima de cada pessoa:  
**"⭐ MÃE VERIFICADA"**  
(Animação: fade in)

**Efeitos Visuais:**  
Transições rápidas (0.3s) entre depoimentos. Cada pessoa tem um "frame" ao redor (como um card de TikTok). Há um efeito de "like" (coração) que aparece durante cada depoimento.

**Dica de Produção:**  
Autenticidade é chave. Use mães reais (amigas, família, clientes reais). Sorrisos genuínos. Se usar a mesma pessoa, mude roupas/ambiente.

---

### Segundo 28-30: CALL-TO-ACTION (CTA) + FECHAMENTO

**Descrição de Cena:**  
Mãe (ou toda a família) olhando diretamente para câmera, com expressão calorosa e convidativa. Ambiente aconchego, bem iluminado. Todos em pijamas Feminnita, abraçados, felizes.

**Áudio:**  
Voz em off (calorosa, convidativa): "Reúna sua família e economize! Clique no link da bio e comece AGORA!"  
Música atinge o pico de alegria. Som de "sucesso" (como um ding positivo).

**Texto na Tela:**  
Aparece em letras GRANDES e destacadas:  
**"REÚNA SUA FAMÍLIA"**  
Depois aparece:  
**"CLIQUE NO LINK DA BIO"**  
Depois aparece menor:  
**"ECONOMIZE AGORA! 👨‍👩‍👧‍👦"**  
(Animação: zoom in para o texto principal, depois fade out)

**Efeitos Visuais:**  
Close-up na família. Há um efeito de "glow" ao redor deles (luz de felicidade/aconchego). Quando o CTA aparece, há um efeito de "pulse" (pulsação) no texto para atrair atenção. Cores quentes e aconchego.

**Dica de Produção:**  
Crie intimidade e calidez. A expressão deve ser confiante mas acessível. O CTA é o momento final crítico - deixe claro e visível. A imagem de família feliz é poderosa.

---

## Especificações Técnicas

### Áudio

**Música de Fundo:**  
- Recomendação: Áudio viral do TikTok com tema familiar/alegre (ex: "Good as Hell" remix, "Walking on Sunshine" remix, ou qualquer áudio de sucesso com >5M usos que transmita felicidade e união)
- Volume: 60% durante todo o vídeo (mais baixo que o "renda extra" para permitir voz em off clara)
- Duração: 30 segundos
- Estilo: Upbeat, alegre, caloroso, familiar

**Voz em Off:**  
- Voz: Feminina, maternal, confiante, clara, calorosa
- Tom: Entusiasmado mas genuíno, não artificial
- Velocidade: Moderada (não muito rápida, não muito lenta)
- Volume: 80% (mais alto que a música)
- Efeito: Sem reverb excessivo, voz clara e direta
- Duração total de fala: ~20 segundos

**Efeitos Sonoros:**  
- Notificação (ding): Quando descoberta da solução, quando números aparecem
- Som de caixa abrindo: Quando pijamas chegam
- Som de sucesso: Quando CTA aparece
- Volume: 40-50%

### Visuais

**Cores Principais:**  
- Rosa Feminnita: #E84C89 (usar em acentos, texto principal)
- Branco: #FFFFFF (fundo de texto, clareza)
- Preto: #000000 (contorno de texto)
- Cores Quentes: Laranja, amarelo, tons de ouro (para transmitir aconchego)
- Cores dos Pijamas: Vibrantes (rosa, azul, verde, amarelo)

**Tipografia:**  
- Fonte Principal: Poppins Bold (Google Fonts)
- Tamanho: 40-48px para texto principal, 24-32px para texto secundário
- Contorno: Preto 2-3px para garantir legibilidade
- Sombra: Leve (blur 2px, opacidade 30%)

**Transições:**  
- Tipo: Cortes rápidos (0.3-0.5s), slides suaves
- Duração: Manter rápido mas não frenético
- Efeito: Transições suaves para transmitir aconchego

**Filtros/Efeitos:**  
- Primeiros 7 segundos: Saturação reduzida (cinza) para transmitir problema
- Segundo 7 em diante: Cores vibrantes e quentes para transmitir solução/felicidade
- Brilho/Glow: Usar em momentos-chave (virada, família feliz, CTA)
- Confete Digital: Quando economia aparece

### Resolução e Formato

**Resolução:** 1080x1920px (padrão TikTok vertical)  
**Aspect Ratio:** 9:16  
**FPS:** 30fps  
**Codec:** H.264  
**Tamanho de Arquivo:** Máximo 287.6MB  
**Duração:** Exatamente 30 segundos  

---

## Dicas de Produção e Gravação

### Equipamento Necessário

**Mínimo:**  
- Celular com câmera decente
- Tripé ou suporte
- Luz natural (janela) ou ring light
- Microfone externo (opcional mas recomendado)

**Ideal:**  
- Câmera mirrorless ou DSLR
- Microfone lavalier ou shotgun
- Iluminação profissional (ring light + softbox)
- Tripé de qualidade

### Ambiente de Gravação

**Ambiente Familiar (Sala/Quarto):**  
- Aconchego, luz quente
- Elementos de "lar" (sofá, cama, plantas)
- Luz natural preferível (gravar perto de janela)
- Se usar luz artificial, use temperatura quente (3000K)

**Iluminação:**  
- Luz frontal para iluminar rostos
- Evitar sombras duras
- Se usar ring light, posicione na altura dos olhos
- Teste antes de gravar

### Técnica de Gravação

**Enquadramento:**  
- Primeiros 3 segundos: Close-up no rosto (queixo até topo da cabeça)
- Cenas de família: Wide shot (todos os membros visíveis) ou medium shot
- CTA final: Wide shot com toda a família (ou close-up se apenas mãe)

**Movimento de Câmera:**  
- Mantenha câmera estável (use tripé)
- Movimentos suaves de zoom
- Evitar movimento excessivo

**Expressões e Atuação:**  
- Primeira cena (preocupação): Expressão genuína de choque com preço
- Virada (esperança): Mudança rápida para curiosidade/esperança
- Cenas de família: Natural, genuinamente feliz
- CTA final: Calorosa, convidativa, confiante

### Edição

**Software Recomendado:**  
- Gratuito: CapCut, DaVinci Resolve
- Pago: Adobe Premiere Pro, Final Cut Pro

**Passos de Edição:**  
1. Importar clips de vídeo
2. Organizar em sequência
3. Cortar para duração exata (30s)
4. Adicionar transições (0.3-0.5s)
5. Adicionar texto com animações
6. Adicionar áudio (música + voz em off)
7. Balancear volumes
8. Adicionar efeitos visuais
9. Exportar em 1080x1920px, 30fps, H.264

---

## Variações e A/B Testing

### Versão Alternativa 1: "Avós + Netos"

Se a primeira versão não gerar muitos cliques, tente esta variação que enfatiza gerações:

- Mostrar avós comprando pijamas para netos
- Enfatizar "economia para aposentados"
- Cenas de avós e netos usando pijamas juntos
- CTA: "Reúna gerações com conforto e economia"

**Razão:** Algumas famílias incluem avós. Esta versão amplia o público.

### Versão Alternativa 2: "Casal + Filhos"

Se o público é mais jovem, tente esta variação:

- Focar em casal novo com filhos pequenos
- Enfatizar "economia para pais de primeira viagem"
- Cenas de brincadeiras em pijamas
- CTA: "Pijamas confortáveis para toda a família"

**Razão:** Casais jovens com filhos pequenos têm poder de compra e buscam economia.

---

## Estratégia de Postagem e Promoção

### Quando Postar

**Melhor Horário:** 19h-21h (noite, quando famílias estão em casa)  
**Melhor Dia:** Quinta a Domingo (fim de semana, quando famílias planejam compras)  
**Frequência:** Postar 1-2 vezes por semana  

### Como Promover

1. **Postar no TikTok:** Use hashtags #FamiliaFeliz #PijamaParaTodos #EconomiaEmFamilia
2. **Compartilhar no Instagram Reels:** Mesmo vídeo, legenda adaptada
3. **Compartilhar no Facebook:** Público mais velho (pais/avós)
4. **Pedir Shares:** "Compartilhe com sua família!"
5. **Responder Comentários:** Engage rapidamente

### Métricas para Acompanhar

- **Visualizações:** Meta mínima 15K views (público familiar é maior)
- **Completion Rate:** Meta mínima 55% (vídeo emocional retém mais)
- **Cliques no Link:** Meta mínima 150 cliques
- **Compartilhamentos:** Meta mínima 80 shares (vídeo familiar é compartilhado mais)
- **Comentários:** Meta mínima 30 comentários
- **Conversão:** Meta mínima 15 registros (de 150 cliques)

---

## Dicas Finais para Maximizar Sucesso

### 1. Autenticidade Familiar

Não tente parecer perfeita. Famílias reais têm imperfeições. Use famílias reais (amigas, clientes, família própria).

### 2. Números Específicos Convertem

"Economizei R$ 440" converte melhor que "Economize muito". Números específicos parecem mais reais.

### 3. Emoção é Chave

Vídeos sobre família e economia tocam emocionalmente. Use isso a seu favor. Mostre genuinamente a felicidade.

### 4. Velocidade + Aconchego

Mantenha transições rápidas (TikTok adora) mas transmita aconchego (cores quentes, luz natural).

### 5. CTA Clara e Emocional

"Reúna sua família e economize" é mais poderoso que "Compre agora". Apele à emoção.

### 6. Teste Múltiplas Versões

Poste a versão principal, depois teste as variações. Aprenda qual funciona melhor.

### 7. Engaje com Famílias

Responda comentários de mães/pais. Agradeça shares. Crie comunidade.

### 8. Mantenha Consistência

Se funcionar bem, crie variações similares. Consistência aumenta reconhecimento.

---

## Checklist Final Antes de Postar

- [ ] Vídeo tem exatamente 30 segundos
- [ ] Áudio está sincronizado com vídeo
- [ ] Texto está legível em celular
- [ ] Cores são quentes e aconchego
- [ ] Transições são suaves
- [ ] CTA é claro e emocional
- [ ] Link na bio está funcional
- [ ] Hashtags estão relevantes
- [ ] Legenda está atrativa e emocional
- [ ] Vídeo foi testado em diferentes celulares
- [ ] Áudio foi testado (volume correto)
- [ ] Você está satisfeita com o resultado final

---

## Comparação: Renda Extra vs Compra Familiar

| Aspecto | Renda Extra | Compra Familiar |
| :--- | :--- | :--- |
| **Público** | Mulheres 18-45, desempregadas | Mães 25-50, responsáveis por compras |
| **Problema** | Sem renda | Preço alto |
| **Solução** | Revender pijamas | Comprar em família |
| **Resultado** | R$ 2.500 em 1 mês | R$ 440 de economia |
| **Tom** | Entusiasmado, esperançoso | Caloroso, familiar |
| **Cores** | Rosa/Laranja (urgência) | Quentes/Ouro (aconchego) |
| **Música** | Energética, viral | Alegre, familiar |
| **CTA** | "Clique no link da bio" | "Reúna sua família" |
| **Melhor Horário** | 19h-22h | 19h-21h |
| **Meta de Views** | 10K | 15K |
| **Meta de Conversão** | 10 registros | 15 registros |
