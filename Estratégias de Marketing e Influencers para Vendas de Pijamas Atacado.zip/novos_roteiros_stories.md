# Três Novos Roteiros de Stories - Personas Específicas

Estes roteiros foram desenvolvidos para serem executados em Stories (15-20 segundos cada), focando em humanização, autenticidade e engajamento direto com o público-alvo de cada persona.

---

## Roteiro 1: Carol - "Meu Primeiro Pedido Chegou!" (Renda Extra)

**Duração:** 15 segundos  
**Persona:** Carol (Empreendedora Iniciante, 24 anos)  
**Objetivo:** Criar identificação com pessoas que estão considerando começar a revender  
**Plataforma:** Instagram Stories e TikTok  

### Estrutura da Cena

| Tempo | Descrição da Cena | Áudio | Texto na Tela | Emoção |
| :--- | :--- | :--- | :--- | :--- |
| **0-2s** | Carol abre a porta de casa com uma caixa de papelão nos braços, olhando para câmera com surpresa | Som de campainha + música animada (upbeat) | "Chegou! 📦" | Entusiasmo |
| **2-5s** | Ela coloca a caixa na mesa e abre rapidamente, mostrando os pijamas bem embalados | Música continua, som de papel sendo rasgado (ASMR) | "Meu primeiro pedido Feminnita!" | Alegria |
| **5-8s** | Close-up: Carol pega um pijama, mostra a etiqueta de preço (R$ 39,90) e faz expressão de aprovação | Voz de Carol: "Que qualidade! Que preço!" | "Comprei por R$ 39,90" | Satisfação |
| **8-12s** | Carol mostra o celular com mensagens de amigas perguntando sobre o pijama (simuladas) | Notificações de WhatsApp (som) + música | "Já tô recebendo pedidos!" 💬 | Surpresa positiva |
| **12-15s** | Carol aponta para câmera com um sorriso confiante | Voz de Carol: "Quer começar também?" | "Clique no link da bio!" ⬆️ | Convite amigável |

### Elementos Técnicos

**Iluminação:** Natural (janela ao fundo) ou luz branca neutra  
**Ângulos:** Plano geral (0-2s), plano médio (2-8s), close-up (8-12s), plano geral novamente (12-15s)  
**Transições:** Corte seco entre cenas, sem efeitos sofisticados (mais autêntico)  
**Música:** Upbeat, motivacional, sem letra (foco na voz)  
**Hashtags:** #RendaExtra #PrimeiroNegócio #FeminnitaLucro #EmpreendedorismoFeminino

### Chamada para Ação (CTA)

**Primária:** "Clique no link da bio e peça o seu catálogo!"  
**Secundária:** "Marque uma amiga que quer começar também!"  
**Sticker:** Link direto para WhatsApp de vendas ou página de cadastro

### Dicas de Produção

Carol deve parecer genuinamente surpresa e feliz. O foco é transmitir que é **fácil começar** e que o resultado é **imediato**. Use roupas casuais (não muito produzida) para manter a autenticidade. A caixa deve estar bem embalada (transmite profissionalismo da Feminnita).

---

## Roteiro 2: Renata - "Análise Rápida de Qualidade" (Dona de Loja)

**Duração:** 18 segundos  
**Persona:** Renata (Dona de Loja, 38 anos)  
**Objetivo:** Demonstrar autoridade e conhecimento técnico para lojistas  
**Plataforma:** Instagram Stories e TikTok  

### Estrutura da Cena

| Tempo | Descrição da Cena | Áudio | Texto na Tela | Emoção |
| :--- | :--- | :--- | :--- | :--- |
| **0-2s** | Renata em seu escritório/loja, com uma mesa limpa. Ela pega um pijama de Suede com confiança | Música profissional (instrumental) | "Dica de Lojista 💡" | Profissionalismo |
| **2-5s** | Close-up: Renata mostra a costura do pijama, passando o dedo pela borda | Voz de Renata: "Vejam a costura perfeita, sem fios soltos" | "Costura de Qualidade" | Análise técnica |
| **5-8s** | Renata toca o tecido (Suede) e faz expressão de aprovação | Voz de Renata: "Tecido macio, durável, não desbota" | "Tecido Premium" | Satisfação profissional |
| **8-11s** | Renata mostra a etiqueta interna com informações (tamanho, composição) | Voz de Renata: "Etiqueta clara, informações completas para seus clientes" | "Transparência Total" | Confiança |
| **11-15s** | Renata aponta para câmera com expressão séria mas amigável | Voz de Renata: "Seus clientes vão perceber a diferença" | "Qualidade que Vende" | Segurança |
| **15-18s** | Renata segura o pijama em destaque e aponta para o link | Voz de Renata: "Cadastre-se como revendedor Feminnita!" | "Fale com a gente!" 📲 | Convite profissional |

### Elementos Técnicos

**Iluminação:** Luz branca/profissional (escritório bem iluminado)  
**Ângulos:** Plano médio (0-2s), close-up (2-11s), plano médio (15-18s)  
**Transições:** Zoom suave em detalhes, cortes profissionais  
**Música:** Instrumental profissional, fundo neutro  
**Hashtags:** #AtacadoPijamas #FornecedorConfiável #MargemDeLucro #QualidadeGarantida

### Chamada para Ação (CTA)

**Primária:** "Cadastre-se como revendedor Feminnita!"  
**Secundária:** "Peça uma amostra gratuita para sua loja"  
**Sticker:** Link direto para formulário de cadastro de lojistas

### Dicas de Produção

Renata deve parecer **confiante e experiente**. Use linguagem técnica mas acessível. O ambiente deve ser profissional mas não intimidador. O foco é transmitir que a Feminnita é um **fornecedor sério e confiável**. Ela não precisa sorrir o tempo todo—profissionalismo é mais importante que carisma aqui.

---

## Roteiro 3: Vanessa - "Compra Coletiva com as Amigas" (Economia Familiar)

**Duração:** 20 segundos  
**Persona:** Vanessa (Líder de Grupo, 45 anos)  
**Objetivo:** Criar senso de comunidade e mostrar economia ao comprar em grupo  
**Plataforma:** Instagram Stories e TikTok  

### Estrutura da Cena

| Tempo | Descrição da Cena | Áudio | Texto na Tela | Emoção |
| :--- | :--- | :--- | :--- | :--- |
| **0-3s** | Vanessa em casa com 2-3 amigas/familiares ao redor. Todas segurando pijamas diferentes (cores/modelos variados) | Música alegre, som de risadas | "Compra Coletiva Feminnita! 👯‍♀️" | Diversão |
| **3-6s** | Câmera faz zoom em cada pessoa mostrando o pijama que escolheu | Voz de Vanessa: "Cada uma escolhe o seu!" | "Variedade para Todos" | Inclusão |
| **6-9s** | Vanessa mostra uma nota fiscal (simulada ou real) na câmera com o valor total destacado | Voz de Vanessa: "Olha só quanto economizamos!" | "De R$ 800 por R$ 550!" 💰 | Surpresa positiva |
| **9-12s** | Cena de todas sentadas no sofá, vestindo os pijamas novos, rindo e se mostrando | Música alegre, som de risadas | "Conforto e Economia!" | Felicidade |
| **12-15s** | Vanessa aponta para câmera com expressão amigável | Voz de Vanessa: "Vocês também podem fazer isso!" | "Marque suas Amigas! 👇" | Convite |
| **15-20s** | Vanessa segura o celular mostrando o link | Voz de Vanessa: "Clique aqui e organize sua compra coletiva!" | "Clique no Link da Bio" 📱 | Ação |

### Elementos Técnicos

**Iluminação:** Natural (sala de estar) ou luz quente (aconchego)  
**Ângulos:** Plano geral (0-3s), plano médio (3-9s), close-up (9-12s), plano geral (12-20s)  
**Transições:** Cortes dinâmicos, zoom em detalhes, sem efeitos muito pesados  
**Música:** Alegre, descontraída, com possibilidade de som ambiente (risadas)  
**Hashtags:** #CompraColetiva #PijamaFamília #EconomiaFamiliar #ConfortoEmCasa

### Chamada para Ação (CTA)

**Primária:** "Marque suas amigas e organize uma compra coletiva!"  
**Secundária:** "Clique no link e veja os Kits Família"  
**Sticker:** Link direto para página de Kits Família ou WhatsApp de vendas

### Dicas de Produção

Este roteiro é o mais **descontraído e divertido**. Vanessa deve parecer **genuinamente feliz** e conectada com as pessoas ao seu redor. O foco é transmitir **união, economia e conforto**. Use cores vibrantes nos pijamas para criar contraste visual. As pessoas ao fundo devem estar naturais e autênticas—não precisa ser super produzido. O tom é de **amiga recomendando para amigas**, não de venda agressiva.

---

## Resumo Comparativo dos Três Roteiros

| Aspecto | Carol | Renata | Vanessa |
| :--- | :--- | :--- | :--- |
| **Tom** | Entusiasmado, autêntico | Profissional, confiante | Alegre, descontraído |
| **Duração** | 15s | 18s | 20s |
| **Foco Principal** | Facilidade e lucro rápido | Qualidade e confiabilidade | Economia e comunidade |
| **Ambiente** | Casa (casual) | Escritório/loja (profissional) | Sala de estar (aconchego) |
| **Público-Alvo** | Iniciantes, mães | Lojistas experientes | Grupos de amigas/família |
| **CTA Primária** | "Clique no link da bio!" | "Cadastre-se como revendedor!" | "Marque suas amigas!" |
| **Emoção Dominante** | Surpresa positiva | Segurança profissional | Felicidade compartilhada |

---

## Dicas Gerais de Produção para Stories

1. **Qualidade de Vídeo:** Use câmera do celular em boa iluminação (evita parecer amador demais, mas mantém autenticidade).

2. **Áudio:** Invista em áudio claro. Use música de fundo baixa (não abafe a voz). Considere usar legendas para melhor engajamento.

3. **Timing:** Poste nos horários de pico: 19h-22h (noite) e 12h-13h (almoço). Stories têm validade de 24h, então reposte a cada dia em horários diferentes.

4. **Sequência:** Poste os três roteiros em dias diferentes da semana para manter variedade de conteúdo.

5. **Chamada para Ação:** Sempre termine com um CTA claro. Use stickers de link, enquetes ou caixas de perguntas para aumentar engajamento.

6. **Autenticidade:** Não precisa ser perfeito. Imperfeições (pequenos erros, risadas, momentos naturais) aumentam a identificação com o público.

7. **Replicação:** Após criar os vídeos, replique com pequenas variações (diferentes roupas, ambientes, horários) para testar qual versão gera mais engajamento.
