import { z } from "zod";
import { getDb } from "../db";
import { oauthCredentials } from "../../drizzle/schema";
import { eq, and } from "drizzle-orm";

export const integrationsRouter = router({
  // Get status of all integrations
  getStatus: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    const credentials = await db
      .select()
      .from(oauthCredentials)
      .where(eq(oauthCredentials.userId, ctx.user.id));

    const status: Record<string, any> = {
      bling: { connected: false },
      canva: { connected: false },
      meta: { connected: false },
    };

    credentials.forEach((cred) => {
      if (cred.platform === "bling") {
        status.bling = {
          connected: true,
          lastSync: cred.lastValidated,
        };
      } else if (cred.platform === "canva") {
        status.canva = {
          connected: true,
          lastSync: cred.lastValidated,
        };
      } else if (cred.platform === "meta") {
        status.meta = {
          connected: true,
          lastSync: cred.lastValidated,
        };
      }
    });

    return status;
  }),

  // Test Bling connection
  testBlingConnection: protectedProcedure
    .input(
      z.object({
        apiKey: z.string().min(1, "API Key é obrigatória"),