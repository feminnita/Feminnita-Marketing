# Autenticação Bling API

## Fluxo de Autenticação

O Bling usa **OAuth 2.0** para autenticação. O token é um **Bearer Token** gerado através do fluxo de autorização OAuth.

## Como usar o Token

**Header**: `Authorization: Bearer [access_token]`

**Exemplo cURL**:
```bash
curl --location --request GET 'https://api.bling.com.br/Api/v3/contatos' \
  --header 'Authorization: Bearer 4a9de71b8aaf91c8ebbf830888354d5479e83a01'
```

## Geração de Token

1. Criar um "Usuário API" em Preferências > Sistema > Usuários
2. Gerar a chave de integração (access_token)
3. Usar essa chave no header Authorization

## Endpoints Principais

- `GET https://api.bling.com.br/Api/v3/produtos` - Listar produtos
- `GET https://api.bling.com.br/Api/v3/pedidos` - Listar pedidos
- `GET https://api.bling.com.br/Api/v3/contatos` - Listar contatos
- `GET https://api.bling.com.br/Api/v3/estoque` - Sincronizar estoque

## Formato de Resposta

```json
{
  "data": {
    "id": 1,
    "nome": "Produto"
  }
}
```
