
**Versão:** 1.0  
**Data:** Fevereiro de 2026  
**Autora:** Manus AI  
**Objetivo:** Guia prático e didático para operar todas as funcionalidades da plataforma Feminnita

---

## 📖 Índice

1. [Glossário Completo](#glossário-completo)
2. [Introdução à Plataforma](#introdução-à-plataforma)
3. [Passo a Passo das Funcionalidades](#passo-a-passo-das-funcionalidades)
4. [Email Marketing e Automação](#email-marketing-e-automação)
5. [Mailchimp: Guia Prático](#mailchimp-guia-prático)
6. [CRM Simples Integrado](#crm-simples-integrado)
7. [Atribuição Multi-canal](#atribuição-multi-canal)
8. [Pesquisas e Comparativos](#pesquisas-e-comparativos)

---

## 🔤 Glossário Completo

### A

**Aba (Tab)**
Uma seção específica da plataforma que agrupa informações relacionadas. Exemplo: "Aba Facebook Ads" contém todas as análises de campanhas do Facebook.

**Ativo (Segmento)**
Clientes que fizeram compra nos últimos 30 dias e mantêm engajamento regular com a marca.

**Atribuição de Conversão**
Processo de identificar qual canal de marketing (Facebook, Google Ads, Email) foi responsável pela venda final.

**Automação**
Sistema que executa ações automaticamente quando certas condições são atendidas. Exemplo: enviar email quando cliente entra no segmento "Em Risco".

### B

**Benchmark**
Padrão de comparação usado para avaliar performance. Exemplo: "ROI médio de mercado é 1.45x".

**Budget**
Valor total de dinheiro alocado para campanhas de marketing em um período.

### C

**CAC (Customer Acquisition Cost)**
Custo médio para adquirir um novo cliente. Fórmula: Gasto em Marketing ÷ Número de Clientes Adquiridos.

**Campanha**
Conjunto de anúncios ou ações de marketing com objetivo específico (ex: "Campanha Black Friday").

**Churn**
Porcentagem de clientes que deixam de comprar ou cancelam o relacionamento com a marca.

**CRM (Customer Relationship Management)**
Sistema para gerenciar informações e relacionamento com clientes em um único lugar.

**CTR (Click-Through Rate)**
Porcentagem de pessoas que clicaram em um anúncio. Fórmula: (Cliques ÷ Impressões) × 100.

**CPA (Cost Per Action)**
Custo médio por ação realizada (compra, cadastro, etc.). Fórmula: Gasto Total ÷ Número de Ações.

### D

**Dashboard**
Tela visual que mostra métricas e dados importantes em tempo real.

**Dormentes (Segmento)**
Clientes que não fizeram compra há mais de 60 dias.

### E

**Email Marketing**
Envio de mensagens de marketing para lista de clientes via email.

**Em Risco (Segmento)**
Clientes que fizeram compra, mas não compraram nos últimos 30 dias (risco de churn).

### F

**Funil de Vendas**
Processo que leva um cliente em potencial até a compra: Conhecimento → Interesse → Consideração → Compra.

### G

**Gerador de Relatórios**
Ferramenta que cria relatórios automáticos com dados e gráficos.

### H

**Heatmap**
Visualização que mostra quais áreas de um anúncio ou página recebem mais cliques (cores quentes = mais cliques).

### I

**Impressão**