# Informações das APIs

## Bling API
- **URL Base**: `https://api.bling.com.br/Api/v3`
- **Versão**: 3.0 (OAS 3.0)
- **Documentação**: https://developer.bling.com.br/
- **Endpoints principais**:
  - Produtos
  - Pedidos
  - Estoques
  - Contatos
  - E muitos outros...
- **Autenticação**: JWT (Bearer Token)

## Canva API
- **Documentação**: https://www.canva.dev/
- **URL Base**: Precisa ser verificada
- **Endpoints**: Connect APIs para integração

## Meta Graph API
- **URL Base**: `https://graph.instagram.com/v18.0/`
- **Documentação**: https://developers.facebook.com/docs/graph-api/
- **Versão**: v18.0
- **Autenticação**: Bearer Token (Access Token)
