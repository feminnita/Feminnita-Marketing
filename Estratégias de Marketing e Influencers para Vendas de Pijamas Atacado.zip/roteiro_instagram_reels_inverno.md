# Roteiro de Vídeo para Instagram Reels - Lançamento Pijama de Inverno

## Informações Gerais do Vídeo

**Título:** "Chegou! Pijama Inverno 2026 - Conforto Máximo para as Noites Frias"  
**Duração:** 30-45 segundos (formato Instagram Reels otimizado)  
**Objetivo:** Criar buzz sobre novo lançamento, gerar antecipação e urgência de compra  
**Público-Alvo:** Mulheres 18-50 anos, seguidoras da marca, buscando conforto e qualidade  
**Formato:** Teaser → Reveal → Características → Prova Social → CTA  
**Estilo Visual:** Premium, elegante, invernal, aspiracional  
**Tom de Voz:** Entusiasmado, exclusivo, confiante, sofisticado  
**Plataforma:** Instagram Reels (pode ser adaptado para TikTok)  
**Resolução:** 1080x1920px (vertical) ou 1080x1350px (quadrado)  
**FPS:** 30fps  
**Áudio:** Música trendy + voz em off + efeitos sonoros  

---

## Estrutura Narrativa

O vídeo segue a narrativa clássica de **lançamento de produto premium**: começa com teaser/mistério (o que é?), revela o produto (pijama inverno!), mostra características principais (tecido, cores, conforto), demonstra com prova social (influenciadoras/clientes usando), e termina com CTA urgente (compre agora, quantidade limitada).

---

## Timeline Detalhada (40 segundos)

### Segundo 0-4: TEASER (Gancho de Mistério)

**Descrição de Cena:**  
Tela preta. Efeito de "frost" (geada) aparecendo lentamente. Mão de mulher tocando vidro congelado. Close-up em gotas de água congeladas. Fundo: ambiente frio, escuro, atmosfera de inverno.

**Áudio:**  
Música começa (algo sofisticado, trendy, com beat que transmite exclusividade). Volume: 70%. Voz em off feminina (misteriosa, entusiasmada): "Você já sentiu o conforto perfeito para o inverno?"

**Texto na Tela:**  
Aparece em letras elegantes, brancas, com efeito de "frost":  
**"ALGO ESPECIAL CHEGOU"**  
Depois aparece menor: **"PREPARE-SE"**  
(Fonte: Montserrat Bold ou similar, tamanho 44px, animação: fade in com efeito de "gelo")

**Efeitos Visuais:**  
Transição suave com efeito de "frost" (geada) aparecendo. Cores frias (azul, branco, cinza). Há um efeito de "shimmer" (brilho) no texto. Música começa com beat que chama atenção.

**Dica de Produção:**  
Crie mistério. O público deve ficar curioso sobre o que é. Use elementos visuais que remetem a inverno (gelo, frio, cores frias).

---

### Segundo 4-10: REVEAL (Revelação do Produto)

**Descrição de Cena:**  
Transição dinâmica: efeito de "zoom out" rápido. Revela mulher em ambiente aconchego (cama, sofá) usando pijama de inverno. Close-up nos detalhes do pijama: tecido grosso, cores quentes (azul marinho, cinza, vinho), padrão elegante. Luz quente ilumina a cena.

**Áudio:**  
Voz em off (entusiasmada, reveladora): "Apresentamos: Pijama Inverno 2026! Tecido premium, conforto máximo, design exclusivo!"  
Música atinge o pico de energia. Som de "reveal" (como um "ta-da!" musical).

**Texto na Tela:**  
Aparece em letras grandes, elegantes:  
**"PIJAMA INVERNO 2026"**  
Depois aparece: **"LANÇAMENTO EXCLUSIVO"**  
(Animação: slide de cima para baixo com efeito de "elegância")

**Efeitos Visuais:**  
Transição rápida com efeito de "zoom out". Cores mudam de frias (azul/branco) para quentes (laranja/ouro). Há um efeito de "glow" ao redor do pijama. Confete digital aparece (opcional, mas impactante).

**Dica de Produção:**  
Este é o momento de IMPACTO. Mostre o pijama de forma elegante e desejável. Use iluminação quente para transmitir conforto. O pijama deve parecer premium e exclusivo.

---

### Segundo 10-18: CARACTERÍSTICAS (Destaques do Produto)

**Descrição de Cena:**  
Montagem rápida de 4 cenas (2 segundos cada), cada uma destacando uma característica:

1. **Cena 1 (2s):** Close-up no tecido - mão tocando, mostrando espessura e qualidade. Texto: "Tecido Premium" com ícone de tecido.

2. **Cena 2 (2s):** Modelo usando pijama, mostrando conforto - alongando, deitando na cama, sorrindo. Texto: "Conforto Máximo" com ícone de coração.

3. **Cena 3 (2s):** Close-up nas cores - 3-4 cores diferentes (azul marinho, cinza, vinho, preto). Texto: "4 Cores Exclusivas" com ícone de paleta.

4. **Cena 4 (2s):** Modelo em ambiente aconchego (cama com roupa de cama, luz quente, xícara de chá). Texto: "Perfeito para Inverno" com ícone de flocos de neve.

**Áudio:**  
Voz em off (clara, didática): "Tecido 100% algodão premium, peso perfeito para inverno, 4 cores exclusivas, e o conforto que você merece nas noites frias!"  
Música mantém tom sofisticado e energético.

**Texto na Tela:**  
Sequência de características aparecendo:  
**"TECIDO PREMIUM"** → **"CONFORTO MÁXIMO"** → **"4 CORES EXCLUSIVAS"** → **"PERFEITO PARA INVERNO"**  
(Animação: slide de lado com efeito de "elegância")

**Efeitos Visuais:**  
Transições suaves entre cenas (0.5s). Cada característica tem um ícone que aparece com efeito de "pop". Cores mantêm tom quente e aconchego. Há um efeito de "highlight" em cada detalhe.

**Dica de Produção:**  
Mostre os detalhes do produto. Deixe claro por que é especial. Use ícones e texto para reforçar cada ponto. A qualidade deve ser evidente.

---

### Segundo 18-28: PROVA SOCIAL + LIFESTYLE (Aspiração)

**Descrição de Cena:**  
Montagem de 3-4 cenas de lifestyle mostrando o pijama em contextos desejáveis:

1. **Cena 1 (2.5s):** Mulher acordando na cama, esticando, sorrindo. Luz natural de manhã. Pijama de inverno confortável. Ambiente aconchego.

2. **Cena 2 (2.5s):** Mulher tomando café/chá na cama, lendo livro, em pijama de inverno. Luz quente, ambiente cozy. Velas acesas.

3. **Cena 3 (2.5s):** Mulher com amigas em pijama de inverno, rindo, conversando. Ambiente de sleepover/pijama party. Diversão e conforto.

4. **Cena 4 (2.5s):** Montagem de depoimentos rápidos de 2-3 mulheres (1 segundo cada): "Melhor pijama que já tive!" / "Qualidade impecável!" / "Recomendo demais!"

**Áudio:**  
Voz em off (entusiasmada): "Mulheres em toda parte já estão amando! Conforto, qualidade e estilo que você merece!"  
Música continua sofisticada e energética. Cada depoimento tem um "ding" de notificação.

**Texto na Tela:**  
Aparece durante as cenas lifestyle:  
**"CONFORTO PARA SEUS MELHORES MOMENTOS"**  
Depois durante depoimentos: **"⭐ CLIENTES AMAM"**  
(Animação: fade in/out suave)

**Efeitos Visuais:**  
Transições suaves entre cenas (0.5s). Cores quentes e aconchego. Há um efeito de "like" (coração) que aparece durante depoimentos. Filtro leve de "warm" (quente) em todas as cenas.

**Dica de Produção:**  
Mostre o produto em contextos aspiracionais. Mulheres querem se ver usando o pijama em situações que as fazem felizes. Use iluminação quente e ambientes aconchego. Autenticidade é importante.

---

### Segundo 28-38: URGÊNCIA + EXCLUSIVIDADE

**Descrição de Cena:**  
Volta para close-up do pijama. Aparecem elementos de urgência: contador de estoque, "Lançamento Exclusivo", "Quantidade Limitada". Fundo: ambiente premium, iluminação elegante.

**Áudio:**  
Voz em off (urgente, convidativa): "Lançamento exclusivo com quantidade limitada! Disponível AGORA apenas no link da bio!"  
Música atinge o pico de energia. Som de "urgência" (como um "tick-tock" suave).

**Texto na Tela:**  
Aparece em sequência:  
**"LANÇAMENTO EXCLUSIVO"**  
**"QUANTIDADE LIMITADA"**  
**"DISPONÍVEL AGORA"**  
Depois aparece em letras maiores e destacadas:  
**"CLIQUE NO LINK DA BIO"**  
(Animação: zoom in, depois pulse/pulsação para atrair atenção)

**Efeitos Visuais:**  
Efeito de "countdown" ou "timer" (opcional). Há um efeito de "glow" intenso ao redor do pijama. Texto tem efeito de "pulse" (pulsação) para transmitir urgência. Cores ficam mais vibrantes.

**Dica de Produção:**  
Crie urgência sem parecer desesperado. Use palavras como "exclusivo", "limitado", "agora". O CTA deve ser claro e visível.

---

### Segundo 38-40: FECHAMENTO (Call-to-Action Final)

**Descrição de Cena:**  
Mulher olhando diretamente para câmera, sorrindo, confiante. Usando pijama de inverno. Fundo: ambiente premium, iluminação elegante. Pode estar em cama aconchego ou ambiente sofisticado.

**Áudio:**  
Voz em off (calorosa, convidativa): "Não perca! Seu inverno perfeito começa aqui!"  
Música atinge o pico. Som de "sucesso" (ding positivo).

**Texto na Tela:**  
**"SEU INVERNO PERFEITO COMEÇA AQUI"**  
Depois aparece menor: **"FEMINNITA PIJAMAS"**  
(Animação: zoom in para o texto, depois fade out)

**Efeitos Visuais:**  
Close-up no rosto. Há um efeito de "glow" ao redor da mulher. Quando o CTA aparece, há um efeito de "pulse" no texto. Cores quentes e aconchego.

**Dica de Produção:**  
Crie conexão emocional. O sorriso deve ser genuíno. A expressão deve transmitir confiança e satisfação. Este é o último momento para convencer.

---

## Especificações Técnicas

### Áudio

**Música de Fundo:**  
- Recomendação: Áudio viral do Instagram Reels com tema premium/sofisticado (ex: "Levitating" remix, "Blinding Lights" remix, ou qualquer áudio trendy com >20M usos que transmita exclusividade)
- Volume: 70% durante todo o vídeo
- Duração: 40 segundos
- Estilo: Sofisticado, energético, trendy, premium

**Voz em Off:**  
- Voz: Feminina, sofisticada, confiante, clara
- Tom: Entusiasmado mas elegante, não artificial
- Velocidade: Moderada
- Volume: 80% (mais alto que a música)
- Efeito: Sem reverb excessivo, voz clara e direta
- Duração total de fala: ~25 segundos

**Efeitos Sonoros:**  
- Som de "reveal" (ta-da!): Quando pijama é revelado
- Notificação (ding): Quando depoimentos aparecem
- Som de "urgência" (tick-tock): Quando contador de estoque aparece
- Som de "sucesso": Quando CTA aparece
- Volume: 40-50%

### Visuais

**Cores Principais:**  
- Rosa Feminnita: #E84C89 (usar em acentos, logo)
- Azul Marinho: #1A3A52 (cor do pijama de inverno)
- Cinza: #8B8B8B (cor do pijama de inverno)
- Vinho: #722F37 (cor do pijama de inverno)
- Branco: #FFFFFF (fundo de texto, clareza)
- Preto: #000000 (contorno de texto)
- Cores Quentes: Laranja, ouro, tons de luz (para aconchego)

**Tipografia:**  
- Fonte Principal: Montserrat Bold ou Poppins Bold (Google Fonts)
- Tamanho: 44-52px para texto principal, 28-36px para texto secundário
- Contorno: Preto 2-3px para garantir legibilidade
- Sombra: Leve (blur 2px, opacidade 30%)

**Transições:**  
- Tipo: Cortes rápidos (0.3-0.5s), slides suaves, zooms elegantes
- Duração: Manter dinâmico mas sofisticado
- Efeito: Transições suaves e elegantes (não muito frenéticas)

**Filtros/Efeitos:**  
- Primeiros 4 segundos: Tons frios (azul, branco, cinza) para transmitir inverno
- Segundo 4 em diante: Cores quentes e vibrantes para transmitir conforto/exclusividade
- Brilho/Glow: Usar em momentos-chave (reveal, características, CTA)
- Confete Digital: Quando produto é revelado (opcional)
- Shimmer/Brilho: Em texto e elementos premium

### Resolução e Formato

**Resolução:** 1080x1920px (vertical, padrão Reels) ou 1080x1350px (quadrado)  
**Aspect Ratio:** 9:16 (vertical) ou 1:1 (quadrado)  
**FPS:** 30fps  
**Codec:** H.264  
**Tamanho de Arquivo:** Máximo 4GB  
**Duração:** 40 segundos (Reels suporta até 90s)  

---

## Dicas de Produção e Gravação

### Equipamento Necessário

**Mínimo:**  
- Celular com câmera decente (iPhone 12+ ou Android equivalente)
- Tripé ou suporte
- Iluminação natural (janela) ou ring light
- Microfone externo (recomendado para voz em off clara)

**Ideal:**  
- Câmera mirrorless ou DSLR
- Microfone lavalier ou shotgun
- Iluminação profissional (ring light + softbox + key light)
- Tripé de qualidade
- Refletor para controlar sombras

### Ambiente de Gravação

**Ambiente Premium (Quarto/Sala):**  
- Elegante, bem iluminado, aconchego
- Elementos que remetem a inverno (mantas, velas, xícara de chá)
- Luz natural preferível (gravar perto de janela)
- Se usar luz artificial, use temperatura quente (3000K) para parecer aconchego
- Fundo neutro ou com elementos sofisticados (não bagunçado)

**Iluminação:**  
- Luz frontal para iluminar rostos
- Luz de fundo suave (para criar profundidade)
- Evitar sombras duras
- Se usar ring light, posicione na altura dos olhos
- Use refletor para suavizar sombras

### Técnica de Gravação

**Enquadramento:**  
- Teaser: Close-up em detalhes (gelo, mão, vidro)
- Reveal: Medium shot (mostrando o pijama completo)
- Características: Close-up em detalhes (tecido, cores, modelo)
- Lifestyle: Wide shot (mostrando o contexto) ou medium shot
- CTA: Close-up no rosto (queixo até topo da cabeça)

**Movimento de Câmera:**  
- Mantenha câmera estável (use tripé)
- Movimentos suaves de zoom (não muito rápido)
- Evitar movimento excessivo (distrai)
- Pode usar movimentos lentos de pan (horizontal) para revelar o pijama

**Expressões e Atuação:**  
- Teaser: Mistério, curiosidade
- Reveal: Entusiasmo, alegria
- Características: Natural, confiante
- Lifestyle: Genuinamente feliz, relaxada
- CTA: Confiante, convidativa, sofisticada

### Edição

**Software Recomendado:**  
- Gratuito: CapCut, DaVinci Resolve
- Pago: Adobe Premiere Pro, Final Cut Pro

**Passos de Edição:**  
1. Importar clips de vídeo
2. Organizar em sequência (teaser → reveal → características → lifestyle → urgência → CTA)
3. Cortar para duração exata (40s)
4. Adicionar transições (0.3-0.5s cada)
5. Adicionar texto com animações
6. Adicionar áudio (música + voz em off)
7. Balancear volumes (música 70%, voz 80%, efeitos 40-50%)
8. Adicionar efeitos visuais (brilho, glow, confete)
9. Aplicar filtro de "warm" (quente) nas cenas de lifestyle
10. Exportar em 1080x1920px, 30fps, H.264

---

## Variações e A/B Testing

### Versão Alternativa 1: "Antes/Depois - Inverno"

Se a primeira versão não gerar muitos saves/shares, tente esta variação:

- Mostrar mulher com frio, tremendo (antes)
- Transição para mesma mulher confortável em pijama de inverno (depois)
- Enfatizar transformação de "frio" para "conforto"
- CTA: "Transforme seu inverno"

**Razão:** Formato antes/depois é muito viral no Instagram.

### Versão Alternativa 2: "Unboxing Exclusivo"

Se o público é mais visual/aspiracional, tente esta variação:

- Mostrar caixa de lançamento elegante
- Abrir caixa em câmera lenta
- Revelar pijama de inverno
- Mostrar detalhe de cada cor
- CTA: "Desembrulhe o conforto"

**Razão:** Unboxing é muito popular no Instagram Reels.

---

## Estratégia de Postagem e Promoção

### Quando Postar

**Melhor Horário:** 19h-21h (noite, quando pessoas estão relaxando)  
**Melhor Dia:** Quinta a Domingo (fim de semana, quando pessoas têm tempo para browsing)  
**Frequência:** Postar 1 vez por semana durante o mês de lançamento  

### Como Promover

1. **Postar no Instagram Reels:** Use hashtags #LançamentoFeminnita #PijamaInverno #ConfortoMaximo
2. **Compartilhar no TikTok:** Mesmo vídeo, com hashtags adaptadas
3. **Compartilhar no Feed:** Postar como carrossel com 3-4 imagens estáticas do pijama
4. **Stories:** Compartilhar clipes do Reels em stories com stickers de urgência
5. **Pedir Shares:** "Compartilhe com alguém que merece conforto!"
6. **Responder Comentários:** Engage rapidamente com comentários

### Métricas para Acompanhar

- **Visualizações:** Meta mínima 20K views (lançamento deve ter alcance maior)
- **Saves:** Meta mínima 500 saves (indica interesse em compra futura)
- **Shares:** Meta mínima 100 shares (vídeo deve ser compartilhado)
- **Comentários:** Meta mínima 50 comentários
- **Cliques no Link:** Meta mínima 200 cliques
- **Conversão:** Meta mínima 25 registros/compras (de 200 cliques)

---

## Dicas Finais para Maximizar Sucesso

### 1. Qualidade Premium é Essencial

Diferente de TikTok (que valoriza autenticidade), Instagram Reels valoriza qualidade visual. Invista em iluminação, ângulos e edição.

### 2. Primeira Cena é Crítica

Os primeiros 3 segundos determinam se o público continua assistindo. Use teaser/mistério para prender atenção.

### 3. Transições Elegantes

Use transições suaves, não abruptas. Isso transmite sofisticação e premium.

### 4. Cores Consistentes

Mantenha paleta de cores consistente (azul marinho, cinza, vinho para o pijama; quentes para lifestyle).

### 5. Música Trendy

Use áudio que está em alta no Instagram. Isso aumenta chances de ser promovido pelo algoritmo.

### 6. Prova Social Importa

Depoimentos e lifestyle shots aumentam confiança. Mostre mulheres reais usando e amando.

### 7. CTA Clara e Urgente

"Clique no link da bio" é bom, mas "Disponível AGORA com quantidade limitada" é melhor.

### 8. Teste Múltiplas Versões

Poste versão principal, depois teste alternativas. Aprenda qual funciona melhor.

---

## Checklist Final Antes de Postar

- [ ] Vídeo tem exatamente 40 segundos
- [ ] Áudio está sincronizado com vídeo
- [ ] Texto está legível em celular (teste em celular real)
- [ ] Cores são vibrantes e consistentes
- [ ] Transições são suaves e elegantes
- [ ] Qualidade visual é premium (não pixelado)
- [ ] CTA é claro e urgente
- [ ] Link na bio está funcional
- [ ] Hashtags estão relevantes e populares
- [ ] Legenda está atrativa e inclui CTA
- [ ] Vídeo foi testado em diferentes celulares
- [ ] Áudio foi testado (volume correto, sem ruído)
- [ ] Você está satisfeita com o resultado final

---

## Comparação: 3 Tipos de Roteiros

| Aspecto | Renda Extra | Compra Familiar | Lançamento Inverno |
| :--- | :--- | :--- | :--- |
| **Público** | Mulheres 18-45, desempregadas | Mães 25-50 | Mulheres 18-50, seguidoras |
| **Problema** | Sem renda | Preço alto | Frio, desconforto |
| **Solução** | Revender pijamas | Comprar em família | Pijama premium de inverno |
| **Resultado** | R$ 2.500/mês | R$ 440 economia | Conforto + exclusividade |
| **Tom** | Entusiasmado | Caloroso | Sofisticado, premium |
| **Cores** | Rosa/Laranja | Quentes/Ouro | Azul/Cinza/Vinho |
| **Plataforma** | TikTok | TikTok/Reels | Instagram Reels |
| **Duração** | 30s | 30s | 40s |
| **CTA** | "Clique no link" | "Reúna sua família" | "Disponível AGORA" |
| **Meta de Views** | 10K | 15K | 20K |
| **Meta de Conversão** | 10 registros | 15 registros | 25 compras |
