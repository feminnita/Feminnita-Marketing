        </CardContent>
      </Card>

      {/* Micro-Influencers Available */}
      <Card>
        <CardHeader>
          <CardTitle>Micro-Influenciadoras Disponíveis</CardTitle>
          <CardDescription>Oportunidades de parcerias com menor investimento</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {microInfluencers.map((micro, idx) => (
              <div key={idx} className="border border-slate-200 rounded-lg p-4 hover:shadow-md transition">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <p className="font-semibold text-slate-900">{micro.name}</p>
                    <p className="text-sm text-slate-600">{micro.niche}</p>
                  </div>
                  <Badge className="bg-blue-100 text-blue-800">{micro.status}</Badge>
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-slate-100">
                  <div className="flex items-center gap-4 text-sm">
                    <span className="text-slate-600">
                      <strong>{(micro.followers / 1000).toFixed(0)}K</strong> seguidores
                    </span>
                    <span className="text-slate-600">
                      <strong>{micro.engagement}%</strong> engajamento
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900">{micro.rate}</span>
                    <button className="px-3 py-1 bg-pink-500 text-white rounded hover:bg-pink-600 transition text-sm">
                      Contratar
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Create Partnership */}
      <Card>
        <CardHeader>
          <CardTitle>Criar Nova Parceria</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-900 mb-2">Influenciadora</label>
            <select className="w-full border border-slate-300 rounded-lg px-3 py-2">
              <option>Selecionar influenciadora...</option>
              <option>Ana Paula (12.5K)</option>
              <option>Beatriz Rocha (18K)</option>
              <option>Camila Santos (15K)</option>
              <option>Daniela Lima (22K)</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-900 mb-2">Tipo de Campanha</label>
            <select className="w-full border border-slate-300 rounded-lg px-3 py-2">
              <option>Post Único</option>
              <option>Série de 3 Posts</option>
              <option>Série de 5 Posts</option>
              <option>Parceria Mensal</option>
            </select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-900 mb-2">Data Início</label>
              <input type="date" className="w-full border border-slate-300 rounded-lg px-3 py-2" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-900 mb-2">Data Fim</label>
              <input type="date" className="w-full border border-slate-300 rounded-lg px-3 py-2" />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-900 mb-2">Budget</label>
            <input type="number" placeholder="R$ 1.000" className="w-full border border-slate-300 rounded-lg px-3 py-2" />
          </div>

          <button className="w-full py-3 bg-gradient-to-r from-pink-500 to-purple-500 text-white rounded-lg hover:from-pink-600 hover:to-purple-600 transition font-semibold">
            🤝 Criar Parceria
          </button>
        </CardContent>
      </Card>

      {/* Performance Summary */}
      <Card className="bg-green-50 border-green-200">
        <CardHeader>
          <CardTitle className="text-green-900">📊 Performance de Influenciadores</CardTitle>
        </CardHeader>
        <CardContent className="text-green-900 space-y-3">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm font-semibold">Parcerias Ativas</p>
              <p className="text-2xl font-bold">4</p>
              <p className="text-xs mt-1">influenciadoras</p>
            </div>
            <div>
              <p className="text-sm font-semibold">Alcance Total</p>
              <p className="text-2xl font-bold">186K</p>
              <p className="text-xs mt-1">seguidores</p>
            </div>
            <div>
              <p className="text-sm font-semibold">Views Geradas</p>
              <p className="text-2xl font-bold">405K</p>
              <p className="text-xs mt-1">este mês</p>
            </div>
            <div>
              <p className="text-sm font-semibold">ROI Médio</p>
              <p className="text-2xl font-bold">397%</p>
              <p className="text-xs mt-1">por campanha</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
