# Planejamento Semanal de Conteúdo para Feminnita (Atacado)

O planejamento semanal de conteúdo visa cobrir os principais objetivos de marketing da Feminnita: atrair revendedores iniciantes (renda extra), fidelizar lojistas (qualidade e variedade), e incentivar compras coletivas (economia familiar), utilizando as quatro personas de influenciadoras criadas para dar voz e humanidade à marca.

## Estrutura do Calendário de Conteúdo

A tabela a seguir detalha a sugestão de postagens para o *feed* principal (Instagram e TikTok), garantindo a variedade de temas e o uso estratégico das personas.

| Dia | Tema/Objetivo Principal | Tipo de Conteúdo | Persona em Destaque | Chamada para Ação (CTA) |
| :--- | :--- | :--- | :--- | :--- |
| **Segunda-feira** | **Motivação e Renda Extra** | **Reel** (Vídeo dinâmico) | Carol (Empreendedora Iniciante) | "Comece a lucrar hoje! Clique no link da bio e fale com nosso time de atacado." |
| **Terça-feira** | **Qualidade e Diferencial** | **Carrossel** (Imagens detalhadas) | Renata (Dona de Loja) | "Lojista, exija qualidade! Salve este post para conferir os detalhes dos nossos tecidos." |
| **Quarta-feira** | **Lançamento e Novidade** | **Reel** (Provador rápido/Transições) | Luiza (Trendsetter) | "Nova coleção no ar! Comente 'QUERO' para receber o catálogo completo no seu direct." |
| **Quinta-feira** | **Abastecimento de Estoque** | **Imagem/Reel** (Foto de caixas/Estoque cheio) | Renata (Dona de Loja) | "Estoque renovado! Garanta suas peças antes que acabem. Pedido mínimo R$ 199." |
| **Sexta-feira** | **Compra Coletiva e Família** | **Reel** (Cenas de família/Amigas) | Vanessa (Líder de Grupo) | "Marque as amigas que vão dividir o pedido com você e economizar!" |
| **Sábado** | **Promoção e Oportunidade** | **Imagem** (Destaque de preço/Outlet) | Carol (Empreendedora Iniciante) | "Últimas peças do Outlet! Preços a partir de R$ 10. Link na bio para o Outlet." |
| **Domingo** | **Engajamento e Lifestyle** | **Story** (Enquete/Caixa de Perguntas) | Luiza (Trendsetter) | "Qual seu pijama favorito para o domingo? Responda na caixinha!" |

## Sugestões de Conteúdo para Stories (Diário)

Os Stories devem ser usados para criar um senso de urgência, proximidade e para direcionar tráfego para o WhatsApp e o site.

| Dia | Conteúdo Sugerido para Stories | Objetivo |
| :--- | :--- | :--- |
| **Segunda** | **Caixa de Perguntas:** "Dúvidas sobre como revender?" (Carol responde). | Quebrar objeções iniciais. |
| **Terça** | **Enquete:** "Qual tecido você prefere: Suede ou Algodão?" (Renata mostra os dois). | Educar sobre o produto e engajar. |
| **Quarta** | **Contagem Regressiva:** Para o lançamento da nova coleção. **Link:** Direto para a página de novidades. | Criar *hype* e gerar tráfego. |
| **Quinta** | **Repost de Cliente:** Mostrar pedidos sendo embalados (Prova Social). **Link:** Direto para o WhatsApp de vendas. | Transmitir confiança e urgência. |
| **Sexta** | **Quiz:** "Qual pijama da família combina com você?" (Vanessa). | Entretenimento e identificação. |
| **Sábado** | **Flash Sale:** Promoção relâmpago de 24h em um produto específico. **Link:** Direto para o produto. | Venda imediata e geração de receita. |
| **Domingo** | **Bastidores:** Preparação do estoque para a semana (música relaxante). | Humanizar a marca. |

## Estratégia de Imagens e Vídeos

1.  **Imagens de Promoção:** Devem ser limpas, com o preço em destaque e a informação de **ATACADO** e **PEDIDO MÍNIMO R$ 199** sempre visível.
2.  **Lançamento:** Focar em vídeos curtos (Reels/TikTok) com música em alta, mostrando a peça em movimento e com transições de câmera.
3.  **Abastecimento de Estoque:** Vídeos curtos e satisfatórios (ASMR de caixas abrindo, pilhas de pijamas) com a legenda: "Seu estoque garantido para a semana! Postagem Imediata." (Gatilho de urgência e eficiência).
4.  **Vídeo Anexado (WhatsAppVideo2026-01-31at09.06.52.mp4):** O vídeo deve ser analisado para replicar o formato de **provador rápido** e **destaque de detalhes** (estampa, tecido) com a modelo. Este formato será a base para os roteiros de Stories e Ads.
