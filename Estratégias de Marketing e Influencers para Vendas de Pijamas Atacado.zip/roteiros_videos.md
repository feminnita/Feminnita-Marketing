# Roteiros de Vídeos para Stories e Ads (Captação de Clientes)

Estes roteiros foram desenvolvidos para serem utilizados tanto em Stories (versão mais curta e direta) quanto em campanhas de Ads (com foco em conversão), utilizando as personas criadas para gerar identificação imediata com o público-alvo.

## Roteiro 1: Renda Extra e Primeiro Investimento (Persona: Carol)

**Público-Alvo:** Pessoas que buscam uma fonte de renda extra e revendedores iniciantes.

| Elemento | Descrição da Cena | Áudio/Texto na Tela |
| :--- | :--- | :--- |
| **Gancho (0-3s)** | Carol (Persona 1) aparece com uma caixa de papelão na mão, com uma expressão de surpresa e satisfação. | **Áudio:** Música animada e em alta. **Texto:** "Comprei R$ 199 em pijamas e olha o que aconteceu!" |
| **Desenvolvimento (4-10s)** | **Corte Rápido:** Carol abre a caixa, mostrando os pijamas da Feminnita. Ela pega um conjunto e mostra a etiqueta de preço de atacado. | **Áudio (Voz da Carol):** "Sério, esse foi o melhor investimento que fiz. O pedido mínimo é só R$ 199, e eu já vendi metade em 2 dias!" |
| **Prova Social (11-15s)** | Carol mostra o celular com mensagens de clientes (simuladas) pedindo os pijamas. | **Texto:** "Lucro de 50% garantido!" |
| **Fechamento/CTA (16-20s)** | Carol sorri e aponta para o link/botão. | **Áudio (Voz da Carol):** "Se você quer uma renda extra, a Feminnita é o caminho. Clique aqui e peça o seu catálogo agora!" |
| **CTA do Ad** | Botão: **"Quero o Catálogo de Atacado"** | |

## Roteiro 2: Qualidade e Variedade para Lojistas (Persona: Renata)

**Público-Alvo:** Lojistas e revendedores experientes (foco em qualidade, variedade e logística).

| Elemento | Descrição da Cena | Áudio/Texto na Tela |
| :--- | :--- | :--- |
| **Gancho (0-3s)** | Renata (Persona 2) aparece em sua loja/escritório, com uma expressão séria e profissional, segurando um pijama de Suede. | **Áudio:** Música de fundo profissional e confiável. **Texto:** "Lojista, seu fornecedor te entrega isso?" |
| **Desenvolvimento (4-10s)** | **Corte Rápido:** Renata mostra detalhes do tecido (close-up), a costura e a etiqueta. Em seguida, mostra a variedade (Plus Size, Masculino, Infantil). | **Áudio (Voz da Renata):** "Na Feminnita, eu garanto a qualidade para minhas clientes. Tecido premium, modelagem perfeita, e o melhor: tem Plus Size e Kits Família para todos os nichos." |
| **Logística (11-15s)** | Imagem de caixas sendo postadas (simulando a **Postagem Imediata**). | **Texto:** "Postagem Imediata e 5% OFF no PIX." |
| **Fechamento/CTA (16-20s)** | Renata aponta para o site. | **Áudio (Voz da Renata):** "Pare de perder vendas por falta de estoque. Cadastre-se como revendedor Feminnita e tenha a melhor logística do mercado." |
| **CTA do Ad** | Botão: **"Cadastre-se como Revendedor"** | |

## Roteiro 3: Compra Coletiva e Economia Familiar (Persona: Vanessa)

**Público-Alvo:** Grupos de amigas, mães e famílias que buscam economia comprando em conjunto.

| Elemento | Descrição da Cena | Áudio/Texto na Tela |
| :--- | :--- | :--- |
| **Gancho (0-3s)** | Vanessa (Persona 3) aparece com a família (ou amigas) vestindo pijamas combinando (Kits Família). | **Áudio:** Música alegre e familiar. **Texto:** "Pijamas para a família toda com preço de atacado!" |
| **Desenvolvimento (4-10s)** | Vanessa mostra a pilha de pijamas e a nota fiscal (simulada) com o valor total e o desconto de atacado. | **Áudio (Voz da Vanessa):** "Eu e minhas amigas/família nos juntamos, batemos o pedido mínimo de R$ 199 e economizamos muito! Saiu muito mais barato do que comprar em loja de varejo." |
| **Benefício (11-15s)** | Cenas de conforto e união (filme no sofá, café da manhã). | **Texto:** "Conforto e economia para todos." |
| **Fechamento/CTA (16-20s)** | Vanessa convida o público a fazer o mesmo. | **Áudio (Voz da Vanessa):** "Chame suas amigas e aproveite o preço de fábrica da Feminnita. Clique no link e organize sua compra coletiva!" |
| **CTA do Ad** | Botão: **"Organizar Compra Coletiva"** | |

## Roteiro para Stories (Conteúdo Diário)

**Formato:** Vídeos curtos (15 segundos) com texto na tela e link de arrastar para cima (ou sticker de link).

| Tema | Roteiro Sugerido |
| :--- | :--- |
| **Lançamento** | **Cena:** Luiza (Persona 4) faz uma transição rápida vestindo o novo pijama. **Texto:** "O Baby Doll Blogueira que acabou de chegar! 💖 Atacado R$ 49,90. Link na bio para ver a coleção." |
| **Estoque** | **Cena:** Vídeo satisfatório de caixas sendo empilhadas. **Texto:** "Seu estoque garantido! Postagem Imediata Feminnita. Fale com nosso time no WhatsApp." |
| **Promoção** | **Cena:** Carol mostra um pijama do Outlet. **Texto:** "Últimas peças no Outlet! Pijamas a partir de R$ 10. Corre antes que acabe! 🏃‍♀️" |
| **Dica de Revenda** | **Cena:** Renata dando uma dica rápida. **Texto:** "Dica de Lojista: O segredo é ter variedade. A Feminnita tem Plus Size, Infantil e Masculino. 🎯" |
