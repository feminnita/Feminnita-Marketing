# Formulário de Credenciamento - Tray Commerce API

## 📋 Dados do Integrador

**Nome da Empresa:** Feminnita Pijamas

**Telefone:** (22) 99281-0707

**E-mail:** [feminnita@gmail.com](mailto:feminnita@gmail.com)

**Site:** www.feminnita.com.br

**Nome do Responsável Técnico:** Christiane Piller Jesus

**E-mail do Responsável Técnico:** christianepj@me.com

---

## 🎯 Dados do Aplicativo

**Nome do Aplicativo:** Feminnita Marketing Automation

**Descrição Simplificada:**Plataforma de automação de marketing integrada ao Bling ERP para gerenciar campanhas em múltiplos canais (Meta, Instagram, TikTok, Facebook, WhatsApp, Email).

**Descrição Completa:**A Feminnita Marketing Automation é uma plataforma inteligente de automação de marketing desenvolvida especificamente para empresas de atacado de pijamas. Integrada ao Bling ERP e à Tray Commerce, oferece uma solução completa que conecta gestão de estoque, vendas e estratégia de marketing em um único dashboard.

Nossa plataforma permite que lojistas, revendedoras e empreendedoras automatizem campanhas de marketing, gerenciem múltiplos canais (Instagram, TikTok, Facebook, WhatsApp, Email) e utilizem inteligência artificial para criar conteúdo personalizado através de 4 personas virtuais autônomas.

**Logo da Aplicação:** femininita_sem_lingerie.png

**URL de Callback (SSL):**

```
https://feminnita.manus.space/api/oauth/tray/callback
```

**ID da Loja:** 1312849

**Link do Vídeo (YouTube ):** [Opcional - deixar em branco se não tiver]

**URLs de Imagens (máximo 3):**

1. [URL da imagem 1]

1. [URL da imagem 2]

1. [URL da imagem 3]

---

## 📤 Como Enviar

1. Acesse: [https://www.tray.com.br/parceiros/quero-ser-parceiro/](https://www.tray.com.br/parceiros/quero-ser-parceiro/)

1. Preencha o formulário com os dados acima

1. Aguarde a aprovação da Tray (geralmente 2-5 dias úteis )

1. Após aprovação, você receberá:
  - **Consumer Key**
  - **Consumer Secret**

---

## ✅ Próximos Passos

Quando você receber as credenciais (Consumer Key e Consumer Secret), envie para mim que vou:

1. ✅ Integrar a API da Tray Commerce

1. ✅ Sincronizar produtos automaticamente

1. ✅ Sincronizar pedidos em tempo real

1. ✅ Atualizar estoque automaticamente

1. ✅ Criar testes Vitest

