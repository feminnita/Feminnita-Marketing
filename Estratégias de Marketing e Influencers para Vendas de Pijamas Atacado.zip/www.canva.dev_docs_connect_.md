
**URL:** https://www.canva.dev/docs/connect/

---

Skip navigation

Skip to main content

Home
Documentation
Solutions
Blogs
Your apps
Your integrations
Getting started
Overview
Quickstart
Creating integrations
Reference apps
Dev MCP server
Fundamentals
API requests & responses
Authentication
API versions
Canva concepts
Security
Shared responsibility model
Examples
Autofill guide
Return navigation guide
Guidelines
Brand
Recommended practices
User interface
Distributing integrations
Submission checklist
Submitting integrations
API reference
Authentication
Assets
Autofill
Brand templates
Comments
Designs
Design imports
Exports
Folders
Resizes