# Personas de Influenciadoras Humanizadas para Feminnita

Para maximizar o impacto das campanhas de marketing e criar uma conexão autêntica com os diferentes segmentos do público-alvo da Feminnita (atacado), foram desenvolvidas quatro personas de influenciadoras, cada uma representando um perfil de cliente potencial. A humanização dessas figuras é essencial para gerar confiança e identificação, elementos cruciais no nicho de revenda.

## 1. Carol, a Empreendedora Iniciante (Foco: Renda Extra)

| Característica | Descrição |
| :--- | :--- |
| **Nome/Idade** | Carol, 24 anos |
| **História** | Estudante universitária ou recém-formada, mora com os pais e busca uma fonte de **renda extra** para pagar a faculdade ou ter sua independência financeira. Não tem experiência prévia em vendas, mas é muito ativa nas redes sociais. |
| **Público-Alvo** | Pessoas que buscam o primeiro negócio, mães que precisam de flexibilidade de horário, e quem tem R$ 200 para investir. |
| **Estilo de Conteúdo** | **Autêntico e Entusiasmado.** Vídeos no formato "Diário de uma Revendedora", mostrando o "unboxing" do pedido mínimo de R$ 199,00, a primeira venda, e dicas simples de como abordar clientes. O foco é na **facilidade** de começar e no **lucro rápido**. |
| **Ganchos de Vídeo** | "Comprei R$ 199 em pijamas e olha quanto lucrei!", "Como ter renda extra sem sair de casa", "Meu primeiro pedido Feminnita chegou!". |
| **Palavras-Chave** | #RendaExtra #PrimeiroNegócio #EmpreendedorismoFeminino #FeminnitaLucroFácil |

## 2. Renata, a Dona de Loja (Foco: Crescimento e Qualidade)

| Característica | Descrição |
| :--- | :--- |
| **Nome/Idade** | Renata, 38 anos |
| **História** | Já é dona de uma loja física ou e-commerce de moda íntima ou presentes. Busca **fornecedores confiáveis** com **qualidade** e **variedade** (Plus Size, Masculino, Infantil) para aumentar sua margem de lucro e fidelizar clientes. |
| **Público-Alvo** | Lojistas, revendedores experientes, empreendedores que buscam escala. |
| **Estilo de Conteúdo** | **Profissional e Informativo.** Foca na **qualidade do tecido** (Suede, Canelado, Algodão), na modelagem (Plus Size), na **postagem imediata** e nas **condições de pagamento** (3x sem juros). Vídeos no formato "Dicas de Fornecedor" e "Tour pelo Estoque". |
| **Ganchos de Vídeo** | "O segredo do meu lucro: Fornecedor de Pijamas com 5% OFF no PIX", "Tecidos que vendem sozinhos: Análise de Qualidade Feminnita", "Como o Plus Size aumentou meu faturamento". |
| **Palavras-Chave** | #AtacadoDePijamas #FornecedorConfiável #MargemDeLucro #ModaIntimaAtacado |

## 3. Vanessa, a Líder de Grupo (Foco: Economia e Família)

| Característica | Descrição |
| :--- | :--- |
| **Nome/Idade** | Vanessa, 45 anos |
| **História** | Mãe de família, muito ligada a amigas, primas e vizinhas. Seu foco é a **economia** e o **conforto** de todos. Ela organiza **compras coletivas** para atingir o atacado e aproveitar o preço baixo para toda a família. |
| **Público-Alvo** | Grupos de compra, famílias grandes, amigas que compram juntas. |
| **Estilo de Conteúdo** | **Prático e Afetivo.** Mostra a praticidade dos **Kits Família** e a economia de comprar no atacado para uso próprio. Conteúdo focado no bem-estar e na união familiar. |
| **Ganchos de Vídeo** | "Compramos pijamas para a família inteira no atacado e economizamos R$ 500!", "Kits Família: O pijama perfeito para a noite do filme", "Como convencer suas amigas a fazerem uma compra coletiva". |
| **Palavras-Chave** | #CompraColetiva #PijamaFamília #EconomiaFamiliar #ConfortoEmCasa |

## 4. Luiza, a Trendsetter (Foco: Estilo e Tendência)

| Característica | Descrição |
| :--- | :--- |
| **Nome/Idade** | Luiza, 21 anos |
| **História** | Fashionista, antenada nas tendências do TikTok e Instagram. Vê o pijama não apenas como roupa de dormir, mas como **loungewear** e peça de moda. Seu foco é no **estilo** e na **versatilidade** das peças. |
| **Público-Alvo** | Jovens, público que valoriza a estética, revendedores que focam em moda e tendências. |
| **Estilo de Conteúdo** | **Visual e Dinâmico.** Vídeos com transições rápidas (antes/depois), mostrando como usar o pijama em casa com estilo e até mesmo a tendência de "Pijama na Rua". Foca nas estampas mais "blogueiras" e nos modelos mais modernos (Baby Doll Blogueira, Camisão). |
| **Ganchos de Vídeo** | "Transformação: Do look do dia para o look da noite com o mesmo pijama!", "Tendência 2026: Pijamas que você pode usar na rua", "O Baby Doll Blogueira que está esgotando o estoque!". |
| **Palavras-Chave** | #Loungewear #PijamaNaRua #ModaTikTok #EstiloConfortável #BabyDollBlogueira |
