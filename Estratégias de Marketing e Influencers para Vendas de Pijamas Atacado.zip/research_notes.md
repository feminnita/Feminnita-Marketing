# Pesquisa Inicial - Feminnita e Mercado de Pijamas

## Dados da Feminnita
- **Site:** www.feminnita.com.br
- **Pedido Mínimo:** R$ 199,00 (Acessível para quem busca renda extra).
- **Público-alvo:** Atacado (revendedores, sacoleiras, grupos de amigos/família).
- **Produtos:** Pijamas femininos (curto, longo, capri), masculinos, plus size, infantis, kits família, verão, outlet.
- **Diferenciais:** 5% OFF no PIX, postagem imediata, suporte via WhatsApp, parcelamento em até 3x sem juros.
- **Preços observados:** Baby doll a partir de R$ 10,00 (promoção), conjuntos média de R$ 30-50.

## Tendências TikTok/Instagram (Concorrentes e Virais)
- **Ganchos de Renda Extra:** "Como faturar R$ 1800 vendendo pijamas", "Renda extra de R$ 600/mês".
- **Estilo de Vídeo:** 
    - Mostrando a "montagem de pedido" (transmite confiança e volume).
    - "Tour pela fábrica/loja" (autoridade de fabricante).
    - Provadores rápidos com transições (dinamismo).
    - Foco em estampas "fofas" e personagens (Disney, Capivara, etc).
    - Tendência 2026: Pijamas que podem ser usados na rua (estilo loungewear).
- **Preços de Atacado Concorrentes:** Kits a partir de R$ 147 por 10 conjuntos (aprox. R$ 14,70 cada). A Feminnita está competitiva.

## Estratégia de Influenciadoras (Personas)
1. **A Empreendedora Iniciante:** Jovem, busca independência financeira, mostra o "unboxing" do primeiro pedido de R$ 199.
2. **A Dona de Loja Física/Online:** Mais profissional, foca em margem de lucro e qualidade do tecido (Suede, Algodão).
3. **A "Mãe Festeira" / Líder de Grupo:** Organiza compras coletivas para família e amigas para economizar.
4. **A Fashionista/Trendsetter:** Foca no estilo, mostra como o pijama é lindo e confortável para o dia a dia.
