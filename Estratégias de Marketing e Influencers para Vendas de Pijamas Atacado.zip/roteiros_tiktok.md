# Três Roteiros de Vídeo Curtos para TikTok - Personas Específicas

Estes roteiros foram desenvolvidos para aproveitar os formatos virais do TikTok, com foco em ganchos irresistíveis, transições dinâmicas, áudio em alta e chamadas para ação claras. Cada roteiro tem 20-30 segundos e é otimizado para o algoritmo do TikTok.

---

## Roteiro 1: Carol - "Como Ganhei R$ 500 em 1 Semana Vendendo Pijamas" (Formato: Antes/Depois)

**Duração:** 25 segundos  
**Persona:** Carol (Empreendedora Iniciante, 24 anos)  
**Formato Viral:** Transformação/Antes-Depois com transições rápidas  
**Objetivo:** Captar atenção de pessoas que buscam renda extra  
**Plataforma:** TikTok (otimizado para FYP - For You Page)  

### Estrutura Detalhada

| Tempo | Descrição da Cena | Transição | Áudio | Texto na Tela | Efeito Visual |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **0-2s** | **GANCHO:** Carol em primeiro plano, expressão séria/pensativa, com a mão no queixo | Nenhuma (estática) | Música viral em alta (upbeat, tipo "Levitating" ou som similar) | "Eu: Desempregada" | Filtro preto e branco ou sépia |
| **2-3s** | **TRANSIÇÃO:** Carol pisca ou faz movimento rápido | Corte seco/Zoom rápido | Continuação da música | "Até que..." | Efeito de transição (zoom ou spin) |
| **3-5s** | **TRANSFORMAÇÃO:** Carol com pijama Feminnita, sorrindo, segurando dinheiro (notas simuladas) | Corte seco | Música continua, som de dinheiro (ding!) | "Eu: Ganho R$ 500/semana!" | Filtro colorido ou efeito de brilho |
| **5-8s** | **PROVA SOCIAL:** Rápido montage de 3-4 screenshots de mensagens de clientes (WhatsApp simulado) | Corte rápido entre cada screenshot | Notificação de WhatsApp (som) | "Meus clientes: 'Quero 5 pijamas!'" | Zoom leve em cada screenshot |
| **8-12s** | **DETALHE DO PRODUTO:** Close-up do pijama sendo mostrado, câmera faz zoom na etiqueta de preço | Zoom suave | Voz de Carol: "Compro por R$ 39,90" | "Vendo por R$ 79,90" | Destaque em amarelo/rosa na etiqueta |
| **12-15s** | **LUCRO EM NÚMEROS:** Carol aponta para câmera com expressão confiante, números aparecem na tela | Corte seco | Voz de Carol: "Lucro de 50%!" | "50% de Lucro Garantido! 💰" | Animação de números crescendo |
| **15-20s** | **ENVOLVIMENTO:** Carol faz pergunta para câmera (close-up rosto) | Nenhuma | Voz de Carol: "Quer começar também?" | "Você também pode!" | Sem efeitos (autêntico) |
| **20-25s** | **CTA FINAL:** Carol aponta para câmera com sorriso, link aparece na tela | Corte seco | Voz de Carol: "Clique no link da bio!" + Som de sucesso (ding!) | "Link na Bio ⬆️ #RendaExtra" | Animação de seta apontando para cima |

### Elementos Técnicos TikTok

**Áudio:** Use som viral do TikTok (busque "Levitating" ou sons de sucesso/motivação em alta). Mantenha a voz de Carol clara mesmo com música de fundo.

**Transições:** Cortes secos rápidos (nada de transições suaves—TikTok favorece dinamismo). Use zoom rápido em momentos-chave.

**Hashtags:** #RendaExtra #PrimeiroNegócio #FeminnitaLucro #ComoGanharDinheiro #EmpreendedorismoFeminino #VendaPijamas #TikTokBrasil

**Duração Ideal:** 25 segundos (mantém engajamento sem perder atenção)

**Dicas de Gravação:**
- Use iluminação natural (janela) ou luz branca
- Grave em vertical (9:16 aspect ratio)
- Mantenha movimento constante (câmera dinâmica, não estática)
- Coloque o texto na tela em letras grandes e coloridas
- Reposte a cada 3-4 dias com pequenas variações (diferentes roupas, cenários)

---

## Roteiro 2: Renata - "Lojista Revela o Segredo da Margem de Lucro" (Formato: Educacional/Dica)

**Duração:** 28 segundos  
**Persona:** Renata (Dona de Loja, 38 anos)  
**Formato Viral:** Dica Rápida/Educacional com Autoridade  
**Objetivo:** Captar lojistas e revendedores experientes  
**Plataforma:** TikTok (otimizado para FYP e Explore)  

### Estrutura Detalhada

| Tempo | Descrição da Cena | Transição | Áudio | Texto na Tela | Efeito Visual |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **0-2s** | **GANCHO:** Renata em seu escritório/loja, expressão séria e profissional | Nenhuma | Música profissional (instrumental, tipo lo-fi ou motivacional) | "Lojista: Quer Aumentar Lucro?" | Sem filtro (profissional) |
| **2-4s** | **PROBLEMA:** Renata mostra uma nota fiscal com preço alto de outro fornecedor | Corte seco | Voz de Renata: "Seu fornecedor te cobra quanto?" | "Fornecedor A: R$ 60 por peça" | Zoom na nota fiscal |
| **4-6s** | **TRANSIÇÃO:** Renata faz gesto de "não" com a cabeça, expressão desaprovadora | Corte seco | Som de "erro" (buzzer) | "Muito Caro! ❌" | Efeito de shake/vibração |
| **6-9s** | **SOLUÇÃO:** Renata mostra um pijama Feminnita e a etiqueta de preço | Corte seco | Voz de Renata: "Feminnita: R$ 39,90 por peça" | "Feminnita: R$ 39,90 ✅" | Destaque em verde na etiqueta |
| **9-12s** | **ANÁLISE TÉCNICA:** Close-up: Renata mostra a costura, tecido e qualidade | Zoom suave | Voz de Renata: "Mesma qualidade, preço menor" | "Mesma Qualidade, Melhor Preço!" | Zoom em detalhes (costura, tecido) |
| **12-15s** | **CÁLCULO DE LUCRO:** Números aparecem na tela (Fornecedor A vs Feminnita) | Animação de números | Voz de Renata: "Veja a diferença" | "Lucro: R$ 20 vs R$ 40 por peça" | Animação de números crescendo em verde |
| **15-19s** | **PROVA SOCIAL:** Rápido montage de 2-3 depoimentos de lojistas (texto ou áudio) | Corte rápido | Áudio de depoimentos ou som de aprovação | "Lojistas: 'Aumentei 40% de lucro!'" | Zoom em cada depoimento |
| **19-24s** | **CALL TO ACTION:** Renata aponta para câmera com confiança | Corte seco | Voz de Renata: "Cadastre-se como revendedor" | "Cadastre-se Agora! 📲" | Sem efeitos (direto) |
| **24-28s** | **FECHAMENTO:** Renata segura o pijama em destaque, link aparece | Corte seco | Voz de Renata: "Link na bio para mais info" + Som de sucesso | "Link na Bio para Cadastro ⬆️" | Animação de seta |

### Elementos Técnicos TikTok

**Áudio:** Use som profissional/motivacional (instrumental). Mantenha a voz de Renata clara e confiante.

**Transições:** Cortes secos, zoom em detalhes técnicos. Nada de efeitos muito lúdicos (profissionalismo é importante).

**Hashtags:** #AtacadoPijamas #FornecedorConfiável #DicaParaLojista #MargemDeLucro #RevendedorPijamas #NegócioOnline #TikTokBrasil

**Duração Ideal:** 28 segundos (tempo suficiente para demonstrar valor técnico)

**Dicas de Gravação:**
- Ambiente profissional mas acessível (escritório, loja)
- Iluminação clara e branca (profissionalismo)
- Mantenha expressão séria mas amigável
- Use gráficos/números na tela para reforçar mensagem
- Reposte a cada 4-5 dias com diferentes produtos/comparações

---

## Roteiro 3: Vanessa - "Compra Coletiva: Como Economizei R$ 250" (Formato: Lifestyle/Comunidade)

**Duração:** 30 segundos  
**Persona:** Vanessa (Líder de Grupo, 45 anos)  
**Formato Viral:** Lifestyle/Comunidade com Humor e Emoção  
**Objetivo:** Captar grupos de amigas e famílias que buscam economia  
**Plataforma:** TikTok (otimizado para FYP com foco em engajamento emocional)  

### Estrutura Detalhada

| Tempo | Descrição da Cena | Transição | Áudio | Texto na Tela | Efeito Visual |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **0-2s** | **GANCHO:** Vanessa com 2-3 amigas/familiares em casa, todas com expressão de dúvida | Nenhuma | Música alegre e descontraída (tipo "Good as Hell" ou som similar) | "Amigas: 'Pijama é caro!'" | Filtro colorido ou efeito de brilho |
| **2-4s** | **PROBLEMA:** Montage rápida mostrando preços altos em lojas (screenshots ou imagens) | Corte rápido | Áudio de frustração ou som de "não" | "Loja: R$ 80 por peça" ❌ | Efeito de shake/vibração |
| **4-6s** | **IDEIA:** Vanessa tem uma ideia (lâmpada aparece na tela ou expressão de "eureka") | Corte seco com efeito | Voz de Vanessa: "E se a gente comprasse junto?" | "Ideia Brilhante! 💡" | Efeito de lâmpada ou estrelas |
| **6-10s** | **AÇÃO:** Montage rápida de amigas escolhendo pijamas, conversando, rindo | Corte rápido entre cenas | Voz de Vanessa: "Cada uma escolhe o seu!" + Som de risadas | "Escolhendo Juntas! 👯‍♀️" | Zoom em cada pessoa, cores vibrantes |
| **10-14s** | **RESULTADO:** Vanessa mostra a nota fiscal final com o valor economizado destacado | Corte seco | Voz de Vanessa: "Olha só quanto economizamos!" + Som de dinheiro (ding!) | "De R$ 800 → R$ 550! 💰" | Animação de números descendo em verde |
| **14-18s** | **ECONOMIA POR PESSOA:** Cálculo rápido aparece na tela | Animação de números | Voz de Vanessa: "R$ 250 economizados!" | "R$ 250 de Economia! 🎉" | Confete animado ou efeito de celebração |
| **18-23s** | **SATISFAÇÃO:** Cena de todas vestindo os pijamas novos, sentadas juntas, rindo e se abraçando | Corte rápido | Música alegre continua, som de risadas | "Conforto + Economia = Felicidade!" | Sem efeitos (autêntico e genuíno) |
| **23-27s** | **CONVITE:** Vanessa aponta para câmera com sorriso contagiante | Corte seco | Voz de Vanessa: "Vocês também podem fazer isso!" | "Marque Suas Amigas! 👇" | Sem efeitos (direto) |
| **27-30s** | **CTA FINAL:** Vanessa segura o celular mostrando o link | Corte seco | Voz de Vanessa: "Clique no link da bio!" + Som de sucesso | "Link na Bio ⬆️ #CompraColetiva" | Animação de seta apontando para cima |

### Elementos Técnicos TikTok

**Áudio:** Use som viral alegre e descontraído (tipo "Good as Hell" ou sons de celebração). Mantenha a voz de Vanessa natural e descontraída.

**Transições:** Cortes rápidos e dinâmicos. Use zoom em momentos de emoção (economia, abraços, risadas).

**Hashtags:** #CompraColetiva #PijamaFamília #EconomiaFamiliar #ConfortoEmCasa #DicaDeAmiga #VidaEmComunidade #TikTokBrasil

**Duração Ideal:** 30 segundos (máximo para manter engajamento emocional)

**Dicas de Gravação:**
- Ambiente aconchego (sala de estar, sofá)
- Iluminação quente (aconchego, não profissional)
- Inclua pessoas reais (amigas, familiares)—quanto mais autêntico, melhor
- Capture momentos genuínos de risada e conexão
- Use cores vibrantes nos pijamas para contraste visual
- Reposte a cada 3-4 dias com diferentes grupos de pessoas

---

## Resumo Comparativo dos Três Roteiros TikTok

| Aspecto | Carol | Renata | Vanessa |
| :--- | :--- | :--- | :--- |
| **Duração** | 25s | 28s | 30s |
| **Formato Viral** | Antes/Depois (Transformação) | Educacional/Dica | Lifestyle/Comunidade |
| **Tom** | Entusiasmado, motivador | Profissional, confiante | Alegre, descontraído |
| **Gancho Principal** | Lucro rápido (R$ 500/semana) | Margem de lucro (50% vs 25%) | Economia em grupo (R$ 250) |
| **Transições** | Cortes rápidos, zoom | Zoom técnico, cortes | Cortes rápidos, confete |
| **Áudio** | Música viral upbeat | Som profissional/instrumental | Música alegre descontraída |
| **Público-Alvo** | Iniciantes, desempregados | Lojistas experientes | Grupos de amigas/família |
| **CTA Primária** | "Clique no link da bio!" | "Cadastre-se como revendedor!" | "Marque suas amigas!" |
| **Emoção Dominante** | Esperança, sucesso | Segurança, confiança | Felicidade, comunidade |
| **Hashtags Principais** | #RendaExtra #PrimeiroNegócio | #AtacadoPijamas #FornecedorConfiável | #CompraColetiva #PijamaFamília |

---

## Dicas Gerais de Produção para TikTok

### 1. Otimização para Algoritmo

O algoritmo do TikTok favorece vídeos que geram engajamento nos primeiros 3 segundos. Portanto, o gancho é crucial. Mantenha a atenção do espectador com transições dinâmicas, mudanças de cenário e áudio em alta.

### 2. Qualidade de Vídeo

Grave em vertical (9:16 aspect ratio) com boa iluminação. Use câmera do celular em 1080p ou superior. Evite vídeos muito escuros ou com áudio baixo—o TikTok penaliza vídeos com qualidade ruim.

### 3. Áudio é Tudo

Use sons virais do TikTok. Acesse a biblioteca de áudio do app e escolha sons que estão em alta. A música de fundo deve estar em volume alto (não abafe a voz). Mantenha a voz clara e confiante.

### 4. Texto na Tela

Use letras grandes, coloridas e legíveis. O texto deve reforçar a mensagem do vídeo, não apenas repetir o que está sendo dito. Coloque o texto em posições estratégicas (não cubra o rosto das pessoas).

### 5. Timing de Postagem

Poste nos horários de pico do TikTok: 6h-9h (manhã), 12h-14h (almoço) e 19h-23h (noite). Reposte a cada 3-4 dias com pequenas variações para testar qual versão gera mais views.

### 6. Engajamento

Responda aos comentários rapidamente. Use a função "Dueto" e "Stitches" para criar conteúdo que responda a comentários ou crie conversas. Isso aumenta o algoritmo e a visibilidade.

### 7. Replicação e Testes

Após gravar os vídeos, replique com pequenas variações:
- **Carol:** Diferentes roupas, diferentes produtos, diferentes ambientes (casa, rua, loja)
- **Renata:** Diferentes produtos, diferentes comparações de preço, diferentes lojistas
- **Vanessa:** Diferentes grupos de pessoas, diferentes pijamas, diferentes cenários

### 8. Análise de Desempenho

Use o TikTok Analytics (disponível para contas de negócio) para acompanhar:
- **Views:** Quantas pessoas viram o vídeo
- **Completion Rate:** Percentual de pessoas que assistiram até o final
- **Engagement Rate:** Curtidas, comentários, compartilhamentos
- **Click-Through Rate:** Quantas pessoas clicaram no link da bio

Identifique qual persona gera mais engajamento e replique esse formato com frequência.

### 9. Hashtags Estratégicas

Use 3-5 hashtags por vídeo. Combine hashtags virais (#FYP #ForYouPage) com hashtags de nicho (#RendaExtra #AtacadoPijamas). Evite usar mais de 5 hashtags—o TikTok penaliza spam.

### 10. Chamada para Ação

Sempre termine com uma CTA clara. Use frases como "Clique no link da bio", "Marque uma amiga", "Comente sua opinião". Quanto mais específica a CTA, melhor o engajamento.
