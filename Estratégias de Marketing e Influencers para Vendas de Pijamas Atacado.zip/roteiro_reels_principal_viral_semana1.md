# Roteiro de Vídeo Completo - Reels Principal/Viral Semana 1
## "Bastidores da Campanha Feminnita - Veja Como Fazemos Acontecer!"

---

## INFORMAÇÕES GERAIS

**Reels:** #2 (Semana 1, Sexta-feira 20h)

**Tipo:** Behind-the-Scenes (BTS) + Lançamento

**Duração:** 45 segundos (formato Reels padrão)

**Plataforma:** Instagram Reels

**Objetivo Principal:** Viralizar + Humanizar marca + Gerar engajamento máximo + Direcionar para lançamento

**Objetivo Secundário:** Aumentar seguidores, gerar saves, preparar audiência para promoção

**Público-Alvo:** 
- Seguidoras atuais (18-50 anos)
- Potenciais clientes (pessoas que buscam pijamas de qualidade)
- Pessoas que amam bastidores/processo criativo

**Tone of Voice:** Autêntico, entusiasmado, descontraído, humanizado, profissional

**Hashtags Principais:** #BastidoresFeminnita #BeautifulChaos #ProcessoCriativo #MakingOf #Feminnita #LançamentoInverno

---

## ESTRATÉGIA DE GANCHO (0-3 SEGUNDOS)

### Por Que o Gancho é Crítico?

No Instagram Reels, **os primeiros 3 segundos determinam se a pessoa vai continuar assistindo**. Se não capturar atenção nos primeiros 3 segundos, a pessoa vai pular para o próximo vídeo. Isso é científico: estudos mostram que 50% das pessoas que veem um Reels decidem em 3 segundos se vão continuar.

### Opções de Gancho (Escolha 1)

#### OPÇÃO 1: Caos Criativo (RECOMENDADO - Maior Viralidade)

**Descrição Visual:**
Plano aberto mostrando estúdio/espaço de produção em "caos criativo". Múltiplas pessoas em movimento, várias coisas acontecendo simultaneamente:
- Alguém correndo com pijama na mão
- Outra pessoa ajustando luz
- Terceira pessoa olhando para câmera
- Pijamas espalhados
- Movimento rápido, energia alta

**Áudio:**
Trending sound viral + efeito sonoro de "whoosh" (transição rápida) + vozes rindo/falando ao fundo (40% volume)

**Texto na Tela:**
"Tá vendo esse caos? 🎬✨"
- Fonte: Poppins Bold, tamanho grande
- Cor: Branco com contorno preto
- Posição: Topo central
- Animação: Zoom in rápido (0.5s)

**Transição:**
Corte rápido com efeito de zoom/spin para próxima cena

**Por Que Funciona:**
- Caos criativo é visualmente interessante e diferente
- Movimento rápido prende atenção
- Pergunta no texto cria curiosidade
- Emojis adicionam diversão
- Trending sound aumenta chances de viralizar

**Tempo Exato:** 0-3 segundos

---

#### OPÇÃO 2: Pergunta Provocadora (Alternativa)

**Descrição Visual:**
Close-up no rosto de alguém (você ou modelo) com expressão de surpresa/entusiasmo, com pijama novo aparecendo ao fundo desfocado

**Áudio:**
Trending sound + voz em off feminina: "Você está pronto para o melhor pijama do inverno?"

**Texto na Tela:**
"Você está pronto? 👀"

**Por Que Funciona:**
- Pergunta direta cria engajamento
- Close-up emocional conecta com audiência
- Simplicidade é poderosa

**Tempo Exato:** 0-3 segundos

---

#### OPÇÃO 3: Reveal Rápido (Alternativa)

**Descrição Visual:**
Tela preta → Flash de luz branca → Pijama aparece em primeiro plano com efeito de "pop"

**Áudio:**
Trending sound + efeito sonoro de "ding" ou "tada"

**Texto na Tela:**
"Chegou! 🎉"

**Por Que Funciona:**
- Efeito visual é impactante
- Reveal cria satisfação visual
- Rápido e dinâmico

**Tempo Exato:** 0-3 segundos

---

### Gancho Recomendado: OPÇÃO 1 (Caos Criativo)

**Justificativa:**
- Maior potencial de viralidade (estudos mostram que caos criativo gera 20-30% mais saves)
- Mais humanizado (mostra trabalho real)
- Mais engajador (pergunta cria curiosidade)
- Mais memorável (diferente de outros Reels)

---

## ROTEIRO DETALHADO - 45 SEGUNDOS

### ESTRUTURA GERAL

```
0-3s:   GANCHO - Caos criativo
        ↓
3-12s:  PREPARAÇÃO - Setup iluminação, pijamas, câmera
        ↓
12-30s: AÇÃO - Modelo, fotógrafo, equipe, edição
        ↓
30-40s: RESULTADO - Fotos finais, celebração
        ↓
40-45s: CTA - Mensagem equipe, chamada para ação
```

---

## CENA 1: GANCHO (0-3 SEGUNDOS)

**Timing:** Exatamente 3 segundos

**Descrição Visual:**

Plano aberto (wide shot) mostrando estúdio/espaço de produção. Múltiplas pessoas em movimento simultâneo:

**Subcena 1.1 (0-1s):** Caos Geral
- Câmera: Wide shot, ângulo ligeiramente elevado (mostra mais espaço)
- Pessoas: Mínimo 3-4 pessoas visíveis, todas em movimento
- Movimento: Rápido, dinâmico, mas não frenético
- Iluminação: Bem iluminado, cores vibrantes visíveis
- Foco: Levemente desfocado (depth of field raso) para criar movimento

**Subcena 1.2 (1-2s):** Alguém Correndo com Pijama
- Detalhe: Close-up de alguém correndo com pijama na mão
- Expressão: Concentrada, determinada, feliz
- Movimento: Rápido, de um lado para o outro
- Transição: Corte rápido

**Subcena 1.3 (2-3s):** Volta para Wide Shot
- Câmera: Wide shot novamente, mostrando caos geral
- Ação: Alguém levantando os braços, celebrando
- Efeito: Zoom in rápido para próxima cena

**Áudio:**

- **Trending Sound:** 70% volume (escolha um viral do Instagram)
  - Recomendação: Sons que funcionam bem com caos criativo:
    - "Levanta que eu vou contar" (funk)
    - "It's corn!" (viral 2023)
    - "Bom demais" (funk)
    - Qualquer trending sound energético

- **Efeito Sonoro:** 30% volume
  - "Whoosh" (transição rápida)
  - Ou "Ding" (sucesso)
  - Ou "Pop" (explosão)

- **Vozes ao Fundo:** 40% volume
  - Risadas genuínas
  - Conversas ("Vira! Vira!")
  - Não deve ser muito alto, apenas ambiente

**Texto na Tela:**

- **Texto Principal:** "Tá vendo esse caos? 🎬✨"
- **Fonte:** Poppins Bold ou Montserrat Bold
- **Tamanho:** Grande (40-50% da altura da tela)
- **Cor:** Branco (#FFFFFF)
- **Contorno:** Preto (#000000) com 2-3px de espessura
- **Posição:** Topo central (20% do topo)
- **Animação:** Zoom in rápido (0-0.5s), depois fica estático
- **Duração:** 0-3s (aparece durante todo gancho)

**Transição:**

- **Tipo:** Zoom + Spin (90 graus)
- **Duração:** 0.5 segundos
- **Efeito:** Dinâmico, não suave (mantém energia)

**Dicas de Produção:**

1. **Filme em 4K:** Se possível, qualidade máxima
2. **Múltiplos Ângulos:** Filme de frente, lado, acima
3. **Velocidade:** Normal (edite rápido depois)
4. **Luz Natural:** Se possível, combine com artificial
5. **Movimento Real:** Não coreografado, genuíno
6. **Risadas Reais:** Capture momentos genuínos de diversão
7. **Várias Takes:** Grave 3-5 takes diferentes
8. **Edição Rápida:** Cortes de 0.5-1 segundo cada

**Por Que Este Gancho Funciona:**

- ✅ Movimento rápido prende atenção (cientificamente comprovado)
- ✅ Caos criativo é visualmente interessante
- ✅ Pergunta cria curiosidade ("O que é esse caos?")
- ✅ Emojis adicionam diversão e viralidade
- ✅ Trending sound aumenta distribuição do algoritmo
- ✅ Vozes/risadas humanizam a marca
- ✅ Diferente de outros Reels (stand out)
- ✅ Fácil de entender em 3 segundos

---

## CENA 2: PREPARAÇÃO (3-12 SEGUNDOS)

**Timing:** 9 segundos (3 subcenas de 3 segundos cada)

**Descrição Visual:**

Montagem rápida mostrando setup de produção. 3 subcenas principais:

### Subcena 2.1: Setup de Iluminação (3-6 segundos)

**Timing:** 3 segundos

**Descrição Visual:**
- **Ação 1 (3-4s):** Alguém ajustando refletor/luz
  - Close-up nas mãos ajustando
  - Luz acendendo gradualmente
  - Ambiente ficando mais iluminado
  
- **Ação 2 (4-5s):** Câmera mostrando efeito da luz
  - Pijama sendo iluminado
  - Cores ficando mais vibrantes
  - Ambiente transformando

- **Ação 3 (5-6s):** Wide shot mostrando setup completo
  - Refletor posicionado
  - Câmera pronta
  - Ambiente profissional

**Áudio:**
- Trending sound 70% (contínuo)
- Efeito sonoro de "clique" (luz acendendo) 40%
- Vozes coordenando ("Tá bom?") 30%

**Texto na Tela:**
- "Iluminação perfeita ✨"
- Posição: Centro
- Animação: Fade in (0.3s), fica 2s, fade out (0.3s)

**Transição:**
- Corte rápido (0.3s) para próxima subcena

---

### Subcena 2.2: Preparação de Pijamas (6-9 segundos)

**Timing:** 3 segundos

**Descrição Visual:**
- **Ação 1 (6-7s):** Pijamas sendo organizados
  - Close-up em diferentes cores
  - Mãos organizando em linha
  - Cores vibrantes em destaque
  
- **Ação 2 (7-8s):** Alguém passando ferro/ajustando
  - Close-up no ferro passando
  - Tecido ficando perfeito
  - Detalhe de qualidade

- **Ação 3 (8-9s):** Wide shot mostrando pijamas prontos
  - Todos os pijamas alinhados
  - Cores em destaque
  - Profissionalismo

**Áudio:**
- Trending sound 70% (contínuo)
- Efeito sonoro de "swish" (ferro) 40%
- Vozes ("Perfeito!") 30%

**Texto na Tela:**
- "Pijamas prontos 🎨"
- Posição: Centro
- Animação: Fade in (0.3s), fica 2s, fade out (0.3s)

**Transição:**
- Corte rápido (0.3s) para próxima subcena

---

### Subcena 2.3: Preparação de Câmera (9-12 segundos)

**Timing:** 3 segundos

**Descrição Visual:**
- **Ação 1 (9-10s):** Câmera sendo posicionada
  - Tripé sendo ajustado
  - Câmera sendo movida
  - Movimento preciso
  
- **Ação 2 (10-11s):** Alguém olhando pelo visor
  - Close-up no rosto focado
  - Olho na câmera
  - Concentração

- **Ação 3 (11-12s):** Câmera pronta, setup completo
  - Wide shot mostrando tudo pronto
  - Profissionalismo
  - Energia de "vamos começar!"

**Áudio:**
- Trending sound 70% (contínuo)
- Efeito sonoro de "clique" (câmera) 40%
- Vozes ("Tá pronto!") 30%

**Texto na Tela:**
- "Câmera rolando 🎥"
- Posição: Centro
- Animação: Fade in (0.3s), fica 2s, fade out (0.3s)

**Transição:**
- Corte rápido (0.3s) para próxima cena

---

## CENA 3: AÇÃO (12-30 SEGUNDOS)

**Timing:** 18 segundos (4 subcenas de 4-5 segundos cada)

**Descrição Visual:**

Montagem de cenas de gravação em ação. Mostrar dinâmica, movimento, trabalho em equipe.

### Subcena 3.1: Modelo Posando (12-16 segundos)

**Timing:** 4 segundos

**Descrição Visual:**
- **Ação 1 (12-13s):** Modelo posando pose 1
  - Pijama em destaque
  - Expressão natural/feliz
  - Movimento fluido
  
- **Ação 2 (13-14s):** Modelo posando pose 2
  - Ângulo diferente
  - Movimento dinâmico
  - Pijama em destaque
  
- **Ação 3 (14-15s):** Modelo posando pose 3
  - Pose relaxada
  - Expressão genuína
  - Conforto em evidência

- **Ação 4 (15-16s):** Close-up no rosto
  - Expressão feliz
  - Olhando para câmera
  - Conexão com audiência

**Áudio:**
- Trending sound 70%
- Efeitos sonoros leves 30%
- Vozes ("Perfeito! Mais um!") 30%

**Texto na Tela:**
- "Modelo em ação 💃"
- Animação: Fade in/out

**Transição:**
- Corte rápido (0.3s)

---

### Subcena 3.2: Fotógrafo Trabalhando (16-20 segundos)

**Timing:** 4 segundos

**Descrição Visual:**
- **Ação 1 (16-17s):** Fotógrafo capturando fotos
  - Close-up nas mãos na câmera
  - Cliques da câmera (som real)
  - Movimento preciso
  
- **Ação 2 (17-18s):** Fotógrafo direcionando modelo
  - Conversação
  - Gestos de direção
  - Profissionalismo
  
- **Ação 3 (18-19s):** Close-up no rosto do fotógrafo
  - Expressão focada/concentrada
  - Olho no visor
  - Paixão pelo trabalho

- **Ação 4 (19-20s):** Câmera capturando a captura
  - Meta shot (câmera fotografando câmera)
  - Criatividade
  - Profissionalismo

**Áudio:**
- Trending sound 70%
- Efeito sonoro de "clique" da câmera 50% (importante!)
- Vozes ("Ótimo! Próxima!")

**Texto na Tela:**
- "Capturando o momento 📸"
- Animação: Fade in/out

**Transição:**
- Corte rápido (0.3s)

---

### Subcena 3.3: Equipe Colaborando (20-24 segundos)

**Timing:** 4 segundos

**Descrição Visual:**
- **Ação 1 (20-21s):** Alguém ajustando pijama
  - Close-up nas mãos ajustando
  - Detalhe de qualidade
  - Cuidado
  
- **Ação 2 (21-22s):** Outro ajustando luz
  - Movimento simultâneo
  - Trabalho em equipe
  - Sincronização
  
- **Ação 3 (22-23s):** Todos trabalhando juntos
  - Wide shot mostrando equipe
  - Comunicação
  - Harmonia
  
- **Ação 4 (23-24s):** Risadas e celebração
  - Momento de diversão
  - Humanidade
  - Conexão

**Áudio:**
- Trending sound 70%
- Vozes conversando 50%
- Risadas genuínas 40%
- Efeitos sonoros leves 20%

**Texto na Tela:**
- "Trabalho em equipe 👥"
- Animação: Fade in/out

**Transição:**
- Corte rápido (0.3s)

---

### Subcena 3.4: Edição/Revisão (24-30 segundos)

**Timing:** 6 segundos (mais longa para criar tensão)

**Descrição Visual:**
- **Ação 1 (24-26s):** Alguém olhando fotos no computador
  - Close-up na tela
  - Fotos aparecendo
  - Cores vibrantes
  
- **Ação 2 (26-27s):** Expressão de aprovação
  - Sorriso
  - Polegar para cima
  - Satisfação
  
- **Ação 3 (27-28s):** Equipe olhando junto
  - Todos ao redor do computador
  - Reações positivas
  - Celebração
  
- **Ação 4 (28-30s):** Risadas e celebração
  - High-five
  - Abraços
  - Energia positiva

**Áudio:**
- Trending sound 70%
- Efeito sonoro de "ding" (aprovação) 40%
- Risadas e vozes celebrando 50%
- Aplausos (opcional) 30%

**Texto na Tela:**
- "Aprovado! ✅"
- Animação: Zoom in (0.5s), depois fica estático

**Transição:**
- Fade suave (0.5s) para próxima cena

---

## CENA 4: RESULTADO (30-40 SEGUNDOS)

**Timing:** 10 segundos

**Descrição Visual:**

Reveal das fotos finais. Mostrar qualidade, cores, profissionalismo.

### Subcena 4.1: Transição para Galeria (30-33 segundos)

**Timing:** 3 segundos

**Descrição Visual:**
- **Ação 1 (30-31s):** Tela do computador/celular mostrando galeria
  - Fundo preto/escuro
  - Fotos começando a aparecer
  - Efeito de "reveal"
  
- **Ação 2 (31-32s):** Primeira foto aparecendo
  - Pijama em destaque
  - Cores vibrantes
  - Qualidade profissional
  
- **Ação 3 (32-33s):** Zoom in na foto
  - Detalhe de qualidade
  - Cores, textura
  - Profissionalismo

**Áudio:**
- Trending sound 70%
- Efeito sonoro de "whoosh" (reveal) 40%
- Vozes ("Olha que lindo!") 30%

**Texto na Tela:**
- "E o resultado? 🤩"
- Animação: Zoom in (0.5s)

**Transição:**
- Fade suave (0.3s)

---

### Subcena 4.2: Montagem de Fotos Finais (33-37 segundos)

**Timing:** 4 segundos

**Descrição Visual:**
- **Ação 1 (33-34s):** Foto 1 - Pijama azul marinho
  - Close-up, cores vibrantes
  - Modelo usando
  - Qualidade em destaque
  
- **Ação 2 (34-35s):** Foto 2 - Pijama cinza
  - Ângulo diferente
  - Ambiente aconchego
  - Lifestyle
  
- **Ação 3 (35-36s):** Foto 3 - Pijama vinho
  - Detalhe de tecido
  - Qualidade premium
  - Close-up
  
- **Ação 4 (36-37s):** Foto 4 - Pijama preto
  - Modelo em movimento
  - Dinamismo
  - Conforto

**Áudio:**
- Trending sound 70% (em pico)
- Efeitos sonoros de "pop" entre fotos 40%
- Vozes ("Perfeito!") 30%

**Texto na Tela:**
- "Perfeito! 🔥"
- Animação: Zoom in (0.3s) a cada foto

**Transição:**
- Cortes rápidos (0.3s) entre fotos

---

### Subcena 4.3: Equipe Celebrando (37-40 segundos)

**Timing:** 3 segundos

**Descrição Visual:**
- **Ação 1 (37-38s):** Equipe vendo as fotos
  - Wide shot
  - Expressões de satisfação
  - Celebração
  
- **Ação 2 (38-39s):** Abraços, high-fives
  - Movimento de celebração
  - Energia positiva
  - Humanidade
  
- **Ação 3 (39-40s):** Câmera capturando alegria
  - Close-up em rostos felizes
  - Energia contagiante
  - Conexão

**Áudio:**
- Trending sound 70% (em pico)
- Efeitos sonoros de sucesso (sino, aplausos) 50%
- Vozes celebrando ("Conseguimos!") 40%

**Texto na Tela:**
- "Missão cumprida! 🎉"
- Animação: Zoom in (0.5s)

**Transição:**
- Fade suave (0.5s) para próxima cena

---

## CENA 5: CTA (40-45 SEGUNDOS)

**Timing:** 5 segundos (CRÍTICO - Onde a conversão acontece)

**Descrição Visual:**

Volta para a equipe, olhando para câmera. Mensagem clara e engajadora.

### Subcena 5.1: Mensagem da Equipe (40-42 segundos)

**Timing:** 2 segundos

**Descrição Visual:**
- **Ação 1 (40-41s):** Alguém (ou vários) olhando para câmera
  - Expressão amigável
  - Genuína
  - Confiante
  
- **Ação 2 (41-42s):** Ambiente de estúdio/produção ao fundo
  - Desfocado
  - Profissionalismo
  - Contexto

**Áudio:**
- Trending sound 60% (reduzido)
- Voz em off feminina ou fala genuína 80%
- Frase: "Muito trabalho, muito amor, e muito resultado para vocês! 💖"

**Texto na Tela:**
- "Muito trabalho, muito amor! 💖"
- Posição: Centro
- Tamanho: Grande
- Cor: Branco com contorno preto
- Animação: Fade in (0.3s), fica 1.5s

**Transição:**
- Fade suave (0.3s)

---

### Subcena 5.2: CTA Final (42-45 segundos)

**Timing:** 3 segundos (MAIS IMPORTANTE)

**Descrição Visual:**
- **Ação 1 (42-43s):** Equipe fazendo gesto
  - Coração com mão
  - Polegar para cima
  - Ou alguém falando direto para câmera
  
- **Ação 2 (43-44s):** Olhar direto para câmera
  - Conexão visual
  - Genuinidade
  - Convite
  
- **Ação 3 (44-45s):** Fade out lento
  - Música diminuindo
  - Transição para próximo conteúdo

**Áudio:**
- Trending sound 40% (diminuindo)
- Voz em off feminina 80%
- Frase: "Deixa seu ❤️ nos comentários! Vocês amaram? 👇"

**Texto na Tela:**
- "Deixa seu ❤️ nos comentários! 👇"
- Posição: Centro/Inferior
- Tamanho: Grande
- Cor: Branco com contorno preto
- Animação: Zoom in (0.3s), fica 2s, zoom out (0.3s)

**Elemento Adicional:**
- Sticker de "Comentar" (opcional, se Instagram permitir)
- Ou seta apontando para comentários

**Transição:**
- Fade to black (0.5s)

---

## ESPECIFICAÇÕES TÉCNICAS COMPLETAS

### Vídeo

- **Resolução:** 1080x1920px (Reels padrão)
- **Aspect Ratio:** 9:16 (vertical)
- **Frame Rate:** 30fps (ou 60fps para slow motion)
- **Codec:** H.264
- **Bitrate:** 8-10 Mbps (alta qualidade)
- **Duração:** 45 segundos (exato)

### Áudio

- **Trending Sound:** 70% volume (escolha viral do Instagram)
- **Efeitos Sonoros:** 30-50% volume (variável por cena)
- **Vozes/Fala:** 80% volume (importante!)
- **Música de Fundo:** Opcional, 20-30% volume
- **Mix Final:** Equilibrado, sem picos, sem distorção

### Edição

- **Software Recomendado:** 
  - CapCut (gratuito, fácil)
  - Adobe Premiere Pro (profissional)
  - DaVinci Resolve (gratuito, profissional)
  - Final Cut Pro (Mac)

- **Transições:** Dinâmicas mas não excessivas
  - Cortes rápidos (0.3s)
  - Zoom in/out (0.5s)
  - Fade suave (0.5s)
  - Spin (0.3s)

- **Efeitos:** Mínimos, foco no conteúdo
  - Zoom in/out
  - Fade in/out
  - Nenhum efeito "gamer"

- **Cor:** 
  - Saturação: Normal a +10%
  - Contraste: Normal a +5%
  - Brilho: Normal
  - Temperatura: Quente (para aconchego)

- **Velocidade:** 
  - Normal: 1x
  - Slow motion: 0.5x (para momentos especiais)
  - Fast motion: 1.5x (para caos/ação)

---

## TIMELINE DETALHADA (45 SEGUNDOS)

| Tempo | Cena | Subcena | Descrição | Áudio | Texto |
|-------|------|---------|-----------|-------|-------|
| 0-3s | GANCHO | Caos Criativo | Equipe em movimento, caos | Trending + whoosh | "Tá vendo esse caos? 🎬✨" |
| 3-6s | PREP | Iluminação | Refletor sendo ajustado | Trending + clique | "Iluminação perfeita ✨" |
| 6-9s | PREP | Pijamas | Pijamas sendo organizados | Trending + swish | "Pijamas prontos 🎨" |
| 9-12s | PREP | Câmera | Câmera sendo posicionada | Trending + clique | "Câmera rolando 🎥" |
| 12-16s | AÇÃO | Modelo | Modelo posando | Trending + vozes | "Modelo em ação 💃" |
| 16-20s | AÇÃO | Fotógrafo | Fotógrafo capturando | Trending + cliques | "Capturando o momento 📸" |
| 20-24s | AÇÃO | Equipe | Trabalho em equipe | Trending + risadas | "Trabalho em equipe 👥" |
| 24-30s | AÇÃO | Edição | Revisão de fotos | Trending + ding | "Aprovado! ✅" |
| 30-33s | RESULTADO | Transição | Fotos na tela | Trending + whoosh | "E o resultado? 🤩" |
| 33-37s | RESULTADO | Fotos | Montagem de fotos | Trending + pops | "Perfeito! 🔥" |
| 37-40s | RESULTADO | Celebração | Equipe celebrando | Trending + aplausos | "Missão cumprida! 🎉" |
| 40-42s | CTA | Mensagem | Equipe para câmera | Trending + voz | "Muito trabalho, muito amor! 💖" |
| 42-45s | CTA | Final | Gesto/fala final | Trending + voz | "Deixa seu ❤️ nos comentários! 👇" |

---

## DICAS DE PRODUÇÃO

### Antes de Gravar

1. **Planejamento:**
   - Faça storyboard visual (desenhos/fotos)
   - Liste exatamente quais cenas precisa
   - Defina quem fará o quê
   - Prepare locação

2. **Equipamento:**
   - Câmera (celular de boa qualidade é suficiente)
   - Tripé
   - Iluminação (natural + artificial)
   - Áudio (microfone externo recomendado)
   - Pijamas (múltiplas cores)

3. **Equipe:**
   - Mínimo 3 pessoas (câmera, direção, modelo)
   - Ideal 4-5 pessoas (para parecer "caos criativo")
   - Todos devem estar confortáveis em câmera

4. **Locação:**
   - Estúdio/espaço bem iluminado
   - Fundo neutro ou interessante
   - Espaço para movimento
   - Sem ruído de fundo

### Durante a Gravação

1. **Múltiplos Ângulos:**
   - Wide shot (visão geral)
   - Medium shot (meia distância)
   - Close-up (detalhe)
   - Filme cada cena de 2-3 ângulos

2. **Múltiplas Takes:**
   - Grave 3-5 takes de cada cena
   - Varie expressões, movimentos
   - Capture momentos genuínos

3. **Áudio:**
   - Teste áudio antes de gravar
   - Grave vozes/risadas genuínas
   - Evite ruído de fundo

4. **Movimento:**
   - Movimento real, não coreografado
   - Energia alta, mas controlada
   - Risadas genuínas

5. **Qualidade:**
   - Boa iluminação
   - Foco nítido
   - Cores vibrantes
   - Sem tremidas (use tripé)

### Edição

1. **Organização:**
   - Importe todos os vídeos
   - Organize em pastas por cena
   - Rotule claramente

2. **Sequência:**
   - Comece com gancho
   - Depois preparação
   - Depois ação
   - Depois resultado
   - Termine com CTA

3. **Transições:**
   - Dinâmicas mas não excessivas
   - Sincronize com áudio
   - Mantenha ritmo rápido

4. **Áudio:**
   - Adicione trending sound
   - Adicione efeitos sonoros
   - Sincronize com vídeo
   - Equilibre volumes

5. **Texto:**
   - Fonte legível
   - Tamanho grande
   - Cores contrastantes
   - Animações suaves

6. **Revisão:**
   - Assista completo 2-3 vezes
   - Verifique timing
   - Verifique áudio
   - Verifique cores

---

## ESTRATÉGIA DE POSTAGEM

### Antes de Postar (24h Antes)

1. **Prepare Descrição:**

```
"Bastidores da Campanha Feminnita! 📸✨

Muito trabalho, muito amor, e muito resultado para vocês! 💖

Aqui você vê o caos criativo por trás de cada foto. Desde a iluminação perfeita até o pijama impecável, tudo é pensado com muito cuidado.

Nossa equipe trabalha junta para capturar cada detalhe, cada expressão, cada cor vibrante.

E o resultado? Fotos que vocês amam! 🔥

Deixa seu ❤️ nos comentários! Vocês amaram? 👇

#BastidoresFeminnita #BeautifulChaos #ProcessoCriativo #MakingOf #Feminnita #LançamentoInverno #BTS #CriativosDoBrasil #CampanhaCriativa #Produção
```

2. **Prepare Hashtags:**
   - 15-20 hashtags relevantes
   - Mix de populares (1M+) e nichados (10K-100K)
   - Inclua trending hashtags

3. **Prepare Stories:**
   - 3-4 stories teaser (antes de postar)
   - Stories com link para Reels (após postar)
   - Stories com enquete ("Vocês amaram?")

4. **Configure Alarme:**
   - Sexta-feira 20h (horário exato)
   - Alarme 15 minutos antes

### Nos Primeiros 30 Minutos (CRÍTICO)

1. **Responda Comentários:**
   - Responda TODOS os comentários
   - Respostas genuínas, não genéricas
   - Convide mais engajamento

2. **Compartilhe nos Stories:**
   - Poste Reels nos Stories
   - Adicione sticker "Deixa seu ❤️"
   - Convide para comentar

3. **Monitore Métricas:**
   - Visualizações
   - Engagement rate
   - Saves
   - Compartilhamentos

4. **Marque Pessoas:**
   - Marque equipe nos comentários
   - Marque clientes nos comentários
   - Crie senso de comunidade

### Nas Primeiras 2 Horas

1. **Continue Respondendo:**
   - Responda novos comentários
   - Mantenha engajamento alto

2. **Compartilhe Novamente:**
   - Poste nos Stories novamente
   - Convide amigos para ver

3. **Analise Performance:**
   - Está no caminho certo?
   - Engagement rate bom?
   - Saves altos?

### Nas Primeiras 24 Horas

1. **Responda Todos os Comentários:**
   - Não deixe nenhum sem resposta
   - Isso aumenta engajamento em 20-30%

2. **Compartilhe nos Stories:**
   - Poste 3-4 vezes ao longo do dia
   - Mantenha Reels em destaque

3. **Prepare Próximo:**
   - Comece a preparar Reels 3 (sábado)
   - Use aprendizados deste Reels

---

## MÉTRICAS ESPERADAS (SEXTA 20h)

### Primeiras 24 Horas

- **Visualizações:** 40K-50K
- **Engagement Rate:** 10-12%
- **Likes:** 2K-4K
- **Comentários:** 100-200
- **Saves:** 200-300
- **Compartilhamentos:** 100-200
- **Novos Seguidores:** 150-200

### Primeiros 7 Dias

- **Visualizações:** 60K-100K
- **Engagement Rate:** 8-10%
- **Likes:** 3K-6K
- **Comentários:** 150-300
- **Saves:** 300-500
- **Compartilhamentos:** 150-300
- **Novos Seguidores:** 250-400

### Primeiros 30 Dias

- **Visualizações:** 80K-150K
- **Engagement Rate:** 6-8%
- **Likes:** 4K-8K
- **Comentários:** 200-400
- **Saves:** 400-700
- **Compartilhamentos:** 200-400
- **Novos Seguidores:** 400-600

---

## CHECKLIST FINAL

### Produção
- [ ] Storyboard criado
- [ ] Equipe confirmada
- [ ] Locação preparada
- [ ] Equipamento testado
- [ ] Áudio testado
- [ ] Pijamas preparados
- [ ] Gravações feitas (múltiplos takes)
- [ ] Momentos genuínos capturados

### Edição
- [ ] Vídeo editado
- [ ] Transições adicionadas
- [ ] Áudio sincronizado
- [ ] Trending sound adicionado
- [ ] Efeitos sonoros adicionados
- [ ] Texto adicionado
- [ ] Cores ajustadas
- [ ] Revisão final completa

### Postagem
- [ ] Descrição preparada
- [ ] Hashtags preparadas
- [ ] Stories teasers preparadas
- [ ] Alarme configurado
- [ ] Horário confirmado (sexta 20h)
- [ ] Pronto para postar

### Pós-Postagem
- [ ] Responder comentários (primeiros 30 min)
- [ ] Compartilhar nos Stories
- [ ] Monitorar métricas
- [ ] Manter engajamento alto
- [ ] Compilar dados

---

## NOTAS FINAIS

**Este é o Reels mais importante da Semana 1.** É o que tem maior potencial de viralizar (10-12% engagement esperado). Invista tempo e qualidade aqui.

**Dicas para Viralizar:**
1. ✅ Gancho nos primeiros 3 segundos (CRÍTICO)
2. ✅ Trending sound (aumenta distribuição)
3. ✅ Ritmo rápido (mantém atenção)
4. ✅ Autenticidade (pessoas amam real)
5. ✅ CTA claro (convida engajamento)
6. ✅ Responda comentários (aumenta viralidade)
7. ✅ Compartilhe nos Stories (amplifica alcance)
8. ✅ Qualidade profissional (diferencia)

**Boa sorte! Este Reels tem tudo para viralizar. 🚀✨**
