# Roteiro de Vídeo para Instagram Reels - Bastidores da Produção

## Informações Gerais

**Título:** "Bastidores da Campanha Feminnita - Veja Como Fazemos Acontecer! 📸✨"

**Duração:** 45-60 segundos (Reels padrão)

**Plataforma:** Instagram Reels

**Objetivo:** Humanizar a marca, mostrar trabalho em equipe, criar conexão emocional com audiência, gerar engajamento através de conteúdo behind-the-scenes

**Público-Alvo:** Seguidoras atuais, potenciais clientes, pessoas que apreciam processo criativo

**Tone of Voice:** Descontraído, autêntico, entusiasmado, humanizado

**Hashtags Recomendadas:** #BastidoresFeminnita #ProcessosCriativos #BeautifulChaos #MakingOf #CampanhaCriativa #Feminnita #Produção #Behind #BTS #CriativosDoBrasil

---

# ROTEIRO DETALHADO - 45 SEGUNDOS

## Estrutura Geral

O vídeo segue uma narrativa de 5 atos que mostra o processo criativo de forma dinâmica e envolvente:

1. **Gancho (0-3s):** Cena caótica e divertida que chama atenção
2. **Preparação (3-12s):** Montagem rápida do setup de produção
3. **Ação (12-30s):** Cenas de gravação, edição, trabalho em equipe
4. **Resultado (30-40s):** Reveal das fotos finais
5. **CTA (40-45s):** Chamada para ação e agradecimento

---

## CENA 1: GANCHO (0-3 segundos)

**Timing:** 3 segundos

**Descrição Visual:**  
Plano rápido e caótico mostrando a equipe em ação. Pode ser:
- Alguém correndo com pijama na mão
- Várias mãos ajustando iluminação
- Risadas e movimento rápido
- Câmera rápida capturando o caos criativo

**Áudio:**  
Música viral energética (70%) + efeito sonoro de "whoosh" (30%) + vozes da equipe rindo (40%)

**Texto na Tela:**  
"Tá vendo esse caos? 🎬"

**Transição:**  
Corte rápido com efeito de transição (zoom, spin ou slide)

**Dicas de Produção:**  
Filme em câmera lenta (slow motion) ou velocidade normal mas edite rápido. Use múltiplos ângulos. Capture momentos genuínos de diversão e trabalho.

---

## CENA 2: PREPARAÇÃO (3-12 segundos)

**Timing:** 9 segundos

**Descrição Visual:**  
Montagem rápida (2-3 segundos cada) mostrando:

**Subcena 2.1 (3-5s):** Setup de Iluminação
- Alguém ajustando refletor
- Luz acendendo
- Ambiente ficando mais iluminado
- Texto: "Iluminação perfeita ✨"

**Subcena 2.2 (5-7s):** Preparação de Pijamas
- Pijamas sendo organizados
- Alguém passando ferro (ou ajustando)
- Cores vibrantes em destaque
- Texto: "Pijamas prontos 🎨"

**Subcena 2.3 (7-9s):** Preparação de Câmera
- Câmera sendo posicionada
- Alguém olhando pelo visor
- Ajustes finais
- Texto: "Câmera rolando 🎥"

**Áudio:**  
Música viral energética (70%) + efeitos sonoros de cliques, ajustes (40%) + vozes coordenando (30%)

**Transição:**  
Cortes rápidos entre subcenas (0.5-1 segundo cada)

**Dicas de Produção:**  
Use múltiplos ângulos. Filme em 4K se possível. Capture detalhes (mãos ajustando, expressões focadas). Use transições dinâmicas entre subcenas.

---

## CENA 3: AÇÃO (12-30 segundos)

**Timing:** 18 segundos

**Descrição Visual:**  
Montagem de cenas de gravação em ação. Mostrar:

**Subcena 3.1 (12-16s):** Modelo Posando
- Modelo usando pijama em diferentes poses
- Expressões genuínas
- Movimentos naturais
- Câmera capturando de diferentes ângulos
- Texto: "Modelo em ação 💃"

**Subcena 3.2 (16-20s):** Fotógrafo Trabalhando
- Fotógrafo capturando fotos
- Cliques da câmera (som real)
- Direcionando modelo
- Close-up no rosto do fotógrafo focado
- Texto: "Capturando o momento 📸"

**Subcena 3.3 (20-24s):** Equipe Colaborando
- Alguém ajustando pijama
- Outro ajustando luz
- Todos trabalhando juntos
- Comunicação entre equipe
- Texto: "Trabalho em equipe 👥"

**Subcena 3.4 (24-30s):** Edição/Revisão
- Alguém olhando fotos no computador
- Expressão de aprovação
- Polegar para cima
- Risadas e celebração
- Texto: "Aprovado! ✅"

**Áudio:**  
Música viral energética (70%) + efeitos sonoros reais (cliques, vozes, risadas) (50%) + conversas genuínas (40%)

**Transição:**  
Cortes rápidos, alguns com efeitos (zoom, spin), alguns naturais

**Dicas de Produção:**  
Capture momentos genuínos. Não tudo precisa ser posado. Risadas reais, conversas reais, trabalho real. Use múltiplos ângulos. Filme em diferentes velocidades (normal e slow motion para momentos especiais).

---

## CENA 4: RESULTADO (30-40 segundos)

**Timing:** 10 segundos

**Descrição Visual:**  
Reveal das fotos finais. Mostrar:

**Subcena 4.1 (30-33s):** Transição para Galeria
- Tela do computador/celular mostrando galeria de fotos
- Fotos aparecendo uma por uma
- Cores vibrantes, qualidade profissional
- Texto: "E o resultado? 🤩"

**Subcena 4.2 (33-37s):** Montagem de Fotos Finais
- 4-5 fotos melhores aparecendo rapidamente
- Diferentes ângulos, cores, produtos
- Cada foto com transição suave
- Música alcançando pico
- Texto: "Perfeito! 🔥"

**Subcena 4.3 (37-40s):** Equipe Celebrando
- Equipe vendo as fotos
- Expressões de satisfação
- Abraços, high-fives
- Câmera capturando alegria
- Texto: "Missão cumprida! 🎉"

**Áudio:**  
Música viral energética em pico (80%) + efeitos sonoros de sucesso (sino, aplausos) (50%) + vozes celebrando (40%)

**Transição:**  
Transições suaves entre fotos. Efeito de "reveal" ou "zoom" para cada foto.

**Dicas de Produção:**  
Use as fotos finais reais da campanha. Qualidade profissional. Transições suaves. Celebração genuína da equipe.

---

## CENA 5: CTA (40-45 segundos)

**Timing:** 5 segundos

**Descrição Visual:**  
Volta para a equipe, olhando para câmera. Ambiente da produção ao fundo.

**Subcena 5.1 (40-42s):** Mensagem da Equipe
- Alguém (ou vários) olhando para câmera
- Expressão amigável e genuína
- Ambiente de estúdio/produção ao fundo
- Texto: "Muito trabalho, muito amor! 💖"

**Subcena 5.2 (42-45s):** CTA Final
- Equipe fazendo gesto (coração com mão, polegar para cima, etc)
- Ou alguém falando direto para câmera
- Áudio: "Vocês amaram? Deixa um ❤️!"
- Texto: "Deixa seu ❤️ nos comentários! 👇"

**Áudio:**  
Música viral (60%) + voz em off ou fala genuína (80%) + efeito sonoro final (30%)

**Transição:**  
Fade para preto ou transição suave

**Dicas de Produção:**  
Seja genuíno. Olhe para câmera. Fale naturalmente. Convide engajamento.

---

# ESPECIFICAÇÕES TÉCNICAS

## Vídeo

- **Resolução:** 1080x1920px (Reels padrão)
- **Frame Rate:** 30fps (ou 60fps para slow motion)
- **Codec:** H.264
- **Duração:** 45-60 segundos
- **Proporção:** 9:16 (vertical)

## Áudio

- **Música de Fundo:** Viral trending sound do Instagram (70% volume)
- **Efeitos Sonoros:** Reais + adicionados (40% volume)
- **Vozes/Fala:** 80% volume
- **Mix Final:** Equilibrado, sem picos

## Edição

- **Software Recomendado:** CapCut, Adobe Premiere Pro, DaVinci Resolve
- **Transições:** Dinâmicas mas não excessivas (zoom, spin, slide, fade)
- **Efeitos:** Mínimos, foco no conteúdo
- **Cor:** Saturação normal, cores vibrantes, contraste bom
- **Velocidade:** Mistura de normal e slow motion

---

# TIMELINE DETALHADA (45 SEGUNDOS)

| Tempo | Cena | Descrição | Áudio | Texto |
|-------|------|-----------|-------|-------|
| 0-3s | Gancho | Caos criativo, equipe em ação | Música + whoosh | "Tá vendo esse caos? 🎬" |
| 3-5s | Setup Iluminação | Refletor sendo ajustado | Música + cliques | "Iluminação perfeita ✨" |
| 5-7s | Pijamas | Pijamas sendo organizados | Música + sons | "Pijamas prontos 🎨" |
| 7-9s | Câmera | Câmera sendo posicionada | Música + cliques | "Câmera rolando 🎥" |
| 9-16s | Modelo Posando | Modelo em diferentes poses | Música + vozes | "Modelo em ação 💃" |
| 16-20s | Fotógrafo | Fotógrafo capturando | Música + cliques | "Capturando o momento 📸" |
| 20-24s | Equipe | Trabalho em equipe | Música + vozes | "Trabalho em equipe 👥" |
| 24-30s | Edição | Revisão de fotos | Música + risadas | "Aprovado! ✅" |
| 30-33s | Transição | Fotos na tela | Música em pico | "E o resultado? 🤩" |
| 33-37s | Fotos Finais | Montagem de fotos | Música + efeitos | "Perfeito! 🔥" |
| 37-40s | Celebração | Equipe celebrando | Música + aplausos | "Missão cumprida! 🎉" |
| 40-42s | Mensagem | Equipe para câmera | Música + fala | "Muito trabalho, muito amor! 💖" |
| 42-45s | CTA | Gesto/fala final | Música + voz | "Deixa seu ❤️ nos comentários! 👇" |

---

# DICAS DE PRODUÇÃO

## Antes de Gravar

1. **Planeje as Cenas:** Faça uma lista das cenas que precisa gravar (setup, ação, resultado)
2. **Prepare Equipamento:** Câmera, iluminação, áudio, pijamas, modelo
3. **Teste Áudio:** Verifique se o som está claro e sem ruído de fundo
4. **Organize Equipe:** Saiba quem fará o quê e quando
5. **Prepare Locação:** Limpe e organize o espaço de produção

## Durante a Gravação

1. **Capture Múltiplos Ângulos:** Use câmera fixa, handheld, close-ups
2. **Filme Mais do que Precisa:** Você vai precisar de material extra para edição
3. **Capture Momentos Genuínos:** Risadas, conversas, trabalho real
4. **Use Diferentes Velocidades:** Normal e slow motion para momentos especiais
5. **Verifique Qualidade:** Revise as gravações durante o processo

## Edição

1. **Organize Material:** Importe e organize todos os vídeos em pastas
2. **Crie Sequência:** Comece com gancho, depois ação, depois resultado
3. **Adicione Transições:** Dinâmicas mas não excessivas
4. **Sincronize com Áudio:** Combine cliques de câmera, vozes, efeitos com música
5. **Adicione Texto:** Use fontes legíveis, cores contrastantes
6. **Revise e Ajuste:** Verifique timing, áudio, cores

## Pós-Produção

1. **Exporte em Alta Qualidade:** 1080x1920px, 30fps, H.264
2. **Teste em Celular:** Veja como fica em tela pequena
3. **Adicione Legendas:** Para acessibilidade
4. **Prepare Descrição:** Escreva caption engajadora
5. **Agende Postagem:** Poste em horário de pico (19h-21h)

---

# VARIAÇÕES ALTERNATIVAS

## Variação 1: Foco em Uma Pessoa

Se quiser focar em uma pessoa específica (você, fotógrafo, designer):

- Comece com essa pessoa acordando/chegando
- Siga seu dia durante a produção
- Mostre seu processo específico
- Termine com resultado final
- Humaniza muito mais

## Variação 2: Foco em Produto

Se quiser focar mais no pijama:

- Comece com pijama em branco
- Mostre processo de produção
- Destaque cores, qualidade, detalhes
- Termine com fotos finais do pijama
- Mais comercial

## Variação 3: Foco em Desafio

Se quiser criar tensão/drama:

- Comece com "Conseguimos fazer em 1 dia?"
- Mostre pressão, correria
- Momentos de dúvida
- Resultado final no último segundo
- Mais engajador

## Variação 4: Foco em Transformação

Se quiser mostrar antes/depois:

- Comece com espaço vazio
- Mostre setup sendo montado
- Mostre gravação
- Mostre edição
- Termine com espaço transformado + fotos
- Mais visual

---

# SCRIPT DE VOZ (OPCIONAL)

Se quiser adicionar narração:

**Voz em Off (feminina, entusiasmada):**

"Vocês já pararam para pensar no que tem por trás de cada foto? Aqui na Feminnita, a gente vive esse caos criativo todo dia! 

Desde a iluminação perfeita até o pijama impecável, tudo é pensado com muito cuidado e muito amor. 

Nossa equipe trabalha junta para capturar cada detalhe, cada expressão, cada cor vibrante.

E o resultado? Fotos que vocês amam!

Mas sabe o que mais importa? O trabalho em equipe, a criatividade, e a paixão que a gente coloca em cada projeto.

Muito trabalho, muito amor, muito resultado!

Deixa seu coração nos comentários se você também ama bastidores! 💖"

---

# DICAS FINAIS PARA VIRALIZAR

1. **Gancho Forte (0-3s):** Os primeiros 3 segundos determinam se as pessoas vão assistir. Use caos, movimento, curiosidade.

2. **Ritmo Rápido:** Mantenha o vídeo dinâmico. Cortes rápidos, transições, movimento. Pessoas têm atenção curta em Reels.

3. **Áudio Viral:** Use trending sounds do Instagram. Isso aumenta muito as chances de viralizar.

4. **Texto Estratégico:** Use emojis, texto grande, cores contrastantes. Deve ser legível em celular pequeno.

5. **CTA Claro:** Termine com chamada para ação clara (like, comentário, share, follow).

6. **Autenticidade:** Pessoas amam conteúdo genuíno. Mostre o real, não o perfeito.

7. **Timing de Postagem:** Poste quinta a domingo entre 19h-21h. Esses horários têm melhor engajamento.

8. **Responda Comentários:** Respostas rápidas aumentam engajamento e viralidade.

---

# CHECKLIST DE PRODUÇÃO

- [ ] Planejamento de cenas completo
- [ ] Equipamento testado (câmera, áudio, iluminação)
- [ ] Locação preparada e limpa
- [ ] Equipe briefada
- [ ] Pijamas preparados
- [ ] Modelo confirmado
- [ ] Gravações de múltiplos ângulos
- [ ] Momentos genuínos capturados
- [ ] Áudio testado
- [ ] Material organizado para edição
- [ ] Edição completa
- [ ] Sincronização com áudio
- [ ] Texto adicionado
- [ ] Legendas adicionadas
- [ ] Revisão final
- [ ] Exportação em alta qualidade
- [ ] Teste em celular
- [ ] Caption escrita
- [ ] Hashtags preparadas
- [ ] Horário de postagem definido

---

# MÉTRICAS ESPERADAS

Se executado bem, espera-se:

- **Visualizações:** 10K-50K (primeiras 24h)
- **Engagement Rate:** 5-10%
- **Saves:** 200-500 (indicador de intenção de compartilhar)
- **Shares:** 100-300
- **Comentários:** 50-150
- **Novos Seguidores:** 100-300

---

# ROTEIRO VISUAL RESUMIDO (Para Referência Rápida)

```
0-3s: GANCHO - Caos criativo, equipe em ação
      ↓
3-9s: PREPARAÇÃO - Setup iluminação, pijamas, câmera
      ↓
9-30s: AÇÃO - Modelo, fotógrafo, equipe, edição
      ↓
30-40s: RESULTADO - Fotos finais, celebração
      ↓
40-45s: CTA - Mensagem equipe, chamada para ação
```

---

# NOTAS FINAIS

Este roteiro é flexível. Você pode:
- Adicionar ou remover cenas
- Mudar ordem
- Adicionar mais tempo
- Usar diferentes locações
- Incluir mais pessoas
- Focar em diferentes aspectos

O importante é manter a autenticidade, o ritmo rápido, e a conexão emocional com a audiência. Bastidores funcionam porque as pessoas amam ver o processo, o trabalho real, a humanidade por trás da marca.

Boa sorte com a produção! 🎬✨
