# 42 Stories Completos - Campanha de Uma Semana (Instagram Stories)

## Guia de Uso

Este documento contém os **textos exatos** e **descrições visuais detalhadas** para cada um dos 42 stories da campanha. Para cada story você encontrará:

- **Story #:** Número sequencial
- **Dia:** Segunda a domingo
- **Horário:** 9h, 13h ou 19h
- **Descrição Visual:** O que deve aparecer na imagem/vídeo
- **Texto Exato:** Copie e cole diretamente no Instagram
- **Elemento Interativo:** Enquete, votação, caixa de perguntas, etc.
- **Dicas de Produção:** Como gravar/editar para melhor resultado

---

# SEGUNDA-FEIRA - TEASER + ANÚNCIO

## Story 1 (9h) - Teaser Misterioso

**Descrição Visual:**  
Imagem com fundo preto ou cinza escuro. Pijama de inverno parcialmente visível no canto inferior direito (apenas a parte do tecido, cores, detalhe). Efeito de luz/brilho sobre o pijama. Texto em branco grande e ousado no centro.

**Texto Exato:**  
"Algo ESPECIAL chegou! 🎁✨"  
"Você está pronto para o melhor pijama do inverno?"

**Elemento Interativo:**  
Sticker de Contagem Regressiva: "Lançamento em 24h!" (Configura para contar de 24h até 0h)

**CTA:**  
"Vira para ver mais! 👉"

**Dicas de Produção:**  
Use luz morna e ambiente escuro para criar mistério. O pijama deve estar parcialmente visível para gerar curiosidade. Texto em fonte grande (Montserrat ou similar) com contorno preto para legibilidade.

---

## Story 2 (9h30) - Enquete de Antecipação

**Descrição Visual:**  
Imagem de ambiente aconchego: cama com lençol branco, luz morna (lâmpada de cabeceira), xícara de chá ou café na mesinha de cabeceira, almofada fofa. Ambiente deve parecer confortável e desejável. Cores quentes (bege, ouro, branco).

**Texto Exato:**  
"Você está esperando por um novo pijama de inverno?"

**Elemento Interativo:**  
Enquete (Poll):  
- Opção A: "SIM! Quero logo!" 
- Opção B: "Talvez... depende do preço"  
- Opção C: "Não, estou bem assim"

**CTA:**  
"Vote agora! 👆"

**Dicas de Produção:**  
Foto de qualidade alta, bem iluminada, com foco no conforto e aconchego. Pode ser foto de cama real ou mockup. Cores quentes transmitem conforto.

---

## Story 3 (13h) - Caixa de Perguntas

**Descrição Visual:**  
Imagem: Pijama de inverno em destaque (mostrando mais detalhes agora que no Story 1). Pode ser em modelo ou pendurado. Fundo neutro (branco, cinza claro ou padrão suave). Cores do pijama devem ser vibrantes e atrativas.

**Texto Exato:**  
"Você tem dúvidas sobre o novo pijama de inverno? Pergunte aqui! 👇"

**Elemento Interativo:**  
Caixa de Perguntas (Ask Sticker):  
- Placeholder: "Qual é sua dúvida? Preço? Tamanho? Cores?"

**CTA:**  
"Deixe sua pergunta! Vamos responder!"

**Dicas de Produção:**  
Foto clara e bem iluminada do pijama. Pode ser foto de estoque ou profissional. Fundo deve ser simples para não distrair do produto.

---

## Story 4 (19h) - Votação de Cor Favorita

**Descrição Visual:**  
Imagem: 2 cores do pijama lado a lado (ex: azul marinho vs cinza). Ambas devem estar bem iluminadas e vibrantes. Pode ser em modelo ou apenas o tecido/pijama pendurado. Fundo neutro para que as cores se destaquem.

**Texto Exato:**  
"Qual cor você prefere? 🎨"

**Elemento Interativo:**  
Votação (Voting Sticker - mostrar 2 cores):  
- Opção A: Azul Marinho
- Opção B: Cinza

**CTA:**  
"Vote na sua favorita! 👆"

**Dicas de Produção:**  
Duas fotos de qualidade similar, mesma iluminação, para que a comparação seja justa. Cores devem ser fiéis ao produto real.

---

# TERÇA-FEIRA - APRESENTAÇÃO DAS CORES + ENQUETE

## Story 5 (9h) - Apresentação das 4 Cores

**Descrição Visual:**  
Imagem: 4 pijamas em cores diferentes (azul marinho, cinza, vinho, preto) lado a lado ou em grade. Todos bem iluminados, cores vibrantes. Pode ser em modelos diferentes ou apenas o pijama pendurado/dobrado. Fundo branco ou neutro.

**Texto Exato:**  
"Conhece nossas 4 cores exclusivas? 🎨✨"  
"Azul Marinho | Cinza | Vinho | Preto"

**Elemento Interativo:**  
Nenhum (apenas apresentação). Pode usar sticker de "Deslize para ver mais" se tiver mais detalhes.

**CTA:**  
"Qual é sua favorita? Vira para votar! 👉"

**Dicas de Produção:**  
4 fotos de qualidade similar, mesma iluminação, para que as cores se destaquem igualmente. Composição deve ser simétrica e profissional.

---

## Story 6 (9h30) - Enquete 1: Qual Cor?

**Descrição Visual:**  
Imagem: Pijama azul marinho em destaque (pode ser em modelo ou pendurado). Ambiente aconchego ao fundo (cama, luz morna). Foco no pijama azul marinho.

**Texto Exato:**  
"Qual é sua cor favorita?"

**Elemento Interativo:**  
Enquete (Poll):  
- Opção A: Azul Marinho (elegante)
- Opção B: Cinza (versátil)
- Opção C: Vinho (sofisticado)
- Opção D: Preto (clássico)

**CTA:**  
"Vote agora! 👆"

**Dicas de Produção:**  
Foto bem iluminada, foco no pijama. Pode ter ambiente ao fundo para contexto. Texto deve ser legível mesmo em celular pequeno.

---

## Story 7 (13h) - Respondendo Perguntas

**Descrição Visual:**  
Imagem: Pijama com detalhe de tecido (close-up mostrando qualidade, textura). Pode mostrar etiqueta com informações. Fundo neutro. Cores quentes para parecer premium.

**Texto Exato:**  
"Vocês perguntaram! Aqui estão as respostas! 👇"  
"P: Qual é o preço?"  
"R: A partir de R$ 49,90 no atacado! 💰"

**Elemento Interativo:**  
Nenhum (apenas resposta). Pode usar sticker de "Deslize para ver mais" para próxima pergunta.

**CTA:**  
"Tem mais dúvidas? Deixe sua pergunta! 👉"

**Dicas de Produção:**  
Foto clara do pijama com detalhe de qualidade. Texto deve ser grande e legível. Preço deve ser destacado em cor diferente (ex: verde ou rosa).

---

## Story 8 (13h30) - Enquete 2: Tamanho Preferido

**Descrição Visual:**  
Imagem: Pijama em modelo (mostrando tamanho/ajuste). Modelo deve parecer confortável e feliz. Ambiente aconchego ao fundo. Foco no ajuste do pijama.

**Texto Exato:**  
"Qual tamanho você usa?"

**Elemento Interativo:**  
Enquete (Poll):  
- Opção A: P (Pequeno)
- Opção B: M (Médio)
- Opção C: G (Grande)
- Opção D: GG (Extra Grande)

**CTA:**  
"Vote no seu tamanho! 👆"

**Dicas de Produção:**  
Foto de modelo usando pijama, mostrando como cai/ajusta. Modelo deve parecer confortável. Foto deve ser de qualidade profissional.

---

## Story 9 (19h) - Caixa de Perguntas: Mais Dúvidas

**Descrição Visual:**  
Imagem: Pijama (close-up no tecido, mostrando qualidade, maciez). Pode ter mão tocando o tecido para mostrar toque. Fundo neutro. Cores quentes.

**Texto Exato:**  
"Mais dúvidas? Pergunte agora! 🤔"  
"Vamos responder tudo para você!"

**Elemento Interativo:**  
Caixa de Perguntas (Ask Sticker):  
- Placeholder: "Qual é sua dúvida? Tecido? Durabilidade? Frete?"

**CTA:**  
"Deixe sua pergunta! 👇"

**Dicas de Produção:**  
Foto clara do tecido, mostrando qualidade. Pode ter mão para escala. Texto deve ser amigável e convidativo.

---

## Story 10 (19h30) - Votação: Qual Combo?

**Descrição Visual:**  
Imagem: 2 combos de pijamas lado a lado (ex: Combo 1: 2 pijamas em cores diferentes vs Combo 2: 3 pijamas em cores diferentes). Ambos bem apresentados, cores vibrantes. Fundo neutro. Preços visíveis.

**Texto Exato:**  
"Se você fosse comprar hoje, qual combo escolheria? 🛍️"

**Elemento Interativo:**  
Votação (Voting Sticker):  
- Opção A: 2 pijamas por R$ 89,90
- Opção B: 3 pijamas por R$ 129,90

**CTA:**  
"Vote no seu combo favorito! 👆"

**Dicas de Produção:**  
2 fotos de qualidade similar, mostrando combos diferentes. Preços devem ser destacados. Composição deve ser equilibrada.

---

# QUARTA-FEIRA - CARACTERÍSTICAS + EDUCAÇÃO

## Story 11 (9h) - Característica 1: Tecido Premium

**Descrição Visual:**  
Imagem: Close-up no tecido (mostrando textura, qualidade). Pode ter mão tocando o tecido. Luz morna para destacar qualidade. Fundo desfocado ou neutro.

**Texto Exato:**  
"100% Algodão Premium ✨"  
"Toque aveludado e macio"  
"Perfeito para inverno"

**Elemento Interativo:**  
Nenhum (apenas informação). Pode usar sticker de "Deslize para ver mais".

**CTA:**  
"Vira para ver mais características! 👉"

**Dicas de Produção:**  
Macro/close-up de qualidade profissional. Luz deve destacar a textura. Pode ter mão para escala e para mostrar toque.

---

## Story 12 (9h30) - Enquete: O que Importa Mais?

**Descrição Visual:**  
Imagem: Pijama completo em modelo (mostrando conforto). Ambiente aconchego ao fundo. Modelo deve parecer relaxada e feliz.

**Texto Exato:**  
"O que é mais importante para você em um pijama?"

**Elemento Interativo:**  
Enquete (Poll):  
- Opção A: Conforto
- Opção B: Qualidade do Tecido
- Opção C: Preço
- Opção D: Estilo/Cor

**CTA:**  
"Vote agora! 👆"

**Dicas de Produção:**  
Foto de modelo usando pijama, parecendo confortável. Qualidade profissional. Ambiente deve reforçar conforto.

---

## Story 13 (13h) - Característica 2: Peso Perfeito

**Descrição Visual:**  
Imagem: Pijama em modelo, mostrando como cai/ajusta. Modelo deve parecer confortável, sem parecer muito quente ou frio. Ambiente aconchego ao fundo.

**Texto Exato:**  
"Peso Perfeito para Inverno 🌡️"  
"Nem quente demais, nem frio demais"  
"Conforto a noite toda"

**Elemento Interativo:**  
Nenhum (apenas informação).

**CTA:**  
"Vira para ver mais! 👉"

**Dicas de Produção:**  
Foto de modelo usando pijama, mostrando ajuste. Modelo deve parecer confortável. Iluminação deve ser natural e aconchegante.

---

## Story 14 (13h30) - Caixa de Perguntas: Dúvidas Técnicas

**Descrição Visual:**  
Imagem: Pijama (mostrando etiqueta, informações técnicas). Pode ter pijama dobrado ou pendurado com etiqueta visível. Fundo neutro.

**Texto Exato:**  
"Dúvidas técnicas? Pergunte aqui! 🔍"  
"Composição? Cuidados? Durabilidade?"

**Elemento Interativo:**  
Caixa de Perguntas (Ask Sticker):  
- Placeholder: "Qual é sua dúvida técnica?"

**CTA:**  
"Deixe sua pergunta! 👇"

**Dicas de Produção:**  
Foto clara mostrando etiqueta/informações técnicas. Texto deve ser profissional. Fundo deve ser simples.

---

## Story 15 (19h) - Característica 3: Durabilidade

**Descrição Visual:**  
Imagem: Pijama após múltiplas lavagens (mostrando que mantém qualidade). Pode ser antes/depois ou apenas o pijama em bom estado. Cores devem parecer vibrantes mesmo após uso. Fundo neutro.

**Texto Exato:**  
"Durável e Resistente 💪"  
"Mantém qualidade após 100+ lavagens"  
"Investimento que vale a pena"

**Elemento Interativo:**  
Nenhum (apenas informação).

**CTA:**  
"Vira para ver o preço! 👉"

**Dicas de Produção:**  
Foto de pijama em bom estado (pode ser novo ou após uso). Cores devem ser vibrantes. Texto deve reforçar durabilidade e valor.

---

## Story 16 (19h30) - Votação: Qual Característica Mais Impressionou?

**Descrição Visual:**  
Imagem: Montagem das 3 características (tecido, peso, durabilidade). Pode ser 3 fotos lado a lado ou em grid. Bem apresentadas, cores vibrantes.

**Texto Exato:**  
"Qual característica mais te impressionou? 🌟"

**Elemento Interativo:**  
Votação (Voting Sticker):  
- Opção A: Tecido Premium
- Opção B: Peso Perfeito
- Opção C: Durabilidade

**CTA:**  
"Vote na sua favorita! 👆"

**Dicas de Produção:**  
Montagem de 3 fotos de qualidade similar. Composição deve ser equilibrada. Cores devem ser vibrantes.

---

# QUINTA-FEIRA - PROVA SOCIAL + DEPOIMENTOS

## Story 17 (9h) - Depoimento 1: Cliente Satisfeita

**Descrição Visual:**  
Imagem: Mulher usando pijama, sorrindo, relaxada. Pode estar na cama, no sofá ou em ambiente aconchego. Ambiente deve parecer confortável. Luz natural ou morna.

**Texto Exato:**  
"'Melhor pijama que já tive! Tão macio e confortável!' - Maria, São Paulo ⭐⭐⭐⭐⭐"

**Elemento Interativo:**  
Nenhum (apenas depoimento).

**CTA:**  
"Vira para ver mais depoimentos! 👉"

**Dicas de Produção:**  
Foto de qualidade profissional. Mulher deve parecer genuinamente feliz e confortável. Ambiente deve reforçar conforto. Pode ser cliente real ou modelo.

---

## Story 18 (9h30) - Enquete: Você Confia em Depoimentos?

**Descrição Visual:**  
Imagem: Montagem de 3 depoimentos (diferentes mulheres, todas usando pijama, todas felizes). Fundo neutro. Pode ter estrelas (⭐) para indicar avaliação.

**Texto Exato:**  
"Depoimentos de clientes influenciam sua decisão de compra?"

**Elemento Interativo:**  
Enquete (Poll):  
- Opção A: Sim, muito!
- Opção B: Um pouco
- Opção C: Não, prefiro testar

**CTA:**  
"Vote agora! 👆"

**Dicas de Produção:**  
Montagem de 3 fotos de qualidade similar. Todas as mulheres devem parecer felizes e genuínas. Composição deve ser equilibrada.

---

## Story 19 (13h) - Depoimento 2: Cliente Lojista

**Descrição Visual:**  
Imagem: Mulher em ambiente de loja (ou mostrando pijamas em estoque). Profissional, confiante. Pode estar ao lado de pijamas, mostrando estoque. Iluminação profissional.

**Texto Exato:**  
"'Vendo muito! Meus clientes amam a qualidade!' - Ana, Lojista RJ ⭐⭐⭐⭐⭐"

**Elemento Interativo:**  
Nenhum (apenas depoimento).

**CTA:**  
"Vira para ver mais! 👉"

**Dicas de Produção:**  
Foto profissional em ambiente de loja. Mulher deve parecer confiante e bem-sucedida. Pode mostrar estoque de pijamas ao fundo.

---

## Story 20 (13h30) - Caixa de Perguntas: Pergunte aos Clientes

**Descrição Visual:**  
Imagem: Montagem de clientes satisfeitas (3-4 mulheres diferentes, todas usando pijama, todas felizes). Fundo neutro. Pode ter bolhas de fala ou ícone de chat.

**Texto Exato:**  
"Quer fazer uma pergunta diretamente para nossos clientes? 💬"  
"Pergunte aqui e eles podem responder!"

**Elemento Interativo:**  
Caixa de Perguntas (Ask Sticker):  
- Placeholder: "Qual é sua dúvida para os clientes?"

**CTA:**  
"Deixe sua pergunta! 👇"

**Dicas de Produção:**  
Montagem de 3-4 fotos de clientes felizes. Composição deve ser alegre e comunitária. Pode ter ícones de chat ou bolhas de fala.

---

## Story 21 (19h) - Depoimento 3: Cliente Renda Extra

**Descrição Visual:**  
Imagem: Mulher mostrando pijamas (como se estivesse revendendo). Alegre, bem-sucedida. Pode estar com pijamas em mãos, mostrando para câmera. Ambiente pode ser casa ou loja pequena. Iluminação natural.

**Texto Exato:**  
"'Já ganhei R$ 1.500 revendendo! Super recomendo!' - Carol, Empreendedora SP ⭐⭐⭐⭐⭐"

**Elemento Interativo:**  
Nenhum (apenas depoimento).

**CTA:**  
"Vira para saber como começar! 👉"

**Dicas de Produção:**  
Foto de mulher alegre e bem-sucedida. Deve mostrar pijamas ou ambiente de negócio. Iluminação natural e aconchegante. Pode ser cliente real ou modelo.

---

## Story 22 (19h30) - Votação: Qual Depoimento Mais Inspirou?

**Descrição Visual:**  
Imagem: Montagem dos 3 depoimentos (cliente satisfeita, lojista, renda extra). Pode ser 3 fotos lado a lado ou em grid. Bem apresentadas.

**Texto Exato:**  
"Qual depoimento mais te inspirou? 🌟"

**Elemento Interativo:**  
Votação (Voting Sticker):  
- Opção A: Cliente Satisfeita
- Opção B: Lojista
- Opção C: Renda Extra

**CTA:**  
"Vote no seu favorito! 👆"

**Dicas de Produção:**  
Montagem de 3 fotos de qualidade similar. Composição deve ser equilibrada. Cada foto deve representar bem seu depoimento.

---

# SEXTA-FEIRA - VOTAÇÃO DE PROMOÇÃO + URGÊNCIA

## Story 23 (9h) - Anúncio de Promoção Especial

**Descrição Visual:**  
Imagem: Pijama com badge "PROMOÇÃO ESPECIAL" ou "OFERTA LIMITADA" (pode ser sticker ou design gráfico). Cores vibrantes, chamativo. Fundo pode ser gradiente ou padrão. Cores quentes (rosa, laranja, amarelo).

**Texto Exato:**  
"PROMOÇÃO ESPECIAL PARA VOCÊS! 🎉"  
"Mas qual promoção vocês preferem?"  
"Vocês decidem!"

**Elemento Interativo:**  
Nenhum (apenas anúncio).

**CTA:**  
"Vira para votar na promoção! 👉"

**Dicas de Produção:**  
Foto chamativa com cores vibrantes. Badge deve ser bem visível. Texto deve ser grande e entusiasmado. Pode ter confete ou efeitos visuais.

---

## Story 24 (9h30) - Votação: Qual Promoção Preferem?

**Descrição Visual:**  
Imagem: Pijama com 2 opções de promoção lado a lado (ex: 40% OFF vs Compre 2, Leve 3). Ambas bem apresentadas, cores vibrantes. Fundo pode ser gradiente ou padrão.

**Texto Exato:**  
"Qual promoção você prefere?"

**Elemento Interativo:**  
Votação (Voting Sticker):  
- Opção A: 40% OFF em 1 pijama
- Opção B: Compre 2, Leve 3 (50% OFF no 3º)

**CTA:**  
"Vote na sua promoção favorita! 👆"

**Dicas de Produção:**  
Foto mostrando as 2 opções de promoção lado a lado. Ambas devem ser igualmente atrativas. Preços devem ser destacados. Cores vibrantes.

---

## Story 25 (13h) - Urgência: Contagem Regressiva

**Descrição Visual:**  
Imagem: Pijama com "ÚLTIMAS PEÇAS" ou "ESTOQUE LIMITADO" (pode ser sticker ou design gráfico). Fundo vermelho ou laranja (cores de urgência). Pode ter relógio ou ícone de urgência.

**Texto Exato:**  
"⏰ ATENÇÃO!"  
"Promoção válida apenas este fim de semana!"  
"Quantidade limitada!"

**Elemento Interativo:**  
Sticker de Contagem Regressiva: "Promoção termina em 48h!" (Configura para contar de 48h até 0h)

**CTA:**  
"Não perca! Compre agora! 🔥"

**Dicas de Produção:**  
Cores de urgência (vermelho, laranja). Texto deve ser grande e impactante. Pode ter efeitos visuais como piscadas ou animações.

---

## Story 26 (13h30) - Caixa de Perguntas: Dúvidas Sobre Promoção

**Descrição Visual:**  
Imagem: Pijama com badge de promoção. Fundo neutro ou gradiente suave. Pode ter ícone de pergunta ou chat.

**Texto Exato:**  
"Dúvidas sobre a promoção? Pergunte aqui! 🤔"  
"Como funciona? Como comprar?"

**Elemento Interativo:**  
Caixa de Perguntas (Ask Sticker):  
- Placeholder: "Qual é sua dúvida sobre a promoção?"

**CTA:**  
"Deixe sua pergunta! 👇"

**Dicas de Produção:**  
Foto clara do pijama com promoção. Fundo deve ser simples. Texto deve ser amigável e convidativo.

---

## Story 27 (19h) - Resultado da Votação + Anúncio Oficial

**Descrição Visual:**  
Imagem: Pijama com a promoção vencedora em destaque (ex: "40% OFF" ou "Compre 2, Leve 3"). Cores vibrantes, chamativo. Fundo pode ser gradiente ou padrão. Pode ter confete ou efeitos visuais.

**Texto Exato:**  
"VOCÊS DECIDIRAM! 🎉"  
"A promoção vencedora é: [Promoção Mais Votada]"  
"Válida apenas este fim de semana!"

**Elemento Interativo:**  
Nenhum (apenas anúncio).

**CTA:**  
"Vira para saber como comprar! 👉"

**Dicas de Produção:**  
Foto chamativa com a promoção vencedora em destaque. Cores vibrantes. Texto deve ser entusiasmado. Pode ter confete ou efeitos visuais.

---

## Story 28 (19h30) - CTA Final: Link para Compra

**Descrição Visual:**  
Imagem: Pijama com promoção. Fundo vibrante, chamativo (pode ser gradiente, padrão ou cor sólida). Pode ter botão "COMPRE AGORA" ou similar.

**Texto Exato:**  
"COMPRE AGORA! 🛍️"  
"Link na bio!"  
"Ou envie mensagem no WhatsApp!"

**Elemento Interativo:**  
Sticker de Link (para site/WhatsApp) ou Sticker de Localização (se tiver loja física).

**CTA:**  
"Clique no link! 👆" ou "Envie mensagem! 💬"

**Dicas de Produção:**  
Foto chamativa com cores vibrantes. Botão ou CTA deve ser bem visível. Texto deve ser claro e direto. Pode ter efeitos visuais.

---

# SÁBADO - LIFESTYLE + INSPIRAÇÃO

## Story 29 (9h) - Lifestyle 1: Acordar Confortável

**Descrição Visual:**  
Imagem: Mulher acordando na cama, esticando, sorrindo. Pijama de inverno visível. Luz natural (amanhecer), ambiente aconchego. Cama com lençol branco ou claro. Atmosfera tranquila e feliz.

**Texto Exato:**  
"Acordar confortável é o melhor! ☀️"  
"Com nosso pijama de inverno, toda manhã é especial"

**Elemento Interativo:**  
Nenhum (apenas inspiração).

**CTA:**  
"Vira para mais inspiração! 👉"

**Dicas de Produção:**  
Foto de qualidade profissional. Mulher deve parecer genuinamente feliz e descansada. Luz natural é importante. Ambiente deve ser aconchego e aspiracional.

---

## Story 30 (9h30) - Enquete: Seu Ritual Matinal Favorito

**Descrição Visual:**  
Imagem: Mulher em ambiente aconchego (cama, luz natural). Pode estar tomando café, lendo, meditando. Fundo: aconchego, cores quentes.

**Texto Exato:**  
"Qual é seu ritual matinal favorito?"

**Elemento Interativo:**  
Enquete (Poll):  
- Opção A: Acordar devagar
- Opção B: Tomar café na cama
- Opção C: Meditar
- Opção D: Exercitar

**CTA:**  
"Vote no seu! 👆"

**Dicas de Produção:**  
Foto de mulher em ambiente aconchego. Luz natural. Ambiente deve parecer relaxante e aspiracional. Qualidade profissional.

---

## Story 31 (13h) - Lifestyle 2: Tarde Relaxante

**Descrição Visual:**  
Imagem: Mulher em sofá, lendo livro, tomando chá. Usando pijama de inverno. Luz quente, ambiente cozy. Pode ter manta, almofada, ambiente muito aconchego.

**Texto Exato:**  
"Tarde de relaxamento? ☕"  
"Pijama de inverno é perfeito para ficar em casa"

**Elemento Interativo:**  
Nenhum (apenas inspiração).

**CTA:**  
"Vira para ver mais! 👉"

**Dicas de Produção:**  
Foto de qualidade profissional. Ambiente deve parecer cozy e confortável. Luz quente. Mulher deve parecer relaxada e feliz. Pode ter adereços (livro, chá, manta).

---

## Story 32 (13h30) - Caixa de Perguntas: Qual Seu Momento Favorito?

**Descrição Visual:**  
Imagem: Montagem de diferentes momentos (acordar, tarde, noite). Pode ser 3 fotos lado a lado ou em grid. Fundo neutro. Cores quentes.

**Texto Exato:**  
"Qual é seu momento favorito do dia para usar pijama confortável? 🌙"

**Elemento Interativo:**  
Caixa de Perguntas (Ask Sticker):  
- Placeholder: "Qual é seu momento favorito?"

**CTA:**  
"Deixe sua resposta! 👇"

**Dicas de Produção:**  
Montagem de 3 fotos de qualidade similar. Composição deve ser equilibrada. Cores quentes. Cada foto deve representar um momento diferente.

---

## Story 33 (19h) - Lifestyle 3: Noite Aconchego

**Descrição Visual:**  
Imagem: Mulher deitada na cama, abraçando almofada, completamente relaxada. Pijama de inverno visível. Luz morna (lâmpada de cabeceira), ambiente muito aconchego. Lençol branco ou claro. Atmosfera de sono perfeito.

**Texto Exato:**  
"Noite aconchego é a melhor! 🌙"  
"Pijama de inverno = sono perfeito"

**Elemento Interativo:**  
Nenhum (apenas inspiração).

**CTA:**  
"Vira para ver mais! 👉"

**Dicas de Produção:**  
Foto de qualidade profissional. Mulher deve parecer completamente relaxada e feliz. Luz morna. Ambiente deve ser muito aconchego. Aspiracional.

---

## Story 34 (19h30) - Votação: Qual Momento Mais Apreciam?

**Descrição Visual:**  
Imagem: Montagem dos 3 momentos (acordar, tarde, noite). Pode ser 3 fotos lado a lado ou em grid. Bem apresentadas, cores quentes.

**Texto Exato:**  
"Qual momento você mais aprecia? 🌟"

**Elemento Interativo:**  
Votação (Voting Sticker):  
- Opção A: Acordar Confortável
- Opção B: Tarde Relaxante
- Opção C: Noite Aconchego

**CTA:**  
"Vote no seu favorito! 👆"

**Dicas de Produção:**  
Montagem de 3 fotos de qualidade similar. Composição deve ser equilibrada. Cores quentes. Cada foto deve representar bem seu momento.

---

# DOMINGO - FECHAMENTO + ÚLTIMO CHAMADO + AGRADECIMENTO

## Story 35 (9h) - Resumo da Semana

**Descrição Visual:**  
Imagem: Montagem de momentos da semana (cores, características, depoimentos, promoção). Pode ser colagem de 4-6 fotos. Bem apresentada, cores vibrantes. Fundo pode ser gradiente ou padrão.

**Texto Exato:**  
"QUE SEMANA INCRÍVEL! 🎉"  
"Vocês votaram, perguntaram, compartilharam!"  
"Obrigada pelo amor!"

**Elemento Interativo:**  
Nenhum (apenas resumo).

**CTA:**  
"Vira para ver o último chamado! 👉"

**Dicas de Produção:**  
Montagem de 4-6 fotos da semana. Composição deve ser alegre e celebratória. Cores vibrantes. Pode ter confete ou efeitos visuais.

---

## Story 36 (9h30) - Enquete Final: Você Vai Comprar?

**Descrição Visual:**  
Imagem: Pijama de inverno com promoção. Fundo vibrante, chamativo. Pode ter botão "COMPRE AGORA" ou similar.

**Texto Exato:**  
"Você vai aproveitar a promoção?"

**Elemento Interativo:**  
Enquete (Poll):  
- Opção A: Sim! Já estou comprando!
- Opção B: Talvez, estou pensando
- Opção C: Não, não é para mim

**CTA:**  
"Vote agora! 👆"

**Dicas de Produção:**  
Foto chamativa com cores vibrantes. Pijama deve estar em destaque. Fundo deve ser atrativo. Pode ter efeitos visuais.

---

## Story 37 (13h) - Último Chamado: Promoção Termina Hoje

**Descrição Visual:**  
Imagem: Pijama com "ÚLTIMO DIA" ou "TERMINA HOJE". Fundo vermelho ou laranja (urgência). Pode ter relógio ou ícone de urgência. Pode ter "X HORAS RESTANTES".

**Texto Exato:**  
"⏰ ATENÇÃO!"  
"Promoção termina HOJE!"  
"Últimas peças em estoque!"

**Elemento Interativo:**  
Sticker de Contagem Regressiva: "Promoção termina em 12h!" (Configura para contar de 12h até 0h)

**CTA:**  
"Compre agora! 🔥"

**Dicas de Produção:**  
Cores de urgência (vermelho, laranja). Texto deve ser grande e impactante. Pode ter efeitos visuais como piscadas. Deve criar senso de urgência.

---

## Story 38 (13h30) - Caixa de Perguntas: Últimas Dúvidas

**Descrição Visual:**  
Imagem: Pijama com promoção. Fundo neutro ou gradiente suave. Pode ter ícone de pergunta ou chat.

**Texto Exato:**  
"Última chance de tirar dúvidas! 🤔"  
"Pergunte agora!"

**Elemento Interativo:**  
Caixa de Perguntas (Ask Sticker):  
- Placeholder: "Qual é sua última dúvida?"

**CTA:**  
"Deixe sua pergunta! 👇"

**Dicas de Produção:**  
Foto clara do pijama com promoção. Fundo deve ser simples. Texto deve ser amigável mas urgente. Pode ter ícone de chat.

---

## Story 39 (19h) - Agradecimento + Teaser da Próxima Campanha

**Descrição Visual:**  
Imagem: Montagem de clientes satisfeitas (3-4 mulheres diferentes, todas usando pijama, todas felizes). Fundo neutro. Pode ter corações ou ícones de amor.

**Texto Exato:**  
"OBRIGADA! 💖"  
"Vocês foram INCRÍVEIS esta semana!"  
"Semana que vem tem MAIS NOVIDADES!"

**Elemento Interativo:**  
Nenhum (apenas agradecimento).

**CTA:**  
"Fique ligada! 👉"

**Dicas de Produção:**  
Montagem de 3-4 fotos de clientes felizes. Composição deve ser alegre e amorosa. Pode ter corações ou efeitos visuais. Cores quentes.

---

## Story 40 (19h30) - Link Final para Compra

**Descrição Visual:**  
Imagem: Pijama com promoção. Fundo vibrante, chamativo (pode ser gradiente, padrão ou cor sólida). Pode ter botão "COMPRE AGORA" ou similar.

**Texto Exato:**  
"ÚLTIMAS HORAS! 🔥"  
"Link na bio!"  
"WhatsApp também!"

**Elemento Interativo:**  
Sticker de Link (para site/WhatsApp) ou Sticker de Localização (se tiver loja física).

**CTA:**  
"Clique agora! 👆" ou "Envie mensagem! 💬"

**Dicas de Produção:**  
Foto chamativa com cores vibrantes. Botão ou CTA deve ser bem visível. Texto deve ser claro e direto. Pode ter efeitos visuais.

---

## Story 41 (20h) - Bônus: Behind the Scenes

**Descrição Visual:**  
Imagem: Behind the scenes da campanha (você/equipe preparando stories, gravando, editando). Ambiente de trabalho, criativo. Pode ser casual e descontraído.

**Texto Exato:**  
"Nos bastidores da campanha! 📸"  
"Muito trabalho, muito amor!"  
"Valeu a pena ver vocês felizes!"

**Elemento Interativo:**  
Nenhum (apenas diversão).

**CTA:**  
"Que acham? 👉"

**Dicas de Produção:**  
Foto casual e descontraída. Pode ser você, sua equipe, ou ambiente de trabalho. Humaniza a marca. Pode ter humor.

---

## Story 42 (20h30) - Bônus: Enquete Final de Satisfação

**Descrição Visual:**  
Imagem: Pijama de inverno. Fundo neutro. Pode ter emoji de satisfação (😊) ou similar.

**Texto Exato:**  
"Qual foi sua experiência com a gente esta semana?"

**Elemento Interativo:**  
Enquete (Poll):  
- Opção A: Amei! Vou comprar!
- Opção B: Gostei, mas vou pensar
- Opção C: Não era para mim
- Opção D: Adorei tudo!

**CTA:**  
"Deixe seu feedback! 👆"

**Dicas de Produção:**  
Foto simples e clara do pijama. Fundo neutro. Texto deve ser amigável. Enquete deve ser positiva.

---

## Resumo Geral

**Total de Stories:** 42  
**Dias:** 7 (segunda a domingo)  
**Stories por Dia:** 6  
**Horários:** 9h, 13h, 19h (+ bônus 20h no domingo)

**Elementos Interativos:**
- Enquetes: 12
- Votações: 7
- Caixas de Perguntas: 7
- Contagem Regressiva: 3
- Links/Localização: 2
- Bônus: 2

**Dicas Finais de Produção:**

1. **Qualidade Visual:** Todas as fotos devem ser de qualidade profissional ou semi-profissional. Use boa iluminação, foco nítido e composição equilibrada.

2. **Consistência de Estilo:** Mantenha paleta de cores consistente ao longo da semana. Cores quentes (rosa, laranja, ouro) para criar conexão emocional.

3. **Texto Legível:** Todos os textos devem ser legíveis em celular pequeno. Use fontes grandes, contorno preto para legibilidade, e cores contrastantes.

4. **Elementos Interativos:** Coloque sempre o elemento interativo em local visível. Não esconda atrás de texto ou imagem.

5. **CTAs Claros:** Sempre termine cada story com CTA claro. Diga exatamente o que você quer que o usuário faça.

6. **Timing:** Poste nos horários especificados (9h, 13h, 19h) para maximizar visualizações. Esses horários geralmente têm melhor engajamento.

7. **Responda Rápido:** Quando receber respostas nas enquetes/votações/caixas de perguntas, responda rapidamente (nos primeiros 30 minutos). Isso aumenta engajamento.

8. **Salve Dados:** Compile todas as respostas em spreadsheet. Isso cria FAQ, guia futuras campanhas, e identifica tendências.

---

## Como Usar Este Documento

1. **Prepare Conteúdo:** Use as descrições visuais para preparar fotos/vídeos. Você pode gravar tudo no domingo anterior.

2. **Copie Textos:** Copie os textos exatos diretamente deste documento para o Instagram. Não precisa reescrever.

3. **Configure Elementos:** Siga as instruções de elemento interativo para configurar enquetes, votações, etc.

4. **Agende Stories:** Use agendador do Instagram para agendar todos os stories nos horários especificados.

5. **Monitore Respostas:** Durante a semana, acompanhe respostas e responda rapidamente.

6. **Compile Dados:** No final da semana, compile todas as respostas em spreadsheet para análise.

Boa sorte com sua campanha! 🚀
