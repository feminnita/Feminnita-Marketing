# Layout Anterior - Feminnita

## Estrutura do Menu Lateral

### Seção: Pessoas e Influenciadoras
- **Personas** (destacado em amarelo)
- **Tendências**
- **Calendário**

### Seção: Conteúdo e Lista
- **Conteúdo e lista** (expansível)

### Seção: Análise e Dados
- **Painel Executivo**
- **Google Analytics 4**
- **Análise Competitiva**
- **Concorrência em tempo real**
- **Valor ao longo da vida útil**
- **ROI por Segmento**

### Seção: Marketing e Campanhas
- **Marketing e Campanhas** (expansível)

### Seção: Integrações
- **Integrações** (expansível)

### Seção: IA e Automação
- **IA e Automação** (expansível)

## Informações Adicionais
- Total: **138 abas disponíveis**
- Cor do tema: Laranja/Amarelo
- Estilo: Sidebar com menu expansível

## Componentes Principais
1. **Barra de busca** no topo do menu
2. **Ícones de menu** com categorias
3. **Sidebar colapsável** com subcategorias
4. **Conteúdo principal** mostrando "4 Personas de Influenciadoras Humanizadas"
