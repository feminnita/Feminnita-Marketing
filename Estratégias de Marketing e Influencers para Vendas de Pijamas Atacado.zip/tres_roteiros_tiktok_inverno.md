# Três Roteiros de Vídeo para TikTok - Variações do Lançamento de Inverno

## Visão Geral das Três Variações

O objetivo é testar três abordagens diferentes do mesmo produto (pijama de inverno) para identificar qual gera mais engajamento, cliques e conversões no TikTok. Cada roteiro segue a estrutura de sucesso do TikTok (gancho nos 3 primeiros segundos, transições rápidas, áudio viral, CTA clara) mas com narrativas e estilos visuais distintos.

---

# ROTEIRO 1: "ASMR + SENSORIAL" (30 segundos)

## Conceito
Foco em experiência sensorial: toque, som, conforto. Usa ASMR (sons relaxantes) para criar conexão emocional. Ideal para público que busca relaxamento e conforto.

## Informações Gerais

**Título:** "O Som do Conforto - Pijama Inverno Feminnita"  
**Duração:** 30 segundos  
**Objetivo:** Criar conexão emocional através dos sentidos, gerar desejo de conforto  
**Público-Alvo:** Mulheres 18-40 anos, buscando relaxamento, autossuficiência  
**Formato:** ASMR + Sensorial + Reveal + CTA  
**Estilo Visual:** Íntimo, relaxante, close-ups detalhados  
**Tom de Voz:** Sussurrado, relaxante, confortável  
**Áudio:** Sons ASMR (tecido, respiração suave) + música relaxante  

---

## Timeline Detalhada (30 segundos)

### Segundo 0-3: GANCHO SENSORIAL

**Descrição de Cena:**  
Close-up extremo: mão tocando tecido macio do pijama. Câmera bem próxima. Som ASMR de tecido sendo tocado (muito claro, satisfatório). Fundo: luz morna, ambiente aconchego.

**Áudio:**  
Som ASMR de tecido sendo tocado (volume alto, muito claro). Respiração suave feminina. Sem música ainda. Volume total: 85%.

**Texto na Tela:**  
**"SINTA O CONFORTO"**  
(Fonte: Poppins Bold, tamanho 36px, cor branca com contorno preto, animação: fade in suave)

**Efeitos Visuais:**  
Close-up extremo. Cores quentes (laranja, ouro). Há um efeito de "shimmer" suave no tecido. Sem transições abruptas, tudo muito suave.

**Dica de Produção:**  
Capture o som do tecido sendo tocado de forma clara e satisfatória. Este é o gancho. ASMR é muito viral no TikTok.

---

### Segundo 3-10: EXPERIÊNCIA SENSORIAL

**Descrição de Cena:**  
Montagem de 4 cenas (1.75 segundos cada):  
1. Mão tocando tecido (close-up) - som ASMR de tecido
2. Mulher deitando na cama com pijama - som ASMR de lençol
3. Mulher esticando em pijama - som ASMR de movimento suave
4. Mulher respirando profundamente, relaxada - som de respiração calma

**Áudio:**  
Sequência de sons ASMR: tecido, lençol, movimento, respiração. Música relaxante começa suavemente (volume 40%). Voz em off sussurrada (volume 70%): "Tecido premium que abraça seu corpo..."

**Texto na Tela:**  
Aparece em sequência:  
**"100% ALGODÃO PREMIUM"** → **"TOQUE AVELUDADO"** → **"PESO PERFEITO"** → **"CONFORTO TOTAL"**

**Efeitos Visuais:**  
Transições suaves (0.3s). Cores quentes. Há um efeito de "fade" entre cenas. Tudo muito relaxante e fluido.

**Dica de Produção:**  
Capture sons reais de ASMR. Estes sons são muito satisfatórios e virais no TikTok. Mantenha tudo suave e relaxante.

---

### Segundo 10-20: REVEAL + LIFESTYLE

**Descrição de Cena:**  
Montagem de 3 cenas (3.3 segundos cada):  
1. Mulher acordando na cama, esticando, sorrindo suavemente
2. Mulher tomando chá/café quente, em pijama, olhando pela janela
3. Mulher deitada, abraçando almofada, completamente relaxada e feliz

**Áudio:**  
Música relaxante continua (volume 50%). Voz em off sussurrada: "Perfeito para as noites frias... Conforto que você merece..."  
Sons ASMR suaves continuam (respiração, movimento suave).

**Texto na Tela:**  
**"PERFEITO PARA NOITES FRIAS"**  
Depois: **"CONFORTO QUE VOCÊ MERECE"**

**Efeitos Visuais:**  
Transições suaves. Cores quentes (laranja, ouro). Há um efeito de "warm glow" em torno da mulher. Tudo muito aconchego.

**Dica de Produção:**  
Mostre genuinamente o relaxamento. Expressões devem ser de paz e conforto. Iluminação quente é essencial.

---

### Segundo 20-28: PROVA SOCIAL + CARACTERÍSTICAS

**Descrição de Cena:**  
Montagem rápida de 2 cenas (4 segundos cada):  
1. Depoimento de mulher: "Melhor pijama que já tive! Tão macio..." (2 segundos)
2. Montagem de 3 cores diferentes do pijama sendo mostradas (2 segundos)

**Áudio:**  
Voz em off de cliente (natural, genuína): "Melhor pijama que já tive! Tão macio e confortável!"  
Música continua relaxante. Sons ASMR suaves.

**Texto na Tela:**  
**"⭐ CLIENTES AMAM"**  
Depois: **"4 CORES EXCLUSIVAS"**

**Efeitos Visuais:**  
Transições suaves. Cores vibrantes das cores do pijama. Há um efeito de "like" (coração) durante depoimento.

---

### Segundo 28-30: CTA

**Descrição de Cena:**  
Mulher olhando para câmera, sorriso suave, relaxada. Ambiente aconchego, luz morna.

**Áudio:**  
Voz em off sussurrada: "Seu conforto perfeito te espera. Link na bio!"  
Música atinge o pico suavemente. Som de "sucesso" suave (ding).

**Texto na Tela:**  
**"LINK NA BIO"**  
Depois: **"SEU CONFORTO PERFEITO"**

**Efeitos Visuais:**  
Close-up suave. Glow ao redor. Efeito pulse suave no texto.

---

## Especificações Técnicas - Roteiro 1

**Áudio:**  
- Sons ASMR: Tecido, lençol, movimento, respiração (volume 70-85%)
- Música: Relaxante, suave (volume 40-50%)
- Voz em Off: Sussurrada, feminina, relaxante (volume 70%)
- Duração: 30 segundos

**Visuais:**  
- Resolução: 1080x1920px
- FPS: 30fps
- Cores: Quentes (laranja, ouro, rosa suave)
- Estilo: Íntimo, close-ups, relaxante

**Métricas Esperadas:**  
- Visualizações: 15K-25K
- Completion Rate: 60-70% (ASMR retém muito)
- Cliques: 100-150
- Conversão: 8-12 registros

---

---

# ROTEIRO 2: "ANTES/DEPOIS + TRANSFORMAÇÃO" (30 segundos)

## Conceito
Foco em transformação: de "frio e desconforto" para "conforto máximo". Formato antes/depois é muito viral no TikTok. Ideal para público que busca solução prática.

## Informações Gerais

**Título:** "Inverno Antes vs Depois - Pijama Feminnita"  
**Duração:** 30 segundos  
**Objetivo:** Mostrar transformação clara, criar desejo de solução  
**Público-Alvo:** Mulheres 20-45 anos, buscando praticidade e solução  
**Formato:** Antes (Problema) → Depois (Solução) → Prova Social → CTA  
**Estilo Visual:** Dinâmico, contrastante, energético  
**Tom de Voz:** Entusiasmado, confiante, prático  
**Áudio:** Música energética + efeitos de transição + voz em off  

---

## Timeline Detalhada (30 segundos)

### Segundo 0-3: GANCHO ANTES (Problema)

**Descrição de Cena:**  
Mulher tremendo de frio, encolhida, desconfortável. Pijama fino, inadequado para inverno. Expressão de desconforto. Fundo: quarto frio, luz azulada.

**Áudio:**  
Música começa (algo energético, com beat que transmite "problema"). Volume: 70%. Voz em off: "Noites frias = pijama inadequado = sono ruim..."

**Texto na Tela:**  
**"ANTES"**  
Depois aparece: **"FRIO DEMAIS"**  
(Animação: slide da esquerda)

**Efeitos Visuais:**  
Cores frias (azul, branco). Há um efeito de "shake" (tremor) suave. Filtro de dessaturação leve.

---

### Segundo 3-6: TRANSIÇÃO DINÂMICA

**Descrição de Cena:**  
Transição rápida com efeito de "spin" ou "flip". Mulher girando/virando. Efeito de "swoosh" visual.

**Áudio:**  
Som de transição (como um "whoosh" rápido). Música muda para tom mais positivo e energético.

**Texto na Tela:**  
**"DEPOIS"**  
(Animação: slide da direita com efeito de "impacto")

**Efeitos Visuais:**  
Transição rápida (0.5s). Efeito de "spin" ou "flip". Cores mudam de frias para quentes.

---

### Segundo 6-15: DEPOIS (Solução)

**Descrição de Cena:**  
Mesma mulher, agora confortável, relaxada, feliz. Pijama de inverno Feminnita. Deitada confortavelmente na cama, sorrindo. Luz quente, ambiente aconchego.

**Áudio:**  
Voz em off (entusiasmada): "Pijama Inverno Feminnita = conforto máximo, sono perfeito, noites quentinhas!"  
Música continua energética. Som de "sucesso" suave.

**Texto na Tela:**  
**"CONFORTO MÁXIMO"**  
Depois: **"SONO PERFEITO"**  
Depois: **"NOITES QUENTINHAS"**  
(Animação: pop com efeito de "sucesso")

**Efeitos Visuais:**  
Cores quentes. Há um efeito de "glow" ao redor da mulher. Confete digital aparece (opcional). Filtro de "warm" aplicado.

---

### Segundo 15-24: PROVA SOCIAL + NÚMEROS

**Descrição de Cena:**  
Montagem rápida de 3 cenas (3 segundos cada):  
1. Mulher 1 em pijama, sorrindo: "Melhor investimento do inverno!"
2. Mulher 2 em pijama, abraçando almofada: "Minha filha dorme melhor agora!"
3. Números aparecendo: "4 CORES", "100% ALGODÃO", "FRETE GRÁTIS"

**Áudio:**  
Depoimentos de clientes (natural, genuíno). Música continua energética. Sons de "ding" quando números aparecem.

**Texto na Tela:**  
**"⭐ CLIENTES AMAM"**  
Depois: **"4 CORES | 100% ALGODÃO | FRETE GRÁTIS"**

**Efeitos Visuais:**  
Transições rápidas (0.3s). Números com efeito "pop". Cores vibrantes.

---

### Segundo 24-30: CTA + URGÊNCIA

**Descrição de Cena:**  
Mulher confortável, olhando para câmera, sorriso confiante. Ambiente aconchego.

**Áudio:**  
Voz em off (urgente, convidativa): "Não perca! Quantidade limitada! Clique no link da bio AGORA!"  
Música atinge o pico. Som de "urgência" (tick-tock suave).

**Texto na Tela:**  
**"QUANTIDADE LIMITADA"**  
Depois: **"CLIQUE NO LINK DA BIO"**  
Depois: **"AGORA! 🔥"**  
(Animação: pulse/pulsação)

**Efeitos Visuais:**  
Glow ao redor. Efeito pulse intenso no texto. Cores vibrantes.

---

## Especificações Técnicas - Roteiro 2

**Áudio:**  
- Música: Energética, com beat claro (volume 70%)
- Voz em Off: Entusiasmada, clara (volume 80%)
- Efeitos: Transição (whoosh), ding, tick-tock, sucesso (volume 50%)
- Duração: 30 segundos

**Visuais:**  
- Resolução: 1080x1920px
- FPS: 30fps
- Cores: Frias (antes) → Quentes (depois)
- Estilo: Dinâmico, contrastante, energético

**Métricas Esperadas:**  
- Visualizações: 20K-30K (antes/depois é viral)
- Completion Rate: 65-75%
- Cliques: 150-200
- Conversão: 12-18 registros

---

---

# ROTEIRO 3: "TREND HIJACK + DESAFIO" (30 segundos)

## Conceito
Foco em trend viral do TikTok: "Show Me Your..." ou "Fit Check". Mulheres mostram seu pijama de inverno em diferentes contextos. Ideal para engajamento e compartilhamento.

## Informações Gerais

**Título:** "Meu Pijama Inverno Fit Check - Feminnita"  
**Duração:** 30 segundos  
**Objetivo:** Criar engajamento, incentivar compartilhamento, viralizar  
**Público-Alvo:** Mulheres 16-40 anos, buscando trends, fashion  
**Formato:** Trend Hijack + Montagem Rápida + CTA para Participar  
**Estilo Visual:** Colorido, dinâmico, fashion-forward  
**Tom de Voz:** Descontraído, divertido, convidativo  
**Áudio:** Música viral em alta + voz em off + efeitos  

---

## Timeline Detalhada (30 segundos)

### Segundo 0-2: GANCHO TREND

**Descrição de Cena:**  
Mulher em frente ao espelho, fazendo "fit check" (mostrando o pijama). Música viral toca. Transição rápida.

**Áudio:**  
Música viral do TikTok (algo como "Show Me Your..." ou trend atual). Volume: 80%. Voz em off (descontraída): "Vocês tão vendo meu pijama inverno?"

**Texto na Tela:**  
**"PIJAMA INVERNO FIT CHECK"**  
(Animação: slide com efeito de "trend")

**Efeitos Visuais:**  
Cores vibrantes. Transição rápida. Há um efeito de "zoom" no espelho.

---

### Segundo 2-12: MONTAGEM RÁPIDA (Múltiplos Looks)

**Descrição de Cena:**  
Montagem rápida de 5 cenas (2 segundos cada), cada uma mostrando um "look" diferente com pijama de inverno:

1. Pijama azul marinho - mulher em cama, elegante
2. Pijama cinza - mulher em sofá, casual
3. Pijama vinho - mulher em pé, fashion
4. Pijama preto - mulher com amigas, divertida
5. Todas as cores juntas - mulher sorrindo

**Áudio:**  
Música viral continua (energética, com beat claro). Voz em off (descontraída): "Azul marinho, cinza, vinho, preto... Qual é seu favorito?"  
Sons de transição (whoosh, pop) entre cenas.

**Texto na Tela:**  
Aparece em sequência:  
**"AZUL MARINHO"** → **"CINZA"** → **"VINHO"** → **"PRETO"** → **"QUAL É SEU FAVORITO?"**  
(Animação: pop rápido)

**Efeitos Visuais:**  
Transições rápidas (0.3s). Cores vibrantes de cada pijama. Há um efeito de "zoom" em cada cena. Muito dinâmico.

---

### Segundo 12-20: PROVA SOCIAL + ENGAJAMENTO

**Descrição de Cena:**  
Montagem de 3 cenas (2.6 segundos cada):  
1. Mulher 1 mostrando pijama: "Meu favorito é o azul!"
2. Mulher 2 mostrando pijama: "Eu prefiro o vinho!"
3. Mulher 3 mostrando pijama: "Todos são perfeitos!"

**Áudio:**  
Depoimentos de clientes (natural, entusiasmado). Música viral continua. Sons de "ding" entre depoimentos.

**Texto na Tela:**  
**"QUAL É O SEU?"**  
Depois: **"COMENTE ABAIXO!"**

**Efeitos Visuais:**  
Transições rápidas (0.3s). Cores vibrantes. Há um efeito de "like" (coração) durante cada depoimento.

---

### Segundo 20-28: CALL-TO-ACTION + DESAFIO

**Descrição de Cena:**  
Mulher apontando para câmera, sorrindo, desafiadora. Ambiente aconchego, luz quente.

**Áudio:**  
Voz em off (descontraída, convidativa): "Você também quer? Clique no link da bio e mostre seu fit check! Pode ser?"  
Música atinge o pico. Som de "sucesso" divertido.

**Texto na Tela:**  
**"CLIQUE NO LINK DA BIO"**  
Depois: **"MOSTRE SEU FIT CHECK"**  
Depois: **"PODE SER?"**  
(Animação: pulse/pulsação divertida)

**Efeitos Visuais:**  
Glow ao redor. Efeito pulse. Cores vibrantes. Há um efeito de "wink" ou "sparkle" (opcional).

---

### Segundo 28-30: FECHAMENTO

**Descrição de Cena:**  
Mulher fazendo gesto de "vem cá" ou acenando para câmera, sorrindo.

**Áudio:**  
Voz em off (final): "Vem! Feminnita te espera!"  
Música atinge o final com efeito de "sucesso".

**Texto na Tela:**  
**"FEMINNITA PIJAMAS"**  
(Animação: fade out)

**Efeitos Visuais:**  
Glow final. Cores vibrantes. Transição suave para preto.

---

## Especificações Técnicas - Roteiro 3

**Áudio:**  
- Música: Viral, energética, com beat claro (volume 80%)
- Voz em Off: Descontraída, divertida (volume 75%)
- Efeitos: Transições (whoosh, pop), ding, sucesso (volume 50%)
- Duração: 30 segundos

**Visuais:**  
- Resolução: 1080x1920px
- FPS: 30fps
- Cores: Vibrantes, coloridas, fashion-forward
- Estilo: Dinâmico, divertido, trend-hijack

**Métricas Esperadas:**  
- Visualizações: 25K-40K (trend hijack é muito viral)
- Completion Rate: 70-80%
- Cliques: 200-300
- Compartilhamentos: 150-250 (trend incentiva share)
- Conversão: 15-25 registros

---

---

## Comparação: 3 Roteiros TikTok Inverno

| Aspecto | Roteiro 1 (ASMR) | Roteiro 2 (Antes/Depois) | Roteiro 3 (Trend Hijack) |
| :--- | :--- | :--- | :--- |
| **Conceito** | Sensorial, relaxante | Transformação clara | Trend viral, divertido |
| **Gancho** | Som ASMR satisfatório | Contraste visual | Trend reconhecível |
| **Público** | Relaxamento, conforto | Solução prática | Fashion, trends |
| **Tone** | Sussurrado, relaxante | Entusiasmado | Descontraído, divertido |
| **Música** | Relaxante, suave | Energética | Viral, trendy |
| **Cores** | Quentes, aconchego | Frias → Quentes | Vibrantes, coloridas |
| **Transições** | Suaves, fade | Dinâmicas, spin | Rápidas, pop |
| **Prova Social** | Depoimento calmo | Depoimentos + números | Múltiplos depoimentos |
| **CTA** | "Link na bio" | "Quantidade limitada" | "Mostre seu fit check" |
| **Completion Rate** | 60-70% | 65-75% | 70-80% |
| **Cliques** | 100-150 | 150-200 | 200-300 |
| **Conversão** | 8-12 | 12-18 | 15-25 |
| **Shares** | Baixo | Médio | Alto (trend incentiva) |
| **Melhor Para** | Relaxamento, conforto | Urgência, solução | Engajamento, viralidade |

---

## Estratégia de Postagem

### Quando Postar

**Roteiro 1 (ASMR):** 21h-23h (noite, quando pessoas estão relaxando)  
**Roteiro 2 (Antes/Depois):** 19h-21h (noite, quando pessoas estão em casa)  
**Roteiro 3 (Trend Hijack):** 18h-20h (final da tarde/início da noite, quando trends estão em alta)  

### Frequência de Postagem

Postar todos os 3 roteiros em paralelo durante 1-2 semanas:
- **Semana 1:** Postar Roteiro 1 (segunda), Roteiro 2 (quarta), Roteiro 3 (sexta)
- **Semana 2:** Repetir a sequência, analisando métricas
- **Semana 3:** Dobrar a frequência do que melhor funcionou

### Hashtags Recomendadas

**Roteiro 1 (ASMR):**  
#ASMRTikTok #SomSatisfatório #ConfortoMaximo #PijamaPerfeito #Feminnita

**Roteiro 2 (Antes/Depois):**  
#AntesEDepois #TransformaçãoTotal #PijamaInverno #ConfortoInverno #Feminnita

**Roteiro 3 (Trend Hijack):**  
#FitCheck #PijamaFitCheck #TrendTikTok #MeuPijama #Feminnita

---

## Dicas Finais para Maximizar Sucesso

### 1. Qualidade de Áudio é Crítica

Especialmente para Roteiro 1 (ASMR), a qualidade do áudio é tudo. Invista em microfone externo.

### 2. Velocidade + Dinamismo

TikTok adora velocidade. Mantenha transições rápidas (0.3s) e mudanças constantes.

### 3. Teste Múltiplas Versões

Não espere uma versão "perfeita". Poste os 3 roteiros e meça qual funciona melhor.

### 4. Responda Comentários Rapidamente

Engajamento rápido aumenta chances de viralizar. Responda comentários nos primeiros 30 minutos.

### 5. Use Trending Sounds

Especialmente para Roteiro 3, use sons que estão em alta no TikTok no momento.

### 6. Mantenha Consistência

Se um roteiro funcionar bem, crie variações similares. Consistência aumenta reconhecimento.

### 7. Acompanhe Métricas

Rastreie completion rate, cliques, conversões. Otimize baseado em dados.

### 8. Crie Urgência

Todos os roteiros devem ter elemento de urgência ("Quantidade limitada", "Agora", "Mostre seu fit check").

---

## Checklist de Produção

### Antes de Gravar

- [ ] Equipamento testado (câmera, microfone, iluminação)
- [ ] Áudio preparado (ASMR para Roteiro 1, música viral para Roteiros 2 e 3)
- [ ] Ambiente preparado (limpeza, iluminação, fundo)
- [ ] Pijamas prontos (todas as cores para Roteiro 3)
- [ ] Roteiros memorizados ou em cards fora de câmera
- [ ] Múltiplas takes preparadas (mínimo 3 takes por cena)

### Durante a Edição

- [ ] Sincronizar áudio com vídeo
- [ ] Adicionar transições (0.3s)
- [ ] Adicionar texto com animações
- [ ] Balancear volumes
- [ ] Adicionar efeitos visuais
- [ ] Testar em celular real
- [ ] Verificar legibilidade de texto

### Antes de Postar

- [ ] Vídeo tem exatamente 30 segundos
- [ ] Qualidade visual é boa (não pixelado)
- [ ] Áudio está claro (sem ruído)
- [ ] CTA é claro e visível
- [ ] Link na bio está funcional
- [ ] Hashtags estão relevantes
- [ ] Legenda está atrativa
- [ ] Você está satisfeita com o resultado

---

## Resumo Executivo

Estes 3 roteiros oferecem abordagens diferentes para testar qual narrativa funciona melhor com seu público no TikTok. Recomenda-se postar todos os 3 em paralelo durante 1-2 semanas, rastreando métricas (completion rate, cliques, conversões, shares), e depois dobrar a frequência do que melhor funcionou. Cada roteiro é otimizado para o algoritmo do TikTok com gancho nos 3 primeiros segundos, transições rápidas, áudio viral, e CTA clara.
